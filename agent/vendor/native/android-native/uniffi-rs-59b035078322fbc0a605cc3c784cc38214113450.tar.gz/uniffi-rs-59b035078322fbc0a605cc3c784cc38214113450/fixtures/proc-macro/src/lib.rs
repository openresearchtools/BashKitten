/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

use std::{collections::HashMap, sync::Arc};

mod callback_interface;

use callback_interface::TestCallbackInterface;

// Test proc-macro definitions in a submodule (#2728)
mod one {
    #[derive(uniffi::Record)]
    pub struct One {
        pub inner: i32,
    }

    #[uniffi::export]
    impl One {
        fn get_inner_value(&self) -> i32 {
            self.inner
        }

        #[doc(hidden)]
        fn parses_with_doc_attribute(&self) {}
    }
}
pub use one::*;

#[uniffi::export]
pub fn one_inner_by_ref(one: &One) -> i32 {
    one.inner
}

#[derive(uniffi::Record)]
pub struct Two {
    a: String,
}

#[derive(uniffi::Record)]
pub struct NestedRecord {
    // This used to result in an error in bindings generation
    user_type_in_builtin_generic: Option<Two>,
}

#[derive(uniffi::Record)]
pub struct Three {
    obj: Arc<Object>,
}

#[derive(uniffi::Record, Debug, PartialEq)]
pub struct RecordWithBytes {
    some_bytes: Vec<u8>,
}

// An object that's not used anywhere (ie, in records, function signatures, etc)
// should not break things.
#[derive(uniffi::Object)]
pub struct Unused;

#[uniffi::export]
impl Unused {
    #[uniffi::constructor]
    fn new() -> Arc<Self> {
        Arc::new(Self)
    }
}

#[uniffi::export]
pub trait Trait: Send + Sync {
    // Test the absence of `with_foreign` by inputting reference arguments, which is
    // incompatible with callback interfaces
    #[allow(clippy::ptr_arg)]
    fn concat_strings(&self, a: &str, b: &str) -> String;
}

struct TraitImpl {}

impl Trait for TraitImpl {
    fn concat_strings(&self, a: &str, b: &str) -> String {
        format!("{a}{b}")
    }
}

#[uniffi::export(with_foreign)]
pub trait TraitWithForeign: Send + Sync {
    fn name(&self) -> String;
}

struct RustTraitImpl {}

impl TraitWithForeign for RustTraitImpl {
    fn name(&self) -> String {
        "RustTraitImpl".to_string()
    }
}

// A public struct implementing a public trait.
#[derive(uniffi::Object)]
pub struct StructWithTrait {
    name: String,
}

#[uniffi::export]
impl StructWithTrait {
    #[uniffi::constructor]
    fn new(name: String) -> Self {
        Self { name }
    }
}

#[uniffi::export]
impl Trait for StructWithTrait {
    fn concat_strings(&self, a: &str, b: &str) -> String {
        format!("{}: {a}{b}", self.name)
    }
}

#[derive(uniffi::Object, Eq, PartialEq)]
#[uniffi::export(Eq)]
pub struct Object;

#[cfg_attr(feature = "myfeature", uniffi::export)]
impl Object {
    #[cfg_attr(feature = "myfeature", uniffi::constructor)]
    fn new() -> Arc<Self> {
        Arc::new(Self)
    }

    #[uniffi::constructor]
    fn named_ctor(arg: u32) -> Self {
        _ = arg;
        // This constructor returns Self directly.  UniFFI ensures that it's wrapped in an Arc
        // before sending it across the FFI.
        Self
    }

    fn is_heavy(&self) -> MaybeBool {
        MaybeBool::Uncertain
    }

    fn is_other_heavy(&self, other: &Self) -> MaybeBool {
        other.is_heavy()
    }

    fn get_trait(&self, inc: Option<Arc<dyn Trait>>) -> Arc<dyn Trait> {
        inc.unwrap_or_else(|| Arc::new(TraitImpl {}))
    }

    fn get_trait_with_foreign(
        &self,
        inc: Option<Arc<dyn TraitWithForeign>>,
    ) -> Arc<dyn TraitWithForeign> {
        inc.unwrap_or_else(|| Arc::new(RustTraitImpl {}))
    }

    fn take_error(&self, e: BasicError) -> u32 {
        assert!(matches!(e, BasicError::InvalidInput));
        42
    }
}

#[uniffi::export]
fn concat_strings_by_ref(t: &dyn Trait, a: &str, b: &str) -> String {
    t.concat_strings(a, b)
}

#[uniffi::export]
fn make_one(inner: i32) -> One {
    One { inner }
}

#[uniffi::export]
fn take_two(two: Two) -> String {
    two.a
}

#[uniffi::export]
fn make_hashmap(k: i8, v: u64) -> HashMap<i8, u64> {
    HashMap::from([(k, v)])
}

#[uniffi::export]
fn return_hashmap(h: HashMap<i8, u64>) -> HashMap<i8, u64> {
    h
}

#[uniffi::export]
fn take_record_with_bytes(rwb: RecordWithBytes) -> Vec<u8> {
    rwb.some_bytes
}

#[uniffi::export]
fn call_callback_interface(cb: Box<dyn TestCallbackInterface>) {
    cb.do_nothing();
    assert_eq!(cb.add(1, 1), 2);
    assert_eq!(cb.optional(Some(1)), 1);
    assert_eq!(cb.optional(None), 0);
    assert_eq!(
        cb.with_bytes(RecordWithBytes {
            some_bytes: vec![9, 8, 7],
        }),
        vec![9, 8, 7]
    );
    assert_eq!(Ok(10), cb.try_parse_int("10".to_string()));
    assert_eq!(
        Err(BasicError::InvalidInput),
        cb.try_parse_int("ten".to_string())
    );
    assert!(matches!(
        cb.try_parse_int("force-unexpected-error".to_string()),
        Err(BasicError::UnexpectedError { .. }),
    ));
    assert_eq!(42, cb.callback_handler(Object::new()));

    assert_eq!(6, cb.get_other_callback_interface().multiply(2, 3));
}

// Type that's defined in the UDL and not wrapped with #[uniffi::export]
pub struct Zero {
    inner: String,
}

#[uniffi::export]
fn make_zero() -> Zero {
    Zero {
        inner: String::from("ZERO"),
    }
}

#[uniffi::export]
fn make_record_with_bytes() -> RecordWithBytes {
    RecordWithBytes {
        some_bytes: vec![0, 1, 2, 3, 4],
    }
}

#[derive(uniffi::Enum)]
pub enum MaybeBool {
    True,
    False,
    Uncertain,
}

#[uniffi::export]
impl MaybeBool {
    fn next(&self) -> Self {
        match self {
            MaybeBool::True => MaybeBool::False,
            MaybeBool::False => MaybeBool::Uncertain,
            MaybeBool::Uncertain => MaybeBool::True,
        }
    }
}

#[derive(uniffi::Enum)]
pub enum MixedEnum {
    None,
    String(String),
    Int(i64),
    Both(String, i64),
    All { s: String, i: i64 },
    Vec(Vec<String>),
}

#[uniffi::export]
impl MixedEnum {
    fn is_not_none(&self) -> bool {
        !matches!(self, Self::None)
    }
}

#[uniffi::export]
fn get_mixed_enum(v: Option<MixedEnum>) -> MixedEnum {
    v.unwrap_or(MixedEnum::Int(1))
}

#[repr(u8)]
#[derive(uniffi::Enum)]
pub enum ReprU8 {
    One = 1,
    Three = 0x3,
}

#[uniffi::export]
fn enum_identity(value: MaybeBool) -> MaybeBool {
    value
}

#[derive(thiserror::Error, uniffi::Error, Debug, PartialEq, Eq)]
pub enum BasicError {
    #[error("InvalidInput")]
    InvalidInput,
    #[error("OsError")]
    OsError,
    #[error("UnexpectedError")]
    UnexpectedError { reason: String },
}

#[uniffi::export]
impl BasicError {
    fn is_unexpected(&self) -> bool {
        matches!(self, Self::UnexpectedError { .. })
    }
}

#[derive(uniffi::Error, Debug)]
pub enum SimpleError {
    A,
    B,
}

impl From<uniffi::UnexpectedUniFFICallbackError> for BasicError {
    fn from(e: uniffi::UnexpectedUniFFICallbackError) -> Self {
        Self::UnexpectedError { reason: e.reason }
    }
}

#[uniffi::export]
fn always_fails() -> Result<(), BasicError> {
    Err(BasicError::OsError)
}

#[derive(Debug, thiserror::Error, uniffi::Error)]
#[uniffi(flat_error)]
#[non_exhaustive]
pub enum FlatError {
    #[error("Invalid input")]
    InvalidInput,

    // Inner types that aren't FFI-convertible are allowed for flat errors
    #[error("OS error: {0}")]
    OsError(std::io::Error),
}

#[uniffi::export]
impl Object {
    fn do_stuff(&self, times: u32) -> Result<(), FlatError> {
        match times {
            0 => Err(FlatError::InvalidInput),
            _ => {
                // do stuff
                Ok(())
            }
        }
    }
}

// defined in UDL.
fn get_one(one: Option<One>) -> One {
    one.unwrap_or(One { inner: 0 })
}

fn get_bool(b: Option<MaybeBool>) -> MaybeBool {
    b.unwrap_or(MaybeBool::Uncertain)
}

fn get_object(o: Option<Arc<Object>>) -> Arc<Object> {
    o.unwrap_or_else(Object::new)
}

fn get_trait(o: Option<Arc<dyn Trait>>) -> Arc<dyn Trait> {
    o.unwrap_or_else(|| Arc::new(TraitImpl {}))
}

fn get_trait_with_foreign(o: Option<Arc<dyn TraitWithForeign>>) -> Arc<dyn TraitWithForeign> {
    o.unwrap_or_else(|| Arc::new(RustTraitImpl {}))
}

#[derive(Default)]
struct Externals {
    one: Option<One>,
    bool: Option<MaybeBool>,
}

fn get_externals(e: Option<Externals>) -> Externals {
    e.unwrap_or_default()
}

#[uniffi::export]
pub fn join(parts: &[String], sep: &str) -> String {
    parts.join(sep)
}

// Custom names
#[derive(uniffi::Object)]
pub struct Renamed;

// `renamed_new` becomes the default constructor because it's named `new`
#[uniffi::export]
impl Renamed {
    #[uniffi::constructor(name = "new")]
    fn renamed_new() -> Arc<Self> {
        Arc::new(Self)
    }

    #[uniffi::method(name = "func")]
    fn renamed_func(&self) -> bool {
        true
    }
}

#[uniffi::export(name = "rename_test")]
fn renamed_rename_test() -> bool {
    true
}

#[derive(Default)]
pub struct CustomInteger(i32);

uniffi::custom_newtype!(CustomInteger, i32);

/// Test defaults on Records
#[derive(uniffi::Record)]
pub struct RecordWithDefaults {
    no_default_string: String,
    #[uniffi(default = true)]
    boolean: bool,
    #[uniffi(default = 42)]
    integer: i32,
    #[uniffi(default = 4.2)]
    float_var: f64,
    #[uniffi(default=[])]
    vec: Vec<bool>,
    #[uniffi(default=None)]
    opt_vec: Option<Vec<bool>>,
    #[uniffi(default = Some(42))]
    opt_integer: Option<i32>,
    #[uniffi(default = 42)]
    custom_integer: CustomInteger,
    #[uniffi(default)]
    boolean_default: bool,
    #[uniffi(default)]
    string_default: String,
    #[uniffi(default)]
    opt_default: Option<String>,
    // named types
    #[uniffi(default)]
    sub: RecordWithImplicitDefaults,
}

/// Test implicit defaults on Records
#[derive(uniffi::Record)]
pub struct RecordWithImplicitDefaults {
    #[uniffi(default)]
    boolean: bool,
    #[uniffi(default)]
    int8: i8,
    #[uniffi(default)]
    uint8: u8,
    #[uniffi(default)]
    int16: i16,
    #[uniffi(default)]
    uint16: u16,
    #[uniffi(default)]
    int32: i32,
    #[uniffi(default)]
    uint32: u32,
    #[uniffi(default)]
    int64: i64,
    #[uniffi(default)]
    uint64: u64,
    #[uniffi(default)]
    afloat: f32,
    #[uniffi(default)]
    adouble: f64,
    #[uniffi(default)]
    vec: Vec<bool>,
    #[uniffi(default)]
    map: HashMap<String, String>,
    #[uniffi(default)]
    some_bytes: Vec<u8>,
    #[uniffi(default)]
    opt_int32: Option<i32>,
    // Object has a ctor which takes no args.
    #[uniffi(default)]
    object: Arc<Object>,
    #[uniffi(default)]
    custom_integer: CustomInteger,
}

/// Test defaults on top-level functions
#[uniffi::export(default(num = 21))]
fn double_with_default(num: i32) -> i32 {
    num + num
}

/// Test defaults on top-level functions
#[uniffi::export(default(num2))]
fn sum_with_default(num1: i32, num2: i32) -> i32 {
    num1 + num2
}

/// Test defaults on constructors / methods
#[derive(uniffi::Object)]
pub struct ObjectWithDefaults {
    num: i32,
}

#[uniffi::export]
impl ObjectWithDefaults {
    #[uniffi::constructor(default(num = 30))]
    fn new(num: i32) -> Self {
        Self { num }
    }

    #[uniffi::method(default(other = 12))]
    fn add_to_num(&self, other: i32) -> i32 {
        self.num + other
    }

    #[uniffi::method(default(other))]
    fn add_to_implicit_num(&self, other: i32) -> i32 {
        self.num + other
    }
}

uniffi::include_scaffolding!("proc-macro");
