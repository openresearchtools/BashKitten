package com.danielealbano.androidremotecontrolmcp.services.notifications

import android.app.ActivityOptions
import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.service.notification.StatusBarNotification
import com.danielealbano.androidremotecontrolmcp.utils.Logger
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

class NotificationProviderImpl
    @Inject
    constructor(
        @param:ApplicationContext private val context: Context,
    ) : NotificationProvider {
        override fun isReady(): Boolean = McpNotificationListenerService.instance != null

        override suspend fun getNotifications(
            packageName: String?,
            limit: Int?,
        ): List<NotificationData> {
            val service = requireService()
            val notifications =
                service
                    .getNotifications()
                    .let { list ->
                        if (packageName != null) {
                            list.filter { sbn -> sbn.packageName == packageName }
                        } else {
                            list.asIterable()
                        }
                    }.filter { sbn -> hasContent(sbn.notification) }
                    .sortedByDescending { it.postTime }
                    .let { if (limit != null) it.take(limit) else it }
            return notifications.map { NotificationDataExtractor.extract(it, context) }
        }

        @Suppress("ReturnCount")
        override suspend fun openNotification(notificationId: String): Result<Unit> {
            val service = requireService()
            val sbn =
                service.getNotifications().firstOrNull {
                    computeNotificationHash(it.key) == notificationId
                } ?: return Result.failure(IllegalArgumentException("Notification not found: $notificationId"))
            val pendingIntent =
                sbn.notification.contentIntent
                    ?: return Result.failure(IllegalStateException("Notification has no content intent"))
            return try {
                pendingIntent.send(context, 0, null, null, null, null, buildBalOptions())
                Result.success(Unit)
            } catch (e: PendingIntent.CanceledException) {
                Result.failure(e)
            }
        }

        override suspend fun dismissNotification(notificationId: String): Result<Unit> {
            val service = requireService()
            val sbn =
                service.getNotifications().firstOrNull {
                    computeNotificationHash(it.key) == notificationId
                } ?: return Result.failure(IllegalArgumentException("Notification not found: $notificationId"))
            return try {
                service.dismissNotification(sbn.key)
                Result.success(Unit)
            } catch (e: SecurityException) {
                Result.failure(e)
            } catch (e: IllegalArgumentException) {
                Result.failure(e)
            }
        }

        override suspend fun snoozeNotification(
            notificationId: String,
            durationMs: Long,
        ): Result<Unit> {
            val service = requireService()
            val sbn =
                service.getNotifications().firstOrNull {
                    computeNotificationHash(it.key) == notificationId
                } ?: return Result.failure(IllegalArgumentException("Notification not found: $notificationId"))
            return try {
                service.snoozeNotificationByKey(sbn.key, durationMs)
                Result.success(Unit)
            } catch (e: SecurityException) {
                Result.failure(e)
            } catch (e: IllegalArgumentException) {
                Result.failure(e)
            }
        }

        @Suppress("ReturnCount")
        override suspend fun executeAction(actionId: String): Result<Unit> {
            val (_, action) =
                findActionByHash(actionId)
                    ?: return Result.failure(IllegalArgumentException("Action not found: $actionId"))
            val pendingIntent =
                action.actionIntent
                    ?: return Result.failure(IllegalStateException("Action has no pending intent"))
            return try {
                pendingIntent.send(context, 0, null, null, null, null, buildBalOptions())
                Result.success(Unit)
            } catch (e: PendingIntent.CanceledException) {
                Result.failure(e)
            }
        }

        @Suppress("ReturnCount")
        override suspend fun replyToAction(
            actionId: String,
            text: String,
        ): Result<Unit> {
            val (_, action) =
                findActionByHash(actionId)
                    ?: return Result.failure(IllegalArgumentException("Action not found: $actionId"))
            val remoteInputs =
                action.remoteInputs
                    ?: return Result.failure(IllegalStateException("Action does not accept text input"))
            val pendingIntent =
                action.actionIntent
                    ?: return Result.failure(IllegalStateException("Action has no pending intent"))
            val replyIntent = Intent()
            val resultsBundle = Bundle()
            for (remoteInput in remoteInputs) {
                resultsBundle.putCharSequence(remoteInput.resultKey, text)
            }
            RemoteInput.addResultsToIntent(remoteInputs, replyIntent, resultsBundle)
            return try {
                pendingIntent.send(context, 0, replyIntent, null, null, null, buildBalOptions())
                Result.success(Unit)
            } catch (e: PendingIntent.CanceledException) {
                Result.failure(e)
            }
        }

        private fun requireService(): McpNotificationListenerService =
            McpNotificationListenerService.instance
                ?: error("Notification listener service not available")

        private fun findActionByHash(actionId: String): Pair<StatusBarNotification, Notification.Action>? {
            val service = requireService()
            for (sbn in service.getNotifications()) {
                val actions = sbn.notification.actions ?: continue
                for ((index, action) in actions.withIndex()) {
                    if (computeActionHash(sbn.key, index) == actionId) {
                        return Pair(sbn, action)
                    }
                }
            }
            return null
        }

        companion object {
            const val HASH_HEX_LENGTH = 8

            fun computeNotificationHash(key: String): String = "%08x".format(key.hashCode())

            fun computeActionHash(
                key: String,
                actionIndex: Int,
            ): String = "%08x".format("$key::$actionIndex".hashCode())
        }
    }

private fun hasContent(notification: Notification): Boolean {
    val extras = notification.extras
    val hasTitle = extras.getCharSequence(Notification.EXTRA_TITLE) != null
    val hasText = extras.getCharSequence(Notification.EXTRA_TEXT) != null
    val hasBigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT) != null
    val hasActions = notification.actions != null && notification.actions.size > 0
    return hasTitle || hasText || hasBigText || hasActions
}

private fun buildBalOptions(): Bundle? =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
        ActivityOptions
            .makeBasic()
            .apply {
                setPendingIntentBackgroundActivityStartMode(
                    ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED,
                )
            }.toBundle()
    } else {
        null
    }
