@file:Suppress("TooManyFunctions")

package com.danielealbano.androidremotecontrolmcp.mcp.tools

import android.util.Log
import android.view.accessibility.AccessibilityWindowInfo
import com.danielealbano.androidremotecontrolmcp.data.model.ToolPermissionsConfig
import com.danielealbano.androidremotecontrolmcp.mcp.McpToolException
import com.danielealbano.androidremotecontrolmcp.privacy.PlaceholderSubstitutor
import com.danielealbano.androidremotecontrolmcp.privacy.PrivacyToolGate
import com.danielealbano.androidremotecontrolmcp.services.accessibility.AccessibilityNodeCache
import com.danielealbano.androidremotecontrolmcp.services.accessibility.AccessibilityNodeData
import com.danielealbano.androidremotecontrolmcp.services.accessibility.AccessibilityServiceProvider
import com.danielealbano.androidremotecontrolmcp.services.accessibility.AccessibilityTreeLock
import com.danielealbano.androidremotecontrolmcp.services.accessibility.AccessibilityTreeParser
import com.danielealbano.androidremotecontrolmcp.services.accessibility.ActionExecutor
import com.danielealbano.androidremotecontrolmcp.services.accessibility.CachedNode
import com.danielealbano.androidremotecontrolmcp.services.accessibility.ElementFinder
import com.danielealbano.androidremotecontrolmcp.services.accessibility.FindBy
import com.danielealbano.androidremotecontrolmcp.services.accessibility.MultiWindowResult
import com.danielealbano.androidremotecontrolmcp.services.accessibility.ScreenInfo
import com.danielealbano.androidremotecontrolmcp.services.accessibility.ScrollDirection
import com.danielealbano.androidremotecontrolmcp.services.accessibility.WindowData
import io.modelcontextprotocol.kotlin.sdk.server.Server
import io.modelcontextprotocol.kotlin.sdk.types.CallToolResult
import io.modelcontextprotocol.kotlin.sdk.types.ToolSchema
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject
import javax.inject.Inject
import kotlin.random.Random

/**
 * MCP tool: find_nodes
 *
 * Finds UI nodes matching the specified criteria in the accessibility tree.
 * Returns an array of matching nodes (may be empty — empty is NOT an error).
 */
class FindNodesTool
    @Inject
    constructor(
        private val treeParser: AccessibilityTreeParser,
        private val elementFinder: ElementFinder,
        private val accessibilityServiceProvider: AccessibilityServiceProvider,
        private val nodeCache: AccessibilityNodeCache,
        private val privacyToolGate: PrivacyToolGate,
        private val substitutor: PlaceholderSubstitutor,
    ) {
        @Suppress("ThrowsCount")
        suspend fun execute(arguments: JsonObject?): CallToolResult {
            // Validate parameters
            val byStr =
                arguments?.get("by")?.jsonPrimitive?.contentOrNull
                    ?: throw McpToolException.InvalidParams("Missing required parameter 'by'")

            val rawValue =
                arguments["value"]?.jsonPrimitive?.contentOrNull
                    ?: throw McpToolException.InvalidParams("Missing required parameter 'value'")

            if (rawValue.isEmpty()) {
                throw McpToolException.InvalidParams("Parameter 'value' must be non-empty")
            }

            // Reverse any pseudonym placeholder so the search matches the real on-screen value.
            val value = substitutor.substitute(rawValue)

            val exactMatch = arguments["exact_match"]?.jsonPrimitive?.booleanOrNull ?: false

            val findBy =
                mapFindBy(byStr)
                    ?: throw McpToolException.InvalidParams(
                        "Invalid 'by' value: '$byStr'. Must be one of: text, content_desc, resource_id, class_name",
                    )

            // Get fresh multi-window accessibility snapshot
            val result = getFreshWindows(treeParser, accessibilityServiceProvider, nodeCache)

            // Search across all windows
            val elements = elementFinder.findElements(result.windows, findBy, value, exactMatch)

            Log.d(TAG, "find_nodes: by=$byStr, found=${elements.size}")

            val redactedFields =
                privacyToolGate.texts(
                    elements.flatMap { listOf(it.text to "node text", it.contentDescription to "node description") },
                )
            val redactedElements =
                elements.mapIndexed { index, element ->
                    element.copy(text = redactedFields[index * 2], contentDescription = redactedFields[index * 2 + 1])
                }

            val resultJson =
                buildJsonObject {
                    put(
                        "nodes",
                        buildJsonArray {
                            redactedElements.forEach { element ->
                                add(McpToolUtils.buildNodeJson(element))
                            }
                        },
                    )
                }

            return McpToolUtils.untrustedTextResult(Json.encodeToString(resultJson))
        }

        fun register(
            registrar: LoggedToolRegistrar,
            toolNamePrefix: String,
        ) {
            registrar.addTool(
                toolName = TOOL_NAME,
                name = "$toolNamePrefix$TOOL_NAME",
                description =
                    "Find UI nodes matching the specified criteria " +
                        "(text, content_desc, resource_id, class_name)",
                inputSchema =
                    ToolSchema(
                        properties =
                            buildJsonObject {
                                putJsonObject("by") {
                                    put("type", "string")
                                    put(
                                        "enum",
                                        buildJsonArray {
                                            add(JsonPrimitive("text"))
                                            add(JsonPrimitive("content_desc"))
                                            add(JsonPrimitive("resource_id"))
                                            add(JsonPrimitive("class_name"))
                                        },
                                    )
                                    put("description", "Search criteria type")
                                }
                                putJsonObject("value") {
                                    put("type", "string")
                                    put("description", "Search value")
                                }
                                putJsonObject("exact_match") {
                                    put("type", "boolean")
                                    put("default", false)
                                    put(
                                        "description",
                                        "If true, match exactly. If false, match contains (case-insensitive)",
                                    )
                                }
                            },
                        required = listOf("by", "value"),
                    ),
            ) { request -> execute(request.arguments) }
        }

        companion object {
            private const val TAG = "MCP:FindNodesTool"
            const val TOOL_NAME = "find_nodes"
        }
    }

/**
 * MCP tool: click_node
 *
 * Clicks the accessibility node identified by node_id.
 */
class ClickNodeTool
    @Inject
    constructor(
        private val treeParser: AccessibilityTreeParser,
        private val actionExecutor: ActionExecutor,
        private val accessibilityServiceProvider: AccessibilityServiceProvider,
        private val nodeCache: AccessibilityNodeCache,
    ) {
        suspend fun execute(arguments: JsonObject?): CallToolResult {
            val nodeId =
                arguments?.get("node_id")?.jsonPrimitive?.contentOrNull
                    ?: throw McpToolException.InvalidParams("Missing required parameter 'node_id'")

            if (nodeId.isEmpty()) {
                throw McpToolException.InvalidParams("Parameter 'node_id' must be non-empty")
            }

            val multiWindowResult = getFreshWindows(treeParser, accessibilityServiceProvider, nodeCache)

            val result = actionExecutor.clickNode(nodeId, multiWindowResult.windows)
            result.onFailure { e -> mapNodeActionException(e, nodeId) }

            Log.d(TAG, "click_node: nodeId=$nodeId succeeded")
            return McpToolUtils.textResult("Click performed on node '$nodeId'")
        }

        fun register(
            registrar: LoggedToolRegistrar,
            toolNamePrefix: String,
        ) {
            registrar.addTool(
                toolName = TOOL_NAME,
                name = "$toolNamePrefix$TOOL_NAME",
                description =
                    "Click the specified accessibility node by node ID. " +
                        "Returns after the click is performed.",
                inputSchema =
                    ToolSchema(
                        properties =
                            buildJsonObject {
                                putJsonObject("node_id") {
                                    put("type", "string")
                                    put("description", "Node ID from ${toolNamePrefix}find_nodes")
                                }
                            },
                        required = listOf("node_id"),
                    ),
            ) { request -> execute(request.arguments) }
        }

        companion object {
            private const val TAG = "MCP:ClickNodeTool"
            const val TOOL_NAME = "click_node"
        }
    }

/**
 * MCP tool: long_click_node
 *
 * Long-clicks the accessibility node identified by node_id.
 */
class LongClickNodeTool
    @Inject
    constructor(
        private val treeParser: AccessibilityTreeParser,
        private val actionExecutor: ActionExecutor,
        private val accessibilityServiceProvider: AccessibilityServiceProvider,
        private val nodeCache: AccessibilityNodeCache,
    ) {
        suspend fun execute(arguments: JsonObject?): CallToolResult {
            val nodeId =
                arguments?.get("node_id")?.jsonPrimitive?.contentOrNull
                    ?: throw McpToolException.InvalidParams("Missing required parameter 'node_id'")

            if (nodeId.isEmpty()) {
                throw McpToolException.InvalidParams("Parameter 'node_id' must be non-empty")
            }

            val multiWindowResult = getFreshWindows(treeParser, accessibilityServiceProvider, nodeCache)

            val result = actionExecutor.longClickNode(nodeId, multiWindowResult.windows)
            result.onFailure { e -> mapNodeActionException(e, nodeId) }

            Log.d(TAG, "long_click_node: nodeId=$nodeId succeeded")
            return McpToolUtils.textResult("Long-click performed on node '$nodeId'")
        }

        fun register(
            registrar: LoggedToolRegistrar,
            toolNamePrefix: String,
        ) {
            registrar.addTool(
                toolName = TOOL_NAME,
                name = "$toolNamePrefix$TOOL_NAME",
                description =
                    "Long-click the specified accessibility node by node ID. " +
                        "Returns after the action is performed.",
                inputSchema =
                    ToolSchema(
                        properties =
                            buildJsonObject {
                                putJsonObject("node_id") {
                                    put("type", "string")
                                    put("description", "Node ID from ${toolNamePrefix}find_nodes")
                                }
                            },
                        required = listOf("node_id"),
                    ),
            ) { request -> execute(request.arguments) }
        }

        companion object {
            private const val TAG = "MCP:LongClickNodeTool"
            const val TOOL_NAME = "long_click_node"
        }
    }

/**
 * MCP tool: tap_node
 *
 * Performs a gesture-based tap at a random point within the bounds of the
 * node identified by node_id. Unlike click_node (which uses the
 * accessibility ACTION_CLICK), this performs a coordinate-based touch gesture.
 */
class TapNodeTool
    @Inject
    constructor(
        private val treeParser: AccessibilityTreeParser,
        private val elementFinder: ElementFinder,
        private val actionExecutor: ActionExecutor,
        private val accessibilityServiceProvider: AccessibilityServiceProvider,
        private val nodeCache: AccessibilityNodeCache,
    ) {
        @Suppress("ThrowsCount")
        suspend fun execute(arguments: JsonObject?): CallToolResult {
            val nodeId =
                arguments?.get("node_id")?.jsonPrimitive?.contentOrNull
                    ?: throw McpToolException.InvalidParams("Missing required parameter 'node_id'")

            if (nodeId.isEmpty()) {
                throw McpToolException.InvalidParams("Parameter 'node_id' must be non-empty")
            }

            val insetPercentage =
                McpToolUtils.optionalFloat(arguments, "inset_percentage", DEFAULT_INSET_PERCENTAGE)

            if (insetPercentage < MIN_INSET_PERCENTAGE || insetPercentage > MAX_INSET_PERCENTAGE) {
                throw McpToolException.InvalidParams(
                    "Parameter 'inset_percentage' must be between $MIN_INSET_PERCENTAGE and $MAX_INSET_PERCENTAGE",
                )
            }

            val multiWindowResult = getFreshWindows(treeParser, accessibilityServiceProvider, nodeCache)

            val node =
                elementFinder.findNodeById(multiWindowResult.windows, nodeId)
                    ?: throw McpToolException.NodeNotFound("Node '$nodeId' not found")

            val bounds = node.bounds
            val width = bounds.right - bounds.left
            val height = bounds.bottom - bounds.top

            val (tapX, tapY) =
                if (width < SMALL_ELEMENT_THRESHOLD && height < SMALL_ELEMENT_THRESHOLD) {
                    Pair(bounds.left.toFloat(), bounds.top.toFloat())
                } else {
                    val insetFraction = insetPercentage / PERCENTAGE_DIVISOR
                    val insetLeft = bounds.left + width * insetFraction
                    val insetRight = bounds.right - width * insetFraction
                    val insetTop = bounds.top + height * insetFraction
                    val insetBottom = bounds.bottom - height * insetFraction
                    Pair(
                        randomFloatInRange(insetLeft, insetRight),
                        randomFloatInRange(insetTop, insetBottom),
                    )
                }

            Log.d(TAG, "tap_node: nodeId=$nodeId, tapAt=($tapX, $tapY)")

            val result = actionExecutor.tap(tapX, tapY)
            return McpToolUtils.handleActionResult(
                result,
                "Tap executed at (${tapX.toInt()}, ${tapY.toInt()}) within node '$nodeId'",
            )
        }

        internal fun randomFloatInRange(
            min: Float,
            max: Float,
        ): Float {
            if (min >= max) return min
            return min + Random.nextFloat() * (max - min)
        }

        fun register(
            registrar: LoggedToolRegistrar,
            toolNamePrefix: String,
        ) {
            registrar.addTool(
                toolName = TOOL_NAME,
                name = "$toolNamePrefix$TOOL_NAME",
                description =
                    "Performs a gesture-based tap at a random point within the bounds of the " +
                        "node identified by node_id. Unlike click_node (which uses the " +
                        "accessibility ACTION_CLICK), this performs a coordinate-based touch gesture. " +
                        "The tap point is randomized within the node bounds, inset by a configurable " +
                        "percentage (default 5%) from each edge to avoid hitting borders. " +
                        "Returns after the gesture completes.",
                inputSchema =
                    ToolSchema(
                        properties =
                            buildJsonObject {
                                putJsonObject("node_id") {
                                    put("type", "string")
                                    put("description", "Node ID from ${toolNamePrefix}find_nodes")
                                }
                                putJsonObject("inset_percentage") {
                                    put("type", "number")
                                    put("default", DEFAULT_INSET_PERCENTAGE.toDouble())
                                    put(
                                        "description",
                                        "Percentage to inset from each edge of the node bounds " +
                                            "(0.0-45.0). Default 5.0",
                                    )
                                }
                            },
                        required = listOf("node_id"),
                    ),
            ) { request -> execute(request.arguments) }
        }

        companion object {
            private const val TAG = "MCP:TapNodeTool"
            const val TOOL_NAME = "tap_node"
            private const val DEFAULT_INSET_PERCENTAGE = 5.0f
            private const val MIN_INSET_PERCENTAGE = 0.0f
            private const val MAX_INSET_PERCENTAGE = 45.0f
            private const val SMALL_ELEMENT_THRESHOLD = 5
            private const val PERCENTAGE_DIVISOR = 100.0f
        }
    }

/**
 * MCP tool: scroll_to_node
 *
 * Scrolls to make the specified node visible by finding its nearest
 * scrollable ancestor and scrolling it. Retries up to [MAX_SCROLL_ATTEMPTS] times.
 */
class ScrollToNodeTool
    @Inject
    constructor(
        private val treeParser: AccessibilityTreeParser,
        private val elementFinder: ElementFinder,
        private val actionExecutor: ActionExecutor,
        private val accessibilityServiceProvider: AccessibilityServiceProvider,
        private val nodeCache: AccessibilityNodeCache,
    ) {
        @Suppress("ThrowsCount", "LongMethod")
        suspend fun execute(arguments: JsonObject?): CallToolResult {
            val nodeId =
                arguments?.get("node_id")?.jsonPrimitive?.contentOrNull
                    ?: throw McpToolException.InvalidParams("Missing required parameter 'node_id'")

            if (nodeId.isEmpty()) {
                throw McpToolException.InvalidParams("Parameter 'node_id' must be non-empty")
            }

            // Parse multi-window trees and find the node
            var result = getFreshWindows(treeParser, accessibilityServiceProvider, nodeCache)
            var node =
                elementFinder.findNodeById(result.windows, nodeId)
                    ?: throw McpToolException.NodeNotFound("Node '$nodeId' not found")

            // If already visible, return immediately
            if (node.visible) {
                Log.d(TAG, "scroll_to_node: node '$nodeId' already visible")
                return McpToolUtils.textResult("Node '$nodeId' is already visible")
            }

            // Find the window tree containing the target node
            val containingTree =
                findContainingTree(result.windows, nodeId)
                    ?: throw McpToolException.ActionFailed(
                        "Node '$nodeId' not found in any window tree",
                    )

            // Find nearest scrollable ancestor within the same window tree
            val scrollableAncestorId =
                findScrollableAncestor(containingTree, nodeId)
                    ?: throw McpToolException.ActionFailed(
                        "No scrollable container found for node '$nodeId'",
                    )

            // Determine initial scroll direction from the node's position relative to
            // the screen. Nodes above the viewport (bounds.bottom <= 0) need UP scrolling;
            // nodes below or at unknown positions default to DOWN.
            val screenInfo = accessibilityServiceProvider.getScreenInfo()
            val primaryDirection = determineScrollDirection(node, screenInfo)
            val oppositeDirection =
                if (primaryDirection == ScrollDirection.DOWN) ScrollDirection.UP else ScrollDirection.DOWN

            // Try primary direction first, then opposite if node not found
            var totalAttempts = 0
            for (direction in listOf(primaryDirection, oppositeDirection)) {
                while (totalAttempts < MAX_SCROLL_ATTEMPTS) {
                    totalAttempts++
                    val scrollResult =
                        actionExecutor.scrollNode(scrollableAncestorId, direction, result.windows)
                    if (scrollResult.isFailure) {
                        throw McpToolException.ActionFailed(
                            "Scroll failed on ancestor '$scrollableAncestorId': " +
                                "${scrollResult.exceptionOrNull()?.message}",
                        )
                    }

                    // Small delay to let UI settle after scroll
                    kotlinx.coroutines.delay(SCROLL_SETTLE_DELAY_MS)

                    // Re-parse and check visibility
                    result = getFreshWindows(treeParser, accessibilityServiceProvider, nodeCache)
                    node = elementFinder.findNodeById(result.windows, nodeId) ?: continue

                    if (node.visible) {
                        Log.d(
                            TAG,
                            "scroll_to_node: node '$nodeId' became visible " +
                                "after $totalAttempts scroll(s) (direction=$direction)",
                        )
                        return McpToolUtils.textResult(
                            "Scrolled to node '$nodeId' ($totalAttempts scroll(s))",
                        )
                    }
                }
            }

            throw McpToolException.ActionFailed(
                "Node '$nodeId' not visible after $MAX_SCROLL_ATTEMPTS scroll attempts",
            )
        }

        /**
         * Determines the best initial scroll direction based on the node's position
         * relative to the screen viewport.
         *
         * - If the node's bottom edge is at or above the top of the screen -> UP
         * - Otherwise (below viewport or unknown) -> DOWN (most common case)
         */
        internal fun determineScrollDirection(
            node: AccessibilityNodeData,
            screenInfo: ScreenInfo,
        ): ScrollDirection =
            when {
                node.bounds.bottom <= 0 -> ScrollDirection.UP
                node.bounds.top >= screenInfo.height -> ScrollDirection.DOWN
                else -> ScrollDirection.DOWN
            }

        /**
         * Walks up the tree from [targetNodeId] to find the nearest scrollable ancestor.
         * Returns the ancestor's node ID, or null if none found.
         */
        @Suppress("ReturnCount")
        private fun findScrollableAncestor(
            tree: AccessibilityNodeData,
            targetNodeId: String,
        ): String? {
            val path = mutableListOf<AccessibilityNodeData>()
            if (!findPathToNode(tree, targetNodeId, path)) return null

            // Walk the path from parent to root (excluding the target itself)
            for (i in path.size - 2 downTo 0) {
                if (path[i].scrollable) {
                    return path[i].id
                }
            }
            return null
        }

        /**
         * Builds the path from [root] to the node with [targetId].
         * Returns true if found, with [path] containing all nodes from root to target.
         */
        @Suppress("ReturnCount")
        private fun findPathToNode(
            root: AccessibilityNodeData,
            targetId: String,
            path: MutableList<AccessibilityNodeData>,
        ): Boolean {
            path.add(root)
            if (root.id == targetId) return true
            for (child in root.children) {
                if (findPathToNode(child, targetId, path)) return true
            }
            path.removeAt(path.size - 1)
            return false
        }

        /**
         * Finds the window tree that contains the node with [targetNodeId].
         * Returns the tree's root [AccessibilityNodeData], or null if not found.
         */
        private fun findContainingTree(
            windows: List<WindowData>,
            targetNodeId: String,
        ): AccessibilityNodeData? {
            for (windowData in windows) {
                if (elementFinder.findNodeById(windowData.tree, targetNodeId) != null) {
                    return windowData.tree
                }
            }
            return null
        }

        fun register(
            registrar: LoggedToolRegistrar,
            toolNamePrefix: String,
        ) {
            registrar.addTool(
                toolName = TOOL_NAME,
                name = "$toolNamePrefix$TOOL_NAME",
                description = "Scroll to make the specified node visible. Returns after the action is performed.",
                inputSchema =
                    ToolSchema(
                        properties =
                            buildJsonObject {
                                putJsonObject("node_id") {
                                    put("type", "string")
                                    put("description", "Node ID from ${toolNamePrefix}find_nodes")
                                }
                            },
                        required = listOf("node_id"),
                    ),
            ) { request -> execute(request.arguments) }
        }

        companion object {
            private const val TAG = "MCP:ScrollToNodeTool"
            const val TOOL_NAME = "scroll_to_node"
            private const val MAX_SCROLL_ATTEMPTS = 5
            private const val SCROLL_SETTLE_DELAY_MS = 300L
        }
    }

// ─────────────────────────────────────────────────────────────────────────────
// Shared Utilities for Node Action Tools
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Maps a "by" string parameter to the [FindBy] enum.
 * Returns null if the string does not match any known value.
 */
internal fun mapFindBy(by: String): FindBy? =
    when (by.lowercase()) {
        "text" -> FindBy.TEXT
        "content_desc" -> FindBy.CONTENT_DESC
        "resource_id" -> FindBy.RESOURCE_ID
        "class_name" -> FindBy.CLASS_NAME
        else -> null
    }

/**
 * Gets a fresh multi-window accessibility snapshot by enumerating all on-screen windows
 * and parsing each window's accessibility tree.
 *
 * Falls back to single-window mode via [AccessibilityServiceProvider.getRootNode] if
 * [AccessibilityServiceProvider.getAccessibilityWindows] returns an empty list.
 *
 * **Performance note**: This function re-parses ALL window trees on every invocation to ensure
 * correctness — stale tree data would cause actions to target the wrong nodes. During parsing,
 * real [AccessibilityNodeInfo] references are accumulated in a [MutableMap] and stored in
 * [nodeCache] via [AccessibilityNodeCache.populate] for O(1) node resolution in
 * [ActionExecutorImpl.performNodeAction]. The cache is replaced atomically on each call.
 *
 * @throws McpToolException.PermissionDenied if accessibility service is not connected.
 * @throws McpToolException.ActionFailed if no windows and no root node are available.
 */
internal fun getFreshWindows(
    treeParser: AccessibilityTreeParser,
    accessibilityServiceProvider: AccessibilityServiceProvider,
    nodeCache: AccessibilityNodeCache,
): MultiWindowResult =
    // Serialize the entire clear+read+populate critical section against concurrent MCP requests:
    // clearing the shared framework node cache mid-traversal of another request would yield a torn
    // tree and flaky node-id resolution. See AccessibilityTreeLock.
    synchronized(AccessibilityTreeLock.monitor) {
        getFreshWindowsLocked(treeParser, accessibilityServiceProvider, nodeCache)
    }

@Suppress("LongMethod", "NestedBlockDepth", "ThrowsCount")
private fun getFreshWindowsLocked(
    treeParser: AccessibilityTreeParser,
    accessibilityServiceProvider: AccessibilityServiceProvider,
    nodeCache: AccessibilityNodeCache,
): MultiWindowResult {
    if (!accessibilityServiceProvider.isReady()) {
        throw McpToolException.PermissionDenied(
            "Accessibility service not enabled or not ready. " +
                "Please enable it in Android Settings > Accessibility.",
        )
    }

    // Drop the framework's accessibility node cache before reading. Chromium WebView
    // suppresses/throttles the content-changed events that invalidate that cache, so a JavaScript
    // DOM change (e.g. updated text) would otherwise read back stale — and node.refresh() cannot
    // re-fetch what the cache still serves as current. Clearing here makes get_screen_state,
    // find_nodes, and the action tools' re-reads (which all go through getFreshWindows) round-trip
    // live and populate the node cache with live nodes. The lightweight wait_for_node/wait_for_idle
    // poll paths do not go through here and clear the cache themselves (see UtilityTools). See
    // AccessibilityServiceProvider.clearFrameworkNodeCache.
    accessibilityServiceProvider.clearFrameworkNodeCache()

    // Accumulate real AccessibilityNodeInfo references from ALL windows for cache population.
    // This map is passed to each parseTree call and populated during tree traversal.
    // We populate the cache ONCE after all windows are parsed to avoid the multi-window
    // cache overwrite problem (Critical Finding 1).
    val accumulatedNodeMap = mutableMapOf<String, CachedNode>()

    val accessibilityWindows = accessibilityServiceProvider.getAccessibilityWindows()

    if (accessibilityWindows.isNotEmpty()) {
        try {
            val currentPackageName = accessibilityServiceProvider.getCurrentPackageName()
            val currentActivityName = accessibilityServiceProvider.getCurrentActivityName()
            val windowDataList = mutableListOf<WindowData>()

            for (window in accessibilityWindows) {
                val rootNode = window.root ?: continue

                // Force the accessibility framework to re-query the underlying
                // AccessibilityNodeProvider (e.g., Compose's virtual node provider).
                // Without this, window.root can return stale cached snapshots —
                // particularly problematic for Jetpack Compose apps where
                // TYPE_WINDOW_CONTENT_CHANGED events may be throttled or missed.
                rootNode.refresh()

                // Extract metadata BEFORE parsing
                val wId = window.id
                val windowPackage = rootNode.packageName?.toString()
                val windowTitle = window.title?.toString()
                val windowType = window.type
                val windowLayer = window.layer
                val windowFocused = window.isFocused

                // Root nodes are NOT recycled — they are stored in accumulatedNodeMap
                // and owned by the cache. On API 33+ recycle() is a no-op, but we
                // avoid calling it on cached nodes for semantic clarity (Critical Finding 2).
                val tree = treeParser.parseTree(rootNode, "root_w$wId", accumulatedNodeMap)

                // Best-effort activity name: only for focused APPLICATION window matching tracked package
                val activityName =
                    if (windowFocused &&
                        windowType == AccessibilityWindowInfo.TYPE_APPLICATION &&
                        windowPackage == currentPackageName
                    ) {
                        currentActivityName
                    } else {
                        null
                    }

                windowDataList.add(
                    WindowData(
                        windowId = wId,
                        windowType = AccessibilityTreeParser.mapWindowType(windowType),
                        packageName = windowPackage,
                        title = windowTitle,
                        activityName = activityName,
                        layer = windowLayer,
                        focused = windowFocused,
                        tree = tree,
                    ),
                )
            }

            if (windowDataList.isEmpty()) {
                throw McpToolException.ActionFailed(
                    "All windows returned null root nodes.",
                )
            }

            // Populate cache with ALL windows' nodes in a single atomic swap
            nodeCache.populate(accumulatedNodeMap)

            return MultiWindowResult(windows = windowDataList, degraded = false)
        } finally {
            // Recycle all AccessibilityWindowInfo objects for consistency
            // (no-op on API 34+, but follows the codebase's recycling convention)
            for (w in accessibilityWindows) {
                @Suppress("DEPRECATION")
                w.recycle()
            }
        }
    }

    // Fallback to single-window mode
    val rootNode =
        accessibilityServiceProvider.getRootNode()
            ?: throw McpToolException.ActionFailed(
                "No windows available and no active window root node. " +
                    "The screen may be transitioning.",
            )

    // Force fresh data from the accessibility framework (see multi-window path comment).
    rootNode.refresh()

    // Extract metadata from the root node before recycling.
    // Use rootNode.window (available API 21+) to detect the actual window type
    // instead of hardcoding APPLICATION — the active window could be SYSTEM, INPUT_METHOD, etc.
    val fallbackWindowId = rootNode.windowId
    val windowInfo = rootNode.window
    val fallbackWindowType =
        if (windowInfo != null) {
            val type = AccessibilityTreeParser.mapWindowType(windowInfo.type)
            @Suppress("DEPRECATION")
            windowInfo.recycle()
            type
        } else {
            "APPLICATION"
        }

    // Fallback path also accumulates into the same map and does NOT recycle root node
    val tree = treeParser.parseTree(rootNode, "root_w$fallbackWindowId", accumulatedNodeMap)

    // Populate cache with fallback window's nodes
    nodeCache.populate(accumulatedNodeMap)

    val currentPackageName = accessibilityServiceProvider.getCurrentPackageName()
    val currentActivityName = accessibilityServiceProvider.getCurrentActivityName()

    return MultiWindowResult(
        windows =
            listOf(
                WindowData(
                    windowId = fallbackWindowId,
                    windowType = fallbackWindowType,
                    packageName = currentPackageName,
                    title = "unknown",
                    activityName = currentActivityName,
                    layer = 0,
                    focused = true,
                    tree = tree,
                ),
            ),
        degraded = true,
    )
}

/**
 * Registers all node action tools with the [Server].
 */
@Suppress("LongParameterList")
fun registerNodeActionTools(
    registrar: LoggedToolRegistrar,
    treeParser: AccessibilityTreeParser,
    elementFinder: ElementFinder,
    actionExecutor: ActionExecutor,
    accessibilityServiceProvider: AccessibilityServiceProvider,
    nodeCache: AccessibilityNodeCache,
    privacyToolGate: PrivacyToolGate,
    substitutor: PlaceholderSubstitutor,
    toolNamePrefix: String,
    perms: ToolPermissionsConfig,
) {
    if (perms.isToolEnabled(FindNodesTool.TOOL_NAME)) {
        FindNodesTool(treeParser, elementFinder, accessibilityServiceProvider, nodeCache, privacyToolGate, substitutor)
            .register(registrar, toolNamePrefix)
    }
    if (perms.isToolEnabled(ClickNodeTool.TOOL_NAME)) {
        ClickNodeTool(treeParser, actionExecutor, accessibilityServiceProvider, nodeCache)
            .register(registrar, toolNamePrefix)
    }
    if (perms.isToolEnabled(LongClickNodeTool.TOOL_NAME)) {
        LongClickNodeTool(treeParser, actionExecutor, accessibilityServiceProvider, nodeCache)
            .register(registrar, toolNamePrefix)
    }
    if (perms.isToolEnabled(TapNodeTool.TOOL_NAME)) {
        TapNodeTool(treeParser, elementFinder, actionExecutor, accessibilityServiceProvider, nodeCache)
            .register(registrar, toolNamePrefix)
    }
    if (perms.isToolEnabled(ScrollToNodeTool.TOOL_NAME)) {
        ScrollToNodeTool(treeParser, elementFinder, actionExecutor, accessibilityServiceProvider, nodeCache)
            .register(registrar, toolNamePrefix)
    }
}

/**
 * Maps exceptions from [ActionExecutor] node actions to [McpToolException]
 * with appropriate MCP error codes.
 *
 * @throws McpToolException always (this function never returns normally).
 */
@Suppress("ThrowsCount")
internal fun mapNodeActionException(
    exception: Throwable,
    nodeId: String,
): Nothing {
    when (exception) {
        is NoSuchElementException -> {
            throw McpToolException.NodeNotFound(
                "Node '$nodeId' not found in accessibility tree",
            )
        }

        is IllegalStateException -> {
            if (exception.message?.contains("not available") == true) {
                throw McpToolException.PermissionDenied(
                    exception.message ?: "Accessibility service not available",
                )
            }
            throw McpToolException.ActionFailed(
                exception.message ?: "Action failed on node '$nodeId'",
            )
        }

        else -> {
            throw McpToolException.ActionFailed(
                "Action failed on node '$nodeId': ${exception.message}",
            )
        }
    }
}
