@file:Suppress("DEPRECATION")

package com.danielealbano.androidremotecontrolmcp.integration

import android.graphics.Rect
import android.os.SystemClock
import android.view.accessibility.AccessibilityWindowInfo
import com.danielealbano.androidremotecontrolmcp.mcp.tools.stripUntrustedWarning
import com.danielealbano.androidremotecontrolmcp.services.accessibility.AccessibilityNodeData
import com.danielealbano.androidremotecontrolmcp.services.accessibility.BoundsData
import com.danielealbano.androidremotecontrolmcp.services.accessibility.ScreenInfo
import com.danielealbano.androidremotecontrolmcp.services.accessibility.WindowData
import io.mockk.coEvery
import io.mockk.every
import io.mockk.mockk
import io.mockk.mockkStatic
import io.mockk.slot
import io.mockk.unmockkStatic
import io.modelcontextprotocol.kotlin.sdk.types.TextContent
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNotEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.DisplayName
import org.junit.jupiter.api.Test

@DisplayName("Error Handling Integration Tests")
class ErrorHandlingIntegrationTest {
    private val sampleTree =
        AccessibilityNodeData(
            id = "node_root",
            className = "android.widget.FrameLayout",
            bounds = BoundsData(0, 0, 1080, 2400),
            visible = true,
        )

    private val sampleScreenInfo =
        ScreenInfo(
            width = 1080,
            height = 2400,
            densityDpi = 420,
            orientation = "portrait",
        )

    @BeforeEach
    fun setUp() {
        McpIntegrationTestHelper.mockAndroidLog()
    }

    @AfterEach
    fun tearDown() {
        McpIntegrationTestHelper.unmockAndroidLog()
    }

    @Test
    fun `permission denied returns error result`() =
        runTest {
            val deps = McpIntegrationTestHelper.createMockDependencies()
            every { deps.accessibilityServiceProvider.isReady() } returns false

            McpIntegrationTestHelper.withTestApplication(deps) { client, _ ->
                val result =
                    client.callTool(
                        name = "android_press_back",
                        arguments = emptyMap(),
                    )
                assertEquals(true, result.isError)
                val text = (result.content[0] as TextContent).text
                assertTrue(text.contains("Accessibility service not enabled"))
            }
        }

    @Test
    fun `node not found returns error result`() =
        runTest {
            val deps = McpIntegrationTestHelper.createMockDependencies()
            McpIntegrationTestHelper.setupMultiWindowMock(deps, sampleTree, sampleScreenInfo)
            coEvery {
                deps.actionExecutor.clickNode("nonexistent", any<List<WindowData>>())
            } returns
                Result.failure(
                    NoSuchElementException("Node 'nonexistent' not found"),
                )

            McpIntegrationTestHelper.withTestApplication(deps) { client, _ ->
                val result =
                    client.callTool(
                        name = "android_click_node",
                        arguments = mapOf("node_id" to "nonexistent"),
                    )
                assertEquals(true, result.isError)
                val text = (result.content[0] as TextContent).text
                assertTrue(text.contains("nonexistent"))
            }
        }

    @Test
    fun `action failed returns error result`() =
        runTest {
            val deps = McpIntegrationTestHelper.createMockDependencies()
            McpIntegrationTestHelper.setupMultiWindowMock(deps, sampleTree, sampleScreenInfo)
            coEvery {
                deps.actionExecutor.clickNode("node_root", any<List<WindowData>>())
            } returns
                Result.failure(
                    IllegalStateException("Node 'node_root' is not clickable"),
                )

            McpIntegrationTestHelper.withTestApplication(deps) { client, _ ->
                val result =
                    client.callTool(
                        name = "android_click_node",
                        arguments = mapOf("node_id" to "node_root"),
                    )
                assertEquals(true, result.isError)
                val text = (result.content[0] as TextContent).text
                assertTrue(text.contains("not clickable"))
            }
        }

    @Test
    fun `invalid params returns error result`() =
        runTest {
            McpIntegrationTestHelper.withTestApplication { client, _ ->
                val result =
                    client.callTool(
                        name = "android_tap",
                        arguments = mapOf("x" to "not_a_number", "y" to 100),
                    )
                assertEquals(true, result.isError)
                val text = (result.content[0] as TextContent).text
                assertTrue(text.isNotEmpty())
            }
        }

    @Test
    fun `internal error returns error result`() =
        runTest {
            val deps = McpIntegrationTestHelper.createMockDependencies()
            every { deps.accessibilityServiceProvider.isReady() } returns true
            coEvery {
                deps.actionExecutor.pressBack()
            } throws RuntimeException("Unexpected internal error")

            McpIntegrationTestHelper.withTestApplication(deps) { client, _ ->
                val result =
                    client.callTool(
                        name = "android_press_back",
                        arguments = emptyMap(),
                    )
                assertEquals(true, result.isError)
                val text = (result.content[0] as TextContent).text
                assertTrue(text.contains("Unexpected internal error"))
            }
        }

    @Test
    fun `wait_for_node timeout returns informational non-error result`() =
        runTest {
            mockkStatic(SystemClock::class)
            try {
                var clockMs = 0L
                every { SystemClock.elapsedRealtime() } answers {
                    val current = clockMs
                    clockMs += 200L
                    current
                }

                val deps = McpIntegrationTestHelper.createMockDependencies()
                McpIntegrationTestHelper.setupMultiWindowMock(deps, sampleTree, sampleScreenInfo)
                // No findElements mock needed — rawNodeExists returns false
                // (raw node properties are null/0/empty by default), findElements is never called

                McpIntegrationTestHelper.withTestApplication(deps) { client, _ ->
                    val result =
                        client.callTool(
                            name = "android_wait_for_node",
                            arguments =
                                mapOf(
                                    "by" to "text",
                                    "value" to "nonexistent_element_xyz",
                                    "timeout" to 1000,
                                ),
                        )
                    assertNotEquals(true, result.isError)
                    val text = (result.content[0] as TextContent).text
                    assertTrue(text.contains("timed out"))
                }
            } finally {
                unmockkStatic(SystemClock::class)
            }
        }

    @Test
    fun `wait_for_idle timeout returns informational non-error result`() =
        runTest {
            mockkStatic(SystemClock::class)
            try {
                var clockMs = 0L
                every { SystemClock.elapsedRealtime() } answers { clockMs }

                val deps = McpIntegrationTestHelper.createMockDependencies()
                every { deps.accessibilityServiceProvider.isReady() } returns true
                val mockWin = mockk<AccessibilityWindowInfo>(relaxed = true)
                every { mockWin.id } returns 0
                every { mockWin.type } returns AccessibilityWindowInfo.TYPE_APPLICATION
                every { mockWin.title } returns "Test"
                every { mockWin.layer } returns 0
                every { mockWin.isFocused } returns true
                every {
                    deps.accessibilityServiceProvider.getAccessibilityWindows()
                } returns listOf(mockWin)
                every { deps.accessibilityServiceProvider.getCurrentPackageName() } returns "com.example"
                every { deps.accessibilityServiceProvider.getCurrentActivityName() } returns ".Main"
                every { deps.accessibilityServiceProvider.getScreenInfo() } returns sampleScreenInfo
                // Return a different raw root node each poll to force timeout
                var callCount = 0
                every { mockWin.root } answers {
                    callCount++
                    clockMs += 600L
                    val node = mockk<android.view.accessibility.AccessibilityNodeInfo>()
                    every { node.className } returns "android.widget.FrameLayout"
                    every { node.text } returns "changing_text_$callCount"
                    val rectSlot = slot<Rect>()
                    every { node.getBoundsInScreen(capture(rectSlot)) } answers {
                        rectSlot.captured.left = 0
                        rectSlot.captured.top = 0
                        rectSlot.captured.right = 1080
                        rectSlot.captured.bottom = 2400
                    }
                    every { node.childCount } returns 0
                    node
                }

                McpIntegrationTestHelper.withTestApplication(deps) { client, _ ->
                    val result =
                        client.callTool(
                            name = "android_wait_for_idle",
                            arguments = mapOf("timeout" to 1000),
                        )
                    assertNotEquals(true, result.isError)
                    val text = (result.content[0] as TextContent).text
                    val parsed = Json.parseToJsonElement(stripUntrustedWarning(text)).jsonObject
                    assertTrue(parsed["message"]?.jsonPrimitive?.content?.contains("timed out") == true)
                    assertTrue(parsed.containsKey("similarity"))
                    assertTrue(parsed.containsKey("elapsedMs"))
                }
            } finally {
                unmockkStatic(SystemClock::class)
            }
        }
}
