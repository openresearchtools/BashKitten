package com.danielealbano.androidremotecontrolmcp.mcp.auth

import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.statement.bodyAsText
import io.ktor.http.HttpStatusCode
import io.ktor.serialization.kotlinx.json.json
import io.ktor.server.application.install
import io.ktor.server.plugins.contentnegotiation.ContentNegotiation
import io.ktor.server.response.respondText
import io.ktor.server.routing.get
import io.ktor.server.routing.routing
import io.ktor.server.testing.testApplication
import io.mockk.every
import io.mockk.mockkStatic
import io.mockk.unmockkStatic
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test

class BearerTokenAuthTest {
    @BeforeEach
    fun setUp() {
        mockkStatic(android.util.Log::class)
        every { android.util.Log.d(any(), any()) } returns 0
        every { android.util.Log.i(any(), any()) } returns 0
        every { android.util.Log.w(any(), any<String>()) } returns 0
        every { android.util.Log.e(any(), any()) } returns 0
        every { android.util.Log.e(any(), any(), any()) } returns 0
    }

    @AfterEach
    fun tearDown() {
        unmockkStatic(android.util.Log::class)
    }

    // --- constantTimeEquals tests ---

    @Test
    fun `constantTimeEquals returns true for identical strings`() {
        assertTrue(constantTimeEquals("my-secret-token", "my-secret-token"))
    }

    @Test
    fun `constantTimeEquals returns false for different strings`() {
        assertFalse(constantTimeEquals("my-secret-token", "wrong-token"))
    }

    @Test
    fun `constantTimeEquals returns false for empty vs non-empty`() {
        assertFalse(constantTimeEquals("my-secret-token", ""))
    }

    @Test
    fun `constantTimeEquals returns true for both empty`() {
        assertTrue(constantTimeEquals("", ""))
    }

    @Test
    fun `constantTimeEquals returns false for strings differing in length`() {
        assertFalse(constantTimeEquals("short", "a-much-longer-string"))
    }

    @Test
    fun `constantTimeEquals returns false for strings differing by one character`() {
        assertFalse(constantTimeEquals("abcdef", "abcdeg"))
    }

    @Test
    fun `constantTimeEquals handles unicode strings`() {
        assertTrue(constantTimeEquals("token-\u00e9\u00e8", "token-\u00e9\u00e8"))
        assertFalse(constantTimeEquals("token-\u00e9\u00e8", "token-\u00e9\u00e7"))
    }

    @Test
    fun `constantTimeEquals handles UUID-format tokens`() {
        val token = "550e8400-e29b-41d4-a716-446655440000"
        assertTrue(constantTimeEquals(token, token))
        assertFalse(constantTimeEquals(token, "550e8400-e29b-41d4-a716-446655440001"))
    }

    // --- Timing consistency verification ---
    // Note: True constant-time verification requires statistical analysis of timing
    // measurements, which is impractical in a unit test. The test below verifies
    // that MessageDigest.isEqual is being used (by checking the function produces
    // correct results for edge cases that would differ between naive and constant-time
    // implementations).

    @Test
    fun `constantTimeEquals returns correct result regardless of mismatch position`() {
        val base = "abcdefghijklmnop"
        // Mismatch at first character
        assertFalse(constantTimeEquals(base, "Xbcdefghijklmnop"))
        // Mismatch at last character
        assertFalse(constantTimeEquals(base, "abcdefghijklmnoX"))
        // Mismatch at middle character
        assertFalse(constantTimeEquals(base, "abcdefgXijklmnop"))
    }

    // --- Ktor plugin integration tests ---

    @Test
    fun `plugin returns 401 when Authorization header is missing`() =
        testApplication {
            application {
                install(ContentNegotiation) { json() }
                install(McpAuthPlugin) { expectedToken = TEST_TOKEN }
                routing {
                    get("/protected/resource") { call.respondText("OK") }
                }
            }

            val response = client.get("/protected/resource")
            assertEquals(HttpStatusCode.Unauthorized, response.status)
        }

    @Test
    fun `plugin returns 401 when Authorization header is malformed`() =
        testApplication {
            application {
                install(ContentNegotiation) { json() }
                install(McpAuthPlugin) { expectedToken = TEST_TOKEN }
                routing {
                    get("/protected/resource") { call.respondText("OK") }
                }
            }

            val response =
                client.get("/protected/resource") {
                    header("Authorization", "Basic abc123")
                }
            assertEquals(HttpStatusCode.Unauthorized, response.status)
        }

    @Test
    fun `plugin returns 401 when token is invalid`() =
        testApplication {
            application {
                install(ContentNegotiation) { json() }
                install(McpAuthPlugin) { expectedToken = TEST_TOKEN }
                routing {
                    get("/protected/resource") { call.respondText("OK") }
                }
            }

            val response =
                client.get("/protected/resource") {
                    header("Authorization", "Bearer wrong-token")
                }
            assertEquals(HttpStatusCode.Unauthorized, response.status)
        }

    @Test
    fun `plugin prevents route handler execution when auth fails`() =
        testApplication {
            var routeHandlerCalled = false
            application {
                install(ContentNegotiation) { json() }
                install(McpAuthPlugin) { expectedToken = TEST_TOKEN }
                routing {
                    get("/protected/resource") {
                        routeHandlerCalled = true
                        call.respondText("OK")
                    }
                }
            }

            val response = client.get("/protected/resource")
            assertEquals(HttpStatusCode.Unauthorized, response.status)
            assertFalse(routeHandlerCalled, "Route handler must not execute when authentication fails")
        }

    @Test
    fun `plugin skips authentication when both methods disabled`() =
        testApplication {
            application {
                install(ContentNegotiation) { json() }
                install(McpAuthPlugin) {
                    bearerTokenEnabled = false
                    oauthEnabled = false
                }
                routing {
                    get("/protected/resource") { call.respondText("OK") }
                }
            }

            val response = client.get("/protected/resource")
            assertEquals(HttpStatusCode.OK, response.status)
            assertEquals("OK", response.bodyAsText())
        }

    @Test
    fun `plugin allows request with valid token`() =
        testApplication {
            application {
                install(ContentNegotiation) { json() }
                install(McpAuthPlugin) { expectedToken = TEST_TOKEN }
                routing {
                    get("/protected/resource") { call.respondText("OK") }
                }
            }

            val response =
                client.get("/protected/resource") {
                    header("Authorization", "Bearer $TEST_TOKEN")
                }
            assertEquals(HttpStatusCode.OK, response.status)
            assertEquals("OK", response.bodyAsText())
        }

    @Test
    fun `plugin skips authentication for excluded paths`() =
        testApplication {
            application {
                install(ContentNegotiation) { json() }
                install(McpAuthPlugin) {
                    expectedToken = TEST_TOKEN
                    excludedPaths = setOf("/health")
                }
                routing {
                    get("/health") { call.respondText("OK") }
                    get("/protected/resource") { call.respondText("Secret") }
                }
            }

            // /health should be accessible without auth
            val healthResponse = client.get("/health")
            assertEquals(HttpStatusCode.OK, healthResponse.status)
            assertEquals("OK", healthResponse.bodyAsText())

            // /protected/resource should still require auth
            val protectedResponse = client.get("/protected/resource")
            assertEquals(HttpStatusCode.Unauthorized, protectedResponse.status)
        }

    // --- Combined-auth (dual-accept) tests ---

    @Test
    fun `valid OAuth token allowed via validateOAuthToken`() =
        testApplication {
            application {
                install(ContentNegotiation) { json() }
                install(McpAuthPlugin) {
                    bearerTokenEnabled = false
                    oauthEnabled = true
                    validateOAuthToken = { _, _ -> true }
                }
                routing { get("/protected/resource") { call.respondText("OK") } }
            }

            val response = client.get("/protected/resource") { header("Authorization", "Bearer any-jwt") }
            assertEquals(HttpStatusCode.OK, response.status)
        }

    @Test
    fun `401 has WWW-Authenticate only when oauth enabled`() =
        testApplication {
            application {
                install(ContentNegotiation) { json() }
                install(McpAuthPlugin) {
                    expectedToken = TEST_TOKEN
                    oauthEnabled = true
                    validateOAuthToken = { _, _ -> false }
                }
                routing { get("/protected/resource") { call.respondText("OK") } }
            }
            val withOauth = client.get("/protected/resource")
            assertEquals(HttpStatusCode.Unauthorized, withOauth.status)
            assertTrue(withOauth.headers["WWW-Authenticate"]?.contains("resource_metadata") == true)
        }

    @Test
    fun `401 has no WWW-Authenticate when only bearer enabled`() =
        testApplication {
            application {
                install(ContentNegotiation) { json() }
                install(McpAuthPlugin) { expectedToken = TEST_TOKEN }
                routing { get("/protected/resource") { call.respondText("OK") } }
            }
            val response = client.get("/protected/resource")
            assertEquals(HttpStatusCode.Unauthorized, response.status)
            assertEquals(null, response.headers["WWW-Authenticate"])
        }

    @Test
    fun `bearer enabled with empty token fails closed`() =
        testApplication {
            application {
                install(ContentNegotiation) { json() }
                install(McpAuthPlugin) {
                    bearerTokenEnabled = true
                    expectedToken = ""
                    oauthEnabled = false
                }
                routing { get("/protected/resource") { call.respondText("OK") } }
            }
            val response = client.get("/protected/resource")
            assertEquals(HttpStatusCode.Unauthorized, response.status)
        }

    @Test
    fun `malformed Authorization header with oauth on returns single 401 with header`() =
        testApplication {
            application {
                install(ContentNegotiation) { json() }
                install(McpAuthPlugin) {
                    expectedToken = TEST_TOKEN
                    oauthEnabled = true
                    validateOAuthToken = { _, _ -> false }
                }
                routing { get("/protected/resource") { call.respondText("OK") } }
            }
            val response = client.get("/protected/resource") { header("Authorization", "Basic abc123") }
            assertEquals(HttpStatusCode.Unauthorized, response.status)
            assertTrue(response.headers["WWW-Authenticate"]?.contains("resource_metadata") == true)
        }

    @Test
    fun `static bearer rejected when only oauth enabled`() =
        testApplication {
            application {
                install(ContentNegotiation) { json() }
                install(McpAuthPlugin) {
                    bearerTokenEnabled = false
                    oauthEnabled = true
                    validateOAuthToken = { _, _ -> false }
                }
                routing { get("/protected/resource") { call.respondText("OK") } }
            }
            val response = client.get("/protected/resource") { header("Authorization", "Bearer $TEST_TOKEN") }
            assertEquals(HttpStatusCode.Unauthorized, response.status)
        }

    companion object {
        private const val TEST_TOKEN = "test-secret-token"
    }
}
