package com.danielealbano.androidremotecontrolmcp.debug

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.danielealbano.androidremotecontrolmcp.data.model.BindingAddress
import com.danielealbano.androidremotecontrolmcp.data.model.ServerConfig
import com.danielealbano.androidremotecontrolmcp.data.repository.SettingsRepository
import com.danielealbano.androidremotecontrolmcp.services.mcp.McpServerService
import com.danielealbano.androidremotecontrolmcp.services.storage.StorageLocationProvider
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Debug-only [BroadcastReceiver] that accepts test configuration overrides
 * via `adb shell am broadcast`.
 *
 * This receiver lives in the `debug` source set, so it is absent from the release
 * APK entirely. It allows E2E tests to inject server settings (bearer token,
 * binding address, port) into the app's DataStore without manipulating protobuf
 * files directly.
 *
 * The source set alone is NOT the security boundary: debug APKs are attached to
 * GitHub releases, so this receiver does reach real devices. It is additionally
 * gated by `android:permission="android.permission.DUMP"` in the debug manifest —
 * a signature/privileged platform permission held by the adb shell UID
 * (com.android.shell) but not grantable to third-party apps. ActivityManager
 * enforces it against the sender's real binder calling UID, so `adb shell am
 * broadcast` still reaches this receiver while an ordinary app is rejected with a
 * SecurityException before [onReceive] runs. Without that gate, any installed app
 * could rewrite the MCP server's configuration (see GHSA-v82h-m32h-3j39).
 *
 * **Usage** (from E2E test via adb):
 * ```
 * # Configure settings
 * adb shell am broadcast \
 *   -a com.danielealbano.androidremotecontrolmcp.debug.E2E_CONFIGURE \
 *   -n com.danielealbano.androidremotecontrolmcp.debug/.E2EConfigReceiver \
 *   --es bearer_token "test-token-uuid" \
 *   --es binding_address "0.0.0.0" \
 *   --ei port 8080 \
 *   --ez auto_start_on_boot true
 *
 * # Start the MCP server (runs inside app process, avoids exported=false restriction)
 * adb shell am broadcast \
 *   -a com.danielealbano.androidremotecontrolmcp.debug.E2E_START_SERVER \
 *   -n com.danielealbano.androidremotecontrolmcp.debug/.E2EConfigReceiver
 * ```
 */
@AndroidEntryPoint
class E2EConfigReceiver : BroadcastReceiver() {
    @Inject
    lateinit var settingsRepository: SettingsRepository

    @Inject
    lateinit var storageLocationProvider: StorageLocationProvider

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onReceive(
        context: Context,
        intent: Intent,
    ) {
        // Log immediately to verify receiver is being called
        Log.i(TAG, "!!! onReceive called with action: ${intent.action}")

        @Suppress("TooGenericExceptionCaught")
        try {
            when (intent.action) {
                ACTION_E2E_CONFIGURE -> handleConfigure(intent)
                ACTION_E2E_START_SERVER -> handleStartServer(context)
                else -> Log.w(TAG, "Ignoring unexpected action: ${intent.action}")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception in onReceive", e)
        }
    }

    private fun handleConfigure(intent: Intent) {
        Log.i(TAG, "Received E2E configuration broadcast")

        val bearerToken = intent.getStringExtra(EXTRA_BEARER_TOKEN)
        val bindingAddress = intent.getStringExtra(EXTRA_BINDING_ADDRESS)
        val port = intent.getIntExtra(EXTRA_PORT, -1)
        val hasAutoStart = intent.hasExtra(EXTRA_AUTO_START_ON_BOOT)
        val autoStart = intent.getBooleanExtra(EXTRA_AUTO_START_ON_BOOT, false)

        scope.launch {
            if (!bearerToken.isNullOrEmpty()) {
                settingsRepository.updateBearerToken(bearerToken)
                Log.i(TAG, "Bearer token updated (length=${bearerToken.length})")
            }
            if (!bindingAddress.isNullOrEmpty()) {
                val address =
                    if (bindingAddress == "0.0.0.0") {
                        BindingAddress.NETWORK
                    } else {
                        BindingAddress.LOCALHOST
                    }
                settingsRepository.updateBindingAddress(address)
                Log.i(TAG, "Binding address updated to $address")
            }
            if (port in ServerConfig.MIN_PORT..ServerConfig.MAX_PORT) {
                settingsRepository.updatePort(port)
                Log.i(TAG, "Port updated to $port")
            }
            if (hasAutoStart) {
                settingsRepository.updateAutoStartOnBoot(autoStart)
                Log.i(TAG, "Auto-start on boot updated to $autoStart")
            }
            applyAuthFlags(intent)
            applyDownloadSettings(intent)
            val storageLocationId = intent.getStringExtra(EXTRA_STORAGE_LOCATION_ID)
            if (!storageLocationId.isNullOrEmpty()) {
                if (storageLocationProvider.isLocationAuthorized(storageLocationId)) {
                    if (intent.hasExtra(EXTRA_STORAGE_ALLOW_WRITE)) {
                        val allowWrite = intent.getBooleanExtra(EXTRA_STORAGE_ALLOW_WRITE, false)
                        storageLocationProvider.updateLocationAllowWrite(storageLocationId, allowWrite)
                        Log.i(TAG, "Storage location allowWrite=$allowWrite")
                    }
                    if (intent.hasExtra(EXTRA_STORAGE_ALLOW_DELETE)) {
                        val allowDelete = intent.getBooleanExtra(EXTRA_STORAGE_ALLOW_DELETE, false)
                        storageLocationProvider.updateLocationAllowDelete(storageLocationId, allowDelete)
                        Log.i(TAG, "Storage location allowDelete=$allowDelete")
                    }
                } else {
                    Log.w(TAG, "Unknown storage location: $storageLocationId")
                }
            }
            Log.i(TAG, "E2E configuration applied successfully")
        }
    }

    private suspend fun applyAuthFlags(intent: Intent) {
        if (intent.hasExtra(EXTRA_OAUTH_ENABLED)) {
            val oauthEnabled = intent.getBooleanExtra(EXTRA_OAUTH_ENABLED, false)
            settingsRepository.updateOauthEnabled(oauthEnabled)
            Log.i(TAG, "OAuth enabled updated to $oauthEnabled")
        }
        if (intent.hasExtra(EXTRA_BEARER_TOKEN_ENABLED)) {
            val bearerEnabled = intent.getBooleanExtra(EXTRA_BEARER_TOKEN_ENABLED, false)
            settingsRepository.updateBearerTokenEnabled(bearerEnabled)
            Log.i(TAG, "Bearer token enabled updated to $bearerEnabled")
        }
    }

    private suspend fun applyDownloadSettings(intent: Intent) {
        val downloadTimeout = intent.getIntExtra(EXTRA_DOWNLOAD_TIMEOUT_SECONDS, -1)
        if (downloadTimeout in
            ServerConfig.MIN_DOWNLOAD_TIMEOUT_SECONDS..ServerConfig.MAX_DOWNLOAD_TIMEOUT_SECONDS
        ) {
            settingsRepository.updateDownloadTimeout(downloadTimeout)
            Log.i(TAG, "Download timeout updated to $downloadTimeout s")
        }
        if (intent.hasExtra(EXTRA_ALLOW_HTTP_DOWNLOADS)) {
            val allowHttp = intent.getBooleanExtra(EXTRA_ALLOW_HTTP_DOWNLOADS, false)
            settingsRepository.updateAllowHttpDownloads(allowHttp)
            Log.i(TAG, "Allow HTTP downloads updated to $allowHttp")
        }
    }

    private fun handleStartServer(context: Context) {
        Log.i(TAG, "Received E2E start server broadcast")
        val intent =
            Intent(context, McpServerService::class.java).apply {
                action = McpServerService.ACTION_START
            }
        context.startForegroundService(intent)
        Log.i(TAG, "McpServerService start command sent")
    }

    companion object {
        private const val TAG = "E2E:ConfigReceiver"
        const val ACTION_E2E_CONFIGURE = "com.danielealbano.androidremotecontrolmcp.debug.E2E_CONFIGURE"
        const val ACTION_E2E_START_SERVER = "com.danielealbano.androidremotecontrolmcp.debug.E2E_START_SERVER"
        private const val EXTRA_BEARER_TOKEN = "bearer_token"
        private const val EXTRA_OAUTH_ENABLED = "oauth_enabled"
        private const val EXTRA_BEARER_TOKEN_ENABLED = "bearer_token_enabled"
        private const val EXTRA_BINDING_ADDRESS = "binding_address"
        private const val EXTRA_PORT = "port"
        private const val EXTRA_AUTO_START_ON_BOOT = "auto_start_on_boot"
        private const val EXTRA_STORAGE_LOCATION_ID = "storage_location_id"
        private const val EXTRA_STORAGE_ALLOW_WRITE = "storage_allow_write"
        private const val EXTRA_STORAGE_ALLOW_DELETE = "storage_allow_delete"
        private const val EXTRA_DOWNLOAD_TIMEOUT_SECONDS = "download_timeout_seconds"
        private const val EXTRA_ALLOW_HTTP_DOWNLOADS = "allow_http_downloads"
    }
}
