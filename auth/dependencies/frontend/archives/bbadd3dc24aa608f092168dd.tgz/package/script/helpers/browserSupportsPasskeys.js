"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.browserSupportsPasskeys = browserSupportsPasskeys;
const browserSupportsWebAuthn_js_1 = require("./browserSupportsWebAuthn.js");
const getBrowserCapabilities_js_1 = require("./getBrowserCapabilities.js");
/**
 * Determine if the browser is capable of facilitating use of synced passkeys for **authentication**
 * via local platform authenticator or via the hybrid transport. This method does NOT know if the
 * user actually has a passkey available to use.
 */
async function browserSupportsPasskeys() {
    if (!(0, browserSupportsWebAuthn_js_1.browserSupportsWebAuthn)()) {
        return new Promise((resolve) => resolve(false));
    }
    const capabilities = await (0, getBrowserCapabilities_js_1.getBrowserCapabilities)();
    const { passkeyPlatformAuthenticator, userVerifyingPlatformAuthenticator, hybridTransport, } = capabilities;
    return passkeyPlatformAuthenticator === 'supported' ||
        hybridTransport === 'supported' ||
        userVerifyingPlatformAuthenticator === 'supported';
}
