"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toPublicKeyCredentialDescriptor = toPublicKeyCredentialDescriptor;
const base64URLStringToBuffer_js_1 = require("./base64URLStringToBuffer.js");
function toPublicKeyCredentialDescriptor(descriptor) {
    const { id } = descriptor;
    return {
        ...descriptor,
        id: (0, base64URLStringToBuffer_js_1.base64URLStringToBuffer)(id),
        transports: descriptor.transports,
        type: descriptor.type,
    };
}
