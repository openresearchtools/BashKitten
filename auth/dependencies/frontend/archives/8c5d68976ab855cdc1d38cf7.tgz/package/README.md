# eslint-plugin-react-web-api

ESLint React's ESLint plugin for React to interact with Web APIs.

## Install

```sh
# npm
npm install --save-dev eslint-plugin-react-web-api
```

## Setup

```ts
import js from "@eslint/js";
import reactWebApi from "eslint-plugin-react-web-api";
import { defineConfig } from "eslint/config";
import tseslint from "typescript-eslint";

export default defineConfig(
  {
    files: ["**/*.{ts,tsx}"],
    extends: [
      js.configs.recommended,
      tseslint.configs.recommended,
      // Add configs from eslint-plugin-react-web-api
      reactWebApi.configs.recommended,
    ],
    rules: {
      // Put rules you want to override here
      "react-web-api/no-leaked-event-listener": "warn",
    },
  },
);
```

## Rules

<https://eslint-react.xyz/docs/rules#web-api-rules>

## Rules to be implemented

| Rule                                    | Description                                   |
| :-------------------------------------- | :-------------------------------------------- |
| `no-leaked-idle-callback`               | Prevents leaked `requestIdleCallback`         |
| `no-leaked-animation-frame`             | Prevents leaked `requestAnimationFrame`       |
| `no-leaked-event-source`                | Prevents leaked `EventSource`                 |
| `no-leaked-mutation-observer`           | Prevents leaked `MutationObserver`            |
| `no-leaked-performance-observer`        | Prevents leaked `PerformanceObserver`         |
| `no-leaked-websocket`                   | Prevents leaked `WebSocket`                   |
| `no-leaked-broadcast-channel`           | Prevents leaked `BroadcastChannel`            |
| `no-leaked-geolocation`                 | Prevents leaked `Geolocation.watchPosition()` |
| `no-leaked-absolute-orientation-sensor` | Prevents leaked `AbsoluteOrientationSensor`   |
| `no-leaked-relative-accelerometer`      | Prevents leaked `Accelerometer`               |
| `no-leaked-ambient-light-sensor`        | Prevents leaked `AmbientLightSensor`          |
| `no-leaked-gravity-sensor`              | Prevents leaked `GravitySensor`               |
| `no-leaked-gyroscope`                   | Prevents leaked `Gyroscope`                   |
| `no-leaked-linear-acceleration-sensor`  | Prevents leaked `LinearAccelerationSensor`    |
| `no-leaked-magnetometer`                | Prevents leaked `Magnetometer`                |
| `no-leaked-orientation-sensor`          | Prevents leaked `OrientationSensor`           |
