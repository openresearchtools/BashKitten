import type CachedResponseStateEnum from './CachedResponseStateEnum.js';
import type Headers from '../../Headers.js';
import type * as PropertySymbol from '../../../PropertySymbol.js';
export default interface ICachedResponse {
    /** Response. */
    response: {
        status: number;
        statusText: string;
        url: string;
        headers: Headers;
        waitingForBody: boolean;
        body: Buffer | null;
        [PropertySymbol.virtualServerFile]?: string | null;
    };
    /** Request. */
    request: {
        headers: Headers;
        method: string;
    };
    /** Cache update time in milliseconds. */
    cacheUpdateTime: number;
    /** Last modified time in milliseconds. */
    lastModified: number | null;
    /** Vary headers. */
    vary: {
        [header: string]: string;
    };
    /** Expire time in milliseconds. */
    expires: number | null;
    /** ETag */
    etag: string | null;
    /** Must revalidate using "If-Modified-Since" request when expired. Not supported yet. */
    mustRevalidate: boolean;
    /** Stale while revalidate using "If-Modified-Since" request when expired */
    staleWhileRevalidate: boolean;
    /** Used when "mustRevalidate" or "staleWhileRevalidate" is true. */
    state: CachedResponseStateEnum;
    /** Virtual server response */
    virtual: boolean;
}
//# sourceMappingURL=ICachedResponse.d.ts.map