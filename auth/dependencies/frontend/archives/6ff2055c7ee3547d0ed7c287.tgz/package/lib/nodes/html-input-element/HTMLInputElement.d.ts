import HTMLElement from '../html-element/HTMLElement.js';
import * as PropertySymbol from '../../PropertySymbol.js';
import ValidityState from '../../validity-state/ValidityState.js';
import Event from '../../event/Event.js';
import HTMLInputElementSelectionModeEnum from './HTMLInputElementSelectionModeEnum.js';
import type HTMLFormElement from '../html-form-element/HTMLFormElement.js';
import FileList from './FileList.js';
import type HTMLLabelElement from '../html-label-element/HTMLLabelElement.js';
import type HTMLDataListElement from '../html-data-list-element/HTMLDataListElement.js';
import type NodeList from '../node/NodeList.js';
/**
 * HTML Input Element.
 *
 * Reference:
 * https://developer.mozilla.org/en-US/docs/Web/API/HTMLInputElement.
 *
 * Used as reference for some of the logic (like selection range):
 * https://github.com/jsdom/jsdom/blob/master/lib/jsdom/living/nodes/nodes/HTMLInputElement-impl.js (MIT licensed).
 */
export default class HTMLInputElement extends HTMLElement {
    #private;
    cloneNode: (deep?: boolean) => HTMLInputElement;
    [PropertySymbol.value]: string | null;
    [PropertySymbol.height]: number;
    [PropertySymbol.width]: number;
    [PropertySymbol.checked]: boolean | null;
    [PropertySymbol.validationMessage]: string;
    [PropertySymbol.validity]: ValidityState;
    [PropertySymbol.files]: FileList;
    [PropertySymbol.indeterminate]: boolean;
    [PropertySymbol.formNode]: HTMLFormElement | null;
    [PropertySymbol.popoverTargetElement]: HTMLElement | null;
    get oninput(): ((event: Event) => void) | null;
    set oninput(value: ((event: Event) => void) | null);
    get oninvalid(): ((event: Event) => void) | null;
    set oninvalid(value: ((event: Event) => void) | null);
    get onselectionchange(): ((event: Event) => void) | null;
    set onselectionchange(value: ((event: Event) => void) | null);
    /**
     * Returns default checked.
     *
     * @returns Default checked.
     */
    get defaultChecked(): boolean;
    /**
     * Sets default checked.
     *
     * @param defaultChecked Default checked.
     */
    set defaultChecked(defaultChecked: boolean);
    /**
     * Returns files.
     *
     * @returns Files.
     */
    get files(): FileList;
    /**
     * Sets files.
     *
     * @param files Files.
     */
    set files(files: FileList);
    /**
     * Returns form action.
     *
     * @returns Form action.
     */
    get formAction(): string;
    /**
     * Sets form action.
     *
     * @param formAction Form action.
     */
    set formAction(formAction: string);
    /**
     * Returns form enctype.
     *
     * @returns Form enctype.
     */
    get formEnctype(): string;
    /**
     * Sets form enctype.
     *
     * @param formEnctype Form enctype.
     */
    set formEnctype(formEnctype: string);
    /**
     * Returns form method.
     *
     * @returns Form method.
     */
    get formMethod(): string;
    /**
     * Sets form method.
     *
     * @param formMethod Form method.
     */
    set formMethod(formMethod: string);
    /**
     * Returns no validate.
     *
     * @returns No validate.
     */
    get formNoValidate(): boolean;
    /**
     * Sets no validate.
     *
     * @param formNoValidate No validate.
     */
    set formNoValidate(formNoValidate: boolean);
    /**
     * Returns form target.
     *
     * @returns Form target.
     */
    get formTarget(): string;
    /**
     * Sets form target.
     *
     * @param formTarget Form target.
     */
    set formTarget(formTarget: string);
    /**
     * Returns the parent form element.
     *
     * @returns Form.
     */
    get form(): HTMLFormElement | null;
    /**
     * Returns validation message.
     *
     * @returns Validation message.
     */
    get validationMessage(): string;
    /**
     * Returns validity.
     *
     * @returns Validity.
     */
    get validity(): ValidityState;
    /**
     * Returns height.
     *
     * @returns Height.
     */
    get height(): number;
    /**
     * Sets height.
     *
     * @param height Height.
     */
    set height(height: number);
    /**
     * Returns width.
     *
     * @returns Width.
     */
    get width(): number;
    /**
     * Sets width.
     *
     * @param width Width.
     */
    set width(width: number);
    /**
     * Returns size.
     *
     * @returns Size.
     */
    get size(): number;
    /**
     * Sets size.
     *
     * @param size Size.
     */
    set size(size: number);
    /**
     * Returns minlength.
     *
     * @returns Min length.
     */
    get minLength(): number;
    /**
     * Sets minlength.
     *
     * @param minLength Min length.
     */
    set minLength(minlength: number);
    /**
     * Returns maxlength.
     *
     * @returns Max length.
     */
    get maxLength(): number;
    /**
     * Sets maxlength.
     *
     * @param maxlength Max length.
     */
    set maxLength(maxLength: number);
    /**
     * Returns type.
     *
     * @returns Type. Defaults to "text".
     */
    get type(): string;
    /**
     * Sets type.
     *
     * @param type Type.
     */
    set type(type: string);
    /**
     * Returns name.
     *
     * @returns Name.
     */
    get name(): string;
    /**
     * Sets name.
     *
     * @param name Name.
     */
    set name(name: string);
    /**
     * Returns alt.
     *
     * @returns Alt.
     */
    get alt(): string;
    /**
     * Sets alt.
     *
     * @param alt Alt.
     */
    set alt(alt: string);
    /**
     * Returns min.
     *
     * @returns Min.
     */
    get min(): string;
    /**
     * Sets min.
     *
     * @param min Min.
     */
    set min(min: string);
    /**
     * Returns max.
     *
     * @returns Max.
     */
    get max(): string;
    /**
     * Sets max.
     *
     * @param max Max.
     */
    set max(max: string);
    /**
     * Returns pattern.
     *
     * @returns Pattern.
     */
    get pattern(): string;
    /**
     * Sets pattern.
     *
     * @param pattern Pattern.
     */
    set pattern(pattern: string);
    /**
     * Returns placeholder.
     *
     * @returns Placeholder.
     */
    get placeholder(): string;
    /**
     * Sets placeholder.
     *
     * @param placeholder Placeholder.
     */
    set placeholder(placeholder: string);
    /**
     * Returns step.
     *
     * @returns Step.
     */
    get step(): string;
    /**
     * Sets step.
     *
     * @param step Step.
     */
    set step(step: string);
    /**
     * Returns inputmode.
     *
     * @returns Inputmode.
     */
    get inputMode(): string;
    /**
     * Sets inputmode.
     *
     * @param inputmode Inputmode.
     */
    set inputMode(inputmode: string);
    /**
     * Returns accept.
     *
     * @returns Accept.
     */
    get accept(): string;
    /**
     * Sets accept.
     *
     * @param accept Accept.
     */
    set accept(accept: string);
    /**
     * Returns allowdirs.
     *
     * @returns Allowdirs.
     */
    get allowdirs(): string;
    /**
     * Sets allowdirs.
     *
     * @param allowdirs Allowdirs.
     */
    set allowdirs(allowdirs: string);
    /**
     * Returns autocomplete.
     *
     * @returns Autocomplete.
     */
    get autocomplete(): string;
    /**
     * Sets autocomplete.
     *
     * @param autocomplete Autocomplete.
     */
    set autocomplete(autocomplete: string);
    /**
     * Returns src.
     *
     * @returns Src.
     */
    get src(): string;
    /**
     * Sets src.
     *
     * @param src Src.
     */
    set src(src: string);
    /**
     * Returns defaultValue.
     *
     * @returns Defaultvalue.
     */
    get defaultValue(): string;
    /**
     * Sets defaultValue.
     *
     * @param defaultValue Defaultvalue.
     */
    set defaultValue(defaultValue: string);
    /**
     * Returns read only.
     *
     * @returns Read only.
     */
    get readOnly(): boolean;
    /**
     * Sets read only.
     *
     * @param readOnly Read only.
     */
    set readOnly(readOnly: boolean);
    /**
     * Returns disabled.
     *
     * @returns Disabled.
     */
    get disabled(): boolean;
    /**
     * Sets disabled.
     *
     * @param disabled Disabled.
     */
    set disabled(disabled: boolean);
    /**
     * Returns autofocus.
     *
     * @returns Autofocus.
     */
    get autofocus(): boolean;
    /**
     * Sets autofocus.
     *
     * @param autofocus Autofocus.
     */
    set autofocus(autofocus: boolean);
    /**
     * Returns required.
     *
     * @returns Required.
     */
    get required(): boolean;
    /**
     * Sets required.
     *
     * @param required Required.
     */
    set required(required: boolean);
    /**
     * Returns indeterminate.
     *
     * @returns Indeterminate.
     */
    get indeterminate(): boolean;
    /**
     * Sets indeterminate.
     *
     * @param indeterminate Indeterminate.
     */
    set indeterminate(indeterminate: boolean);
    /**
     * Returns multiple.
     *
     * @returns Multiple.
     */
    get multiple(): boolean;
    /**
     * Sets multiple.
     *
     * @param multiple Multiple.
     */
    set multiple(multiple: boolean);
    /**
     * Returns checked.
     *
     * @returns Checked.
     */
    get checked(): boolean;
    /**
     * Sets checked.
     *
     * @param checked Checked.
     */
    set checked(checked: boolean);
    /**
     * Returns value.
     *
     * @returns Value.
     */
    get value(): string;
    /**
     * Sets value.
     *
     * @param value Value.
     */
    set value(value: string | null);
    /**
     * Returns selection start.
     *
     * @returns Selection start.
     */
    get selectionStart(): number | null;
    /**
     * Sets selection start.
     *
     * @param start Start.
     */
    set selectionStart(start: number);
    /**
     * Returns selection end.
     *
     * @returns Selection end.
     */
    get selectionEnd(): number | null;
    /**
     * Sets selection end.
     *
     * @param end End.
     */
    set selectionEnd(end: number);
    /**
     * Returns selection direction.
     *
     * @returns Selection direction.
     */
    get selectionDirection(): string | null;
    /**
     * Sets selection direction.
     *
     * @param direction Direction.
     */
    set selectionDirection(direction: string);
    /**
     * Returns "true" if it will validate.
     *
     * @returns "true" if it will validate.
     */
    get willValidate(): boolean;
    /**
     * Returns value as Date.
     *
     * @returns Date.
     */
    get valueAsDate(): Date | null;
    /**
     * Sets value from a Date.
     *
     * @param value Date.
     */
    set valueAsDate(value: Date | null);
    /**
     * Returns value as number.
     *
     * @returns Number.
     */
    get valueAsNumber(): number;
    /**
     * Sets value from a number.
     *
     * @param value number.
     */
    set valueAsNumber(value: number);
    /**
     * Returns the associated label elements.
     *
     * @returns Label elements.
     */
    get labels(): NodeList<HTMLLabelElement>;
    /**
     * Returns associated datalist element.
     *
     * @returns Data list element.
     */
    get list(): HTMLDataListElement | null;
    /**
     * Returns popover target element.
     *
     * @returns Popover target element.
     */
    get popoverTargetElement(): HTMLElement | null;
    /**
     * Sets popover target element.
     *
     * @param popoverTargetElement Popover target element.
     */
    set popoverTargetElement(popoverTargetElement: HTMLElement | null);
    /**
     * Returns popover target action.
     *
     * @returns Popover target action.
     */
    get popoverTargetAction(): string;
    /**
     * Sets popover target action.
     *
     * @param value Popover target action.
     */
    set popoverTargetAction(value: string);
    /**
     * @override
     */
    get tabIndex(): number;
    /**
     * @override
     */
    set tabIndex(tabIndex: number);
    /**
     * Sets validation message.
     *
     * @param message Message.
     */
    setCustomValidity(message: string): void;
    /**
     * Selects the text.
     */
    select(): void;
    /**
     * Set selection range.
     *
     * @param start Start.
     * @param end End.
     * @param [direction="none"] Direction.
     */
    setSelectionRange(start: number, end: number, direction?: string): void;
    /**
     * Set range text.
     *
     * @param replacement Replacement.
     * @param [start] Start.
     * @param [end] End.
     * @param [direction] Direction.
     * @param selectionMode
     */
    setRangeText(replacement: string, start?: number | null, end?: number | null, selectionMode?: HTMLInputElementSelectionModeEnum): void;
    /**
     * Checks validity.
     *
     * @returns "true" if the field is valid.
     */
    checkValidity(): boolean;
    /**
     * Reports validity.
     *
     * @returns "true" if the field is valid.
     */
    reportValidity(): boolean;
    /**
     * Steps up.
     *
     * @param [increment] Increment.
     */
    stepUp(increment?: number): void;
    /**
     * Steps down.
     *
     * @param [increment] Increment.
     */
    stepDown(increment?: number): void;
    /**
     * @override
     */
    [PropertySymbol.cloneNode](deep?: boolean): HTMLInputElement;
    /**
     * @override
     */
    dispatchEvent(event: Event): boolean;
}
//# sourceMappingURL=HTMLInputElement.d.ts.map