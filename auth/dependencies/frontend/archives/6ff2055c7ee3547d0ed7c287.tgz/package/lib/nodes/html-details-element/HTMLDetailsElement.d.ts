import Event from '../../event/Event.js';
import HTMLElement from '../html-element/HTMLElement.js';
import * as PropertySymbol from '../../PropertySymbol.js';
import type Attr from '../attr/Attr.js';
/**
 * HTMLDetailsElement
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/API/HTMLDetailsElement
 */
export default class HTMLDetailsElement extends HTMLElement {
    get ontoggle(): ((event: Event) => void) | null;
    set ontoggle(value: ((event: Event) => void) | null);
    /**
     * Returns the open attribute.
     */
    get open(): boolean;
    /**
     * Sets the open attribute.
     *
     * @param open New value.
     */
    set open(open: boolean);
    /**
     * @override
     */
    [PropertySymbol.onSetAttribute](attribute: Attr, replacedAttribute: Attr | null): void;
    /**
     * @override
     */
    [PropertySymbol.onRemoveAttribute](removedAttribute: Attr): void;
    /**
     * @override
     */
    dispatchEvent(event: Event): boolean;
}
//# sourceMappingURL=HTMLDetailsElement.d.ts.map