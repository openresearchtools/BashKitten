// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package internal

// Version is the current release version of the OpenTelemetry stdoutlog
// exporter in use.
const Version = "v0.22.0"
