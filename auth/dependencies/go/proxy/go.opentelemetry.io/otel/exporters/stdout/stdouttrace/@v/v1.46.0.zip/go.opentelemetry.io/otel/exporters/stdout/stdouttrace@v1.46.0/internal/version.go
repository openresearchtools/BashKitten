// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package internal

// Version is the current release version of the OpenTelemetry stdouttrace
// exporter in use.
const Version = "1.46.0"
