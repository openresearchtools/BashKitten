// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package internal

// Version is the current release version of the OpenTelemetry OTLP over HTTP/protobuf logs exporter in use.
const Version = "0.22.0"
