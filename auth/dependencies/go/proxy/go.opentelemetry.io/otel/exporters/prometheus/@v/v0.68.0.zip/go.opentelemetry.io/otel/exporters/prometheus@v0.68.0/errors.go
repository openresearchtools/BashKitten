// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package prometheus

import "errors"

// Sentinel errors for consistent error checks in tests.
var (
	errInvalidMetricType  = errors.New("invalid metric type")
	errInvalidMetric      = errors.New("invalid metric")
	errEHScaleBelowMin    = errors.New("exponential histogram scale below minimum supported")
	errBridgeNotSupported = errors.New(
		"metrics from the prometheus bridge are not supported in the prometheus exporter, and will be dropped",
	)
)
