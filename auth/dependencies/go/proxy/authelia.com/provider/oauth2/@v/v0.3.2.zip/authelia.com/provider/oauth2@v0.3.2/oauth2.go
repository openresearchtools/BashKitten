// SPDX-FileCopyrightText: 2026 Authelia
//
// SPDX-License-Identifier: Apache-2.0

package oauth2

import (
	"context"
	"net/http"
	"net/url"
	"time"

	"golang.org/x/text/language"

	"authelia.com/provider/oauth2/internal/consts"
	"authelia.com/provider/oauth2/token/jwt"
)

type TokenUse = TokenType

type TokenType string

type GrantType string

const (
	AccessToken             TokenType = consts.TokenTypeAccessToken
	RefreshToken            TokenType = consts.TokenTypeRefreshToken
	ClientRegistrationToken TokenType = consts.TokenTypeClientRegistrationToken
	DeviceCode              TokenType = consts.CodeDevice
	UserCode                TokenType = consts.CodeUser

	// PushedAuthorizeRequestContext represents the PAR context object
	PushedAuthorizeRequestContext TokenType = "par_context"

	AuthorizeCode TokenType = "authorize_code"
	IDToken       TokenType = "id_token"

	GrantTypeImplicit          GrantType = consts.GrantTypeImplicit
	GrantTypeRefreshToken      GrantType = consts.GrantTypeRefreshToken
	GrantTypeAuthorizationCode GrantType = consts.GrantTypeAuthorizationCode
	GrantTypePassword          GrantType = consts.GrantTypeResourceOwnerPasswordCredentials
	GrantTypeClientCredentials GrantType = consts.GrantTypeClientCredentials
	GrantTypeJWTBearer         GrantType = consts.GrantTypeOAuthJWTBearer
	GrantTypeDeviceCode        GrantType = consts.GrantTypeOAuthDeviceCode
	GrantTypeTokenExchange     GrantType = consts.GrantTypeOAuthTokenExchange

	// BearerAccessToken is the standard OAuth 2.0 Token type.
	BearerAccessToken string = "bearer"

	// DPoPAccessToken is the RFC 9449 token_type value for access tokens bound to a DPoP proof-of-possession key.
	DPoPAccessToken string = "DPoP"

	// RFC8693NAToken is the N/A token.
	RFC8693NAToken string = "N_A"
)

// Provider is an interface that enables you to write OAuth2 handlers with only a few lines of code.
// Check Fosite for an implementation of this interface.
type Provider interface {
	// NewAuthorizeRequest returns an AuthorizeRequest.
	//
	// The following specs must be considered in any implementation of this method:
	// * https://datatracker.ietf.org/doc/html/rfc6749#section-3.1
	//	 Extension response types MAY contain a space-delimited (%x20) list of
	//	 values, where the order of values does not matter (e.g., response
	//	 type "a b" is the same as "b a").  The meaning of such composite
	//	 response types is defined by their respective specifications.
	// * https://datatracker.ietf.org/doc/html/rfc6749#section-3.1.2
	//   The redirection endpoint URI MUST be an absolute URI as defined by
	//   [RFC3986] Section 4.3.  The endpoint URI MAY include an
	//   "application/x-www-form-urlencoded" formatted (per Appendix B) query
	//   component ([RFC3986] Section 3.4), which MUST be retained when adding
	//   additional query parameters.  The endpoint URI MUST NOT include a
	//   fragment component.
	// * https://datatracker.ietf.org/doc/html/rfc6749#section-3.1.2.2 (everything MUST be implemented)
	NewAuthorizeRequest(ctx context.Context, r *http.Request) (requester AuthorizeRequester, err error)

	// NewAuthorizeResponse iterates through all response type handlers and returns their result or
	// ErrUnsupportedResponseType if none of the handlers were able to handle it.
	//
	// The following specs must be considered in any implementation of this method:
	// * https://datatracker.ietf.org/doc/html/rfc6749#section-3.1.1
	//	 Extension response types MAY contain a space-delimited (%x20) list of
	//	 values, where the order of values does not matter (e.g., response
	//	 type "a b" is the same as "b a").  The meaning of such composite
	//	 response types is defined by their respective specifications.
	//	 If an authorization request is missing the "response_type" parameter,
	//	 or if the response type is not understood, the authorization server
	//	 MUST return an error response as described in Section 4.1.2.1.
	NewAuthorizeResponse(ctx context.Context, request AuthorizeRequester, session Session) (responder AuthorizeResponder, err error)

	// WriteAuthorizeError returns the error codes to the redirection endpoint or shows the error to the user, if no valid
	// redirect uri was given. Implements rfc6749#section-4.1.2.1
	//
	// The following specs must be considered in any implementation of this method:
	// * https://datatracker.ietf.org/doc/html/rfc6749#section-3.1.2
	//   The redirection endpoint URI MUST be an absolute URI as defined by
	//   [RFC3986] Section 4.3.  The endpoint URI MAY include an
	//   "application/x-www-form-urlencoded" formatted (per Appendix B) query
	//   component ([RFC3986] Section 3.4), which MUST be retained when adding
	//   additional query parameters.  The endpoint URI MUST NOT include a
	//   fragment component.
	// * https://datatracker.ietf.org/doc/html/rfc6749#section-4.1.2.1 (everything)
	// * https://datatracker.ietf.org/doc/html/rfc6749#section-3.1.2.2 (everything MUST be implemented)
	WriteAuthorizeError(ctx context.Context, rw http.ResponseWriter, request AuthorizeRequester, err error)

	// WriteAuthorizeResponse persists the AuthorizeSession in the store and redirects the user agent to the provided
	// redirect url or returns an error if storage failed.
	//
	// The following specs must be considered in any implementation of this method:
	// * https://datatracker.ietf.org/doc/html/rfc6749#rfc6749#section-4.1.2.1
	//   After completing its interaction with the resource owner, the
	//   authorization server directs the resource owner's user-agent back to
	//   the client.  The authorization server redirects the user-agent to the
	//   client's redirection endpoint previously established with the
	//   authorization server during the client registration process or when
	//   making the authorization request.
	// * https://datatracker.ietf.org/doc/html/rfc6749#section-3.1.2.2 (everything MUST be implemented)
	WriteAuthorizeResponse(ctx context.Context, rw http.ResponseWriter, request AuthorizeRequester, response AuthorizeResponder)

	// NewAccessRequest creates a new access request object and validates
	// various parameters.
	//
	// The following specs must be considered in any implementation of this method:
	// * https://datatracker.ietf.org/doc/html/rfc6749#section-3.2 (everything)
	// * https://datatracker.ietf.org/doc/html/rfc6749#section-3.2.1 (everything)
	//
	// Furthermore the registered handlers should implement their specs accordingly.
	NewAccessRequest(ctx context.Context, r *http.Request, session Session) (requester AccessRequester, err error)

	// NewAccessResponse creates a new access response and validates that access_token and token_type are set.
	//
	// The following specs must be considered in any implementation of this method:
	// https://datatracker.ietf.org/doc/html/rfc6749#section-5.1
	NewAccessResponse(ctx context.Context, request AccessRequester) (responder AccessResponder, err error)

	// WriteAccessError writes an access request error response.
	//
	// The following specs must be considered in any implementation of this method:
	// * https://datatracker.ietf.org/doc/html/rfc6749#section-5.2 (everything)
	WriteAccessError(ctx context.Context, rw http.ResponseWriter, request AccessRequester, err error)

	// WriteAccessResponse writes the access response.
	//
	// The following specs must be considered in any implementation of this method:
	// https://datatracker.ietf.org/doc/html/rfc6749#section-5.1
	WriteAccessResponse(ctx context.Context, rw http.ResponseWriter, request AccessRequester, response AccessResponder)

	// NewRevocationRequest handles incoming token revocation requests and validates various parameters.
	//
	// The following specs must be considered in any implementation of this method:
	// https://datatracker.ietf.org/doc/html/rfc7009#section-2.1
	NewRevocationRequest(ctx context.Context, r *http.Request) (err error)

	// WriteRevocationResponse writes the revoke response.
	//
	// The following specs must be considered in any implementation of this method:
	// https://datatracker.ietf.org/doc/html/rfc7009#section-2.2
	WriteRevocationResponse(ctx context.Context, rw http.ResponseWriter, err error)

	// IntrospectToken returns token metadata, if the token is valid. Tokens generated by the authorization endpoint,
	// such as the authorization code, can not be introspected.
	IntrospectToken(ctx context.Context, token string, tokenUse TokenUse, session Session, scope ...string) (actualTokenUse TokenUse, requester AccessRequester, err error)

	// NewIntrospectionRequest initiates token introspection as defined in
	//https://datatracker.ietf.org/doc/html/rfc7662#section-2.1
	NewIntrospectionRequest(ctx context.Context, r *http.Request, session Session) (responder IntrospectionResponder, err error)

	// WriteIntrospectionError responds with an error if token introspection failed as defined in
	//https://datatracker.ietf.org/doc/html/rfc7662#section-2.3
	WriteIntrospectionError(ctx context.Context, rw http.ResponseWriter, err error)

	// WriteIntrospectionResponse responds with token metadata discovered by token introspection as defined in
	//https://datatracker.ietf.org/doc/html/rfc7662#section-2.2
	WriteIntrospectionResponse(ctx context.Context, rw http.ResponseWriter, response IntrospectionResponder)

	// NewPushedAuthorizeRequest validates the request and produces an AuthorizeRequester object that can be stored
	NewPushedAuthorizeRequest(ctx context.Context, r *http.Request) (requester AuthorizeRequester, err error)

	// NewPushedAuthorizeResponse executes the handlers and builds the response
	NewPushedAuthorizeResponse(ctx context.Context, request AuthorizeRequester, session Session) (responder PushedAuthorizeResponder, err error)

	// WritePushedAuthorizeResponse writes the PAR response
	WritePushedAuthorizeResponse(ctx context.Context, rw http.ResponseWriter, request AuthorizeRequester, responder PushedAuthorizeResponder)

	// WritePushedAuthorizeError writes the PAR error
	WritePushedAuthorizeError(ctx context.Context, rw http.ResponseWriter, request AuthorizeRequester, err error)

	// NewRFC862DeviceAuthorizeRequest validate the OAuth 2.0 Device Authorization Flow Request
	//
	// The following specs must be considered in any implementation of this method:
	// * https://www.rfc-editor.org/rfc/rfc8628#section-3.1 (everything MUST be implemented)
	// Parameters sent without a value MUST be treated as if they were
	// omitted from the request.  The authorization server MUST ignore
	// unrecognized request parameters.  Request and response parameters
	// MUST NOT be included more than once.
	NewRFC862DeviceAuthorizeRequest(ctx context.Context, r *http.Request) (requester DeviceAuthorizeRequester, err error)

	// NewRFC862DeviceAuthorizeResponse persists the DeviceCodeSession and UserCodeSession in the store
	//
	// The following specs must be considered in any implementation of this method:
	// * https://www.rfc-editor.org/rfc/rfc8628#section-3.2 (everything MUST be implemented)
	// In response, the authorization server generates a unique device
	// verification code and an end-user code that are valid for a limited
	// time
	NewRFC862DeviceAuthorizeResponse(ctx context.Context, request DeviceAuthorizeRequester, session Session) (responder DeviceAuthorizeResponder, err error)

	// WriteRFC862DeviceAuthorizeResponse return to the user both codes and
	// some configuration information in a JSON formatted manner
	//
	// The following specs must be considered in any implementation of this method:
	// * https://www.rfc-editor.org/rfc/rfc8628#section-3.2 (everything MUST be implemented)
	// Response is a HTTP response body using the
	// "application/json" format [RFC8259] with a 200 (OK) status code.
	WriteRFC862DeviceAuthorizeResponse(ctx context.Context, rw http.ResponseWriter, request DeviceAuthorizeRequester, response DeviceAuthorizeResponder)

	// WriteRFC8628UserAuthorizeResponse returns the device grant user verification result in a JSON formatted manner.
	//
	// The following specs must be considered in any implementation of this method:
	// * https://www.rfc-editor.org/rfc/rfc8628#section-3.3 (everything MUST be implemented)
	// Response is a HTTP response body using the
	// "application/json" format [RFC8259] with a 200 (OK) status code.
	WriteRFC8628UserAuthorizeResponse(cxt context.Context, rw http.ResponseWriter, request DeviceAuthorizeRequester, response DeviceUserAuthorizeResponder)

	// WriteRFC8628UserAuthorizeError returns the device grant user verification error in a JSON formatted manner.
	//
	// The following specs must be considered in any implementation of this method:
	// * https://www.rfc-editor.org/rfc/rfc8628#section-3.3 (everything MUST be implemented)
	// Response is a HTTP response body using the
	// "application/json" format [RFC8259] with a 200 (OK) status code.
	WriteRFC8628UserAuthorizeError(_ context.Context, rw http.ResponseWriter, request DeviceAuthorizeRequester, err error)

	// NewRFC8628UserAuthorizeRequest validate the OAuth 2.0 Device Authorization Flow - User interaction Request
	//
	// The following specs must be considered in any implementation of this method:
	// * https://www.rfc-editor.org/rfc/rfc8628#section-3.3 (everything MUST be implemented)
	// Parameters sent without a value MUST be treated as if they were
	// omitted from the request. The authorization server MUST ignore
	// unrecognized request parameters. Request and response parameters
	// MUST NOT be included more than once.
	NewRFC8628UserAuthorizeRequest(ctx context.Context, r *http.Request) (requester DeviceAuthorizeRequester, err error)

	// NewRFC8628UserAuthorizeResponse persists the DeviceCodeSession and UserCodeSession in the store
	//
	// The following specs must be considered in any implementation of this method:
	// * https://www.rfc-editor.org/rfc/rfc8628#section-3.2 (everything MUST be implemented)
	// In response, the authorization server generates a unique device
	// verification code and an end-user code that are valid for a limited
	// time
	NewRFC8628UserAuthorizeResponse(ctx context.Context, request DeviceAuthorizeRequester, session Session) (responder DeviceUserAuthorizeResponder, err error)

	// NewRFC7591ClientRegistrationRequest validates the request and produces a ClientRegistrationRequester.
	//
	// The following specs must be considered in any implementation of this method:
	// * https://datatracker.ietf.org/doc/html/rfc7591#section-3.1 (everything MUST be implemented)
	NewRFC7591ClientRegistrationRequest(ctx context.Context, r *http.Request) (requester ClientRegistrationRequester, err error)

	// NewRFC7591ClientRegistrationResponse executes the configured client registration endpoint handlers and builds
	// the response.
	//
	// The following specs must be considered in any implementation of this method:
	// * https://datatracker.ietf.org/doc/html/rfc7591#section-3.2.1 (everything MUST be implemented)
	NewRFC7591ClientRegistrationResponse(ctx context.Context, requester ClientRegistrationRequester) (responder ClientRegistrationResponder, err error)

	// WriteRFC7591ClientRegistrationResponse writes the client registration response with a 201 (Created) status.
	//
	// The following specs must be considered in any implementation of this method:
	// * https://datatracker.ietf.org/doc/html/rfc7591#section-3.2.1 (everything MUST be implemented)
	WriteRFC7591ClientRegistrationResponse(ctx context.Context, rw http.ResponseWriter, requester ClientRegistrationRequester, responder ClientRegistrationResponder)

	// WriteRFC7591ClientRegistrationError writes a client registration endpoint error response.
	//
	// The following specs must be considered in any implementation of this method:
	// * https://datatracker.ietf.org/doc/html/rfc7591#section-3.2.2 (everything MUST be implemented)
	WriteRFC7591ClientRegistrationError(ctx context.Context, rw http.ResponseWriter, requester ClientRegistrationRequester, err error)

	// NewRFC7592ClientConfigurationRequest validates the request and produces a ClientConfigurationRequester.
	//
	// The following specs must be considered in any implementation of this method:
	// * https://datatracker.ietf.org/doc/html/rfc7592#section-2 (everything MUST be implemented)
	NewRFC7592ClientConfigurationRequest(ctx context.Context, r *http.Request) (requester ClientConfigurationRequester, err error)

	// NewRFC7592ClientConfigurationResponse executes the configured client configuration endpoint handlers and
	// builds the response.
	//
	// The following specs must be considered in any implementation of this method:
	// * https://datatracker.ietf.org/doc/html/rfc7592#section-2 (everything MUST be implemented)
	NewRFC7592ClientConfigurationResponse(ctx context.Context, requester ClientConfigurationRequester) (responder ClientConfigurationResponder, err error)

	// WriteRFC7592ClientConfigurationResponse writes the client configuration response. A 204 (No Content) status,
	// written for a successful DELETE, carries no body.
	//
	// The following specs must be considered in any implementation of this method:
	// * https://datatracker.ietf.org/doc/html/rfc7592#section-2.3 (everything MUST be implemented)
	WriteRFC7592ClientConfigurationResponse(ctx context.Context, rw http.ResponseWriter, requester ClientConfigurationRequester, responder ClientConfigurationResponder)

	// WriteRFC7592ClientConfigurationError writes a client configuration endpoint error response, mapping to the
	// status codes described in RFC 7592 Section 3: 401 (with a 'WWW-Authenticate: Bearer' header) for a missing or
	// invalid registration access token, 404 for an unknown client_id, and 405 for an unsupported method.
	//
	// The following specs must be considered in any implementation of this method:
	// * https://datatracker.ietf.org/doc/html/rfc7592#section-3 (everything MUST be implemented)
	WriteRFC7592ClientConfigurationError(ctx context.Context, rw http.ResponseWriter, requester ClientConfigurationRequester, err error)
}

// IntrospectionResponder is the response object that will be returned when token introspection was successful,
// for example when the client is allowed to perform token introspection. Refer to
// https://datatracker.ietf.org/doc/html/rfc7662#section-2.2 for more details.
type IntrospectionResponder interface {
	// IsActive returns true if the introspected token is active and false otherwise.
	IsActive() (active bool)

	// GetAccessRequester returns the AccessRequester which returns nil when IsActive() is false and the original access request object otherwise.
	GetAccessRequester() (requester AccessRequester)

	// GetTokenUse optionally returns the type of the token that was introspected. This could be "access_token", "refresh_token",
	// or if the type can not be determined an empty string.
	GetTokenUse() (tokenUse TokenUse)

	// GetAccessTokenType optionally returns the type of the access token that was introspected. This could be "bearer", "mac",
	// or empty string if the type of the token is refresh token.
	GetAccessTokenType() (tokenType string)

	// ToMap returns the audience values for this introspection for use with signed introspection responses, and map
	// values for this introspection regardless of what kind of introspection response.
	ToMap() (audience []string, introspection map[string]any)
}

// IntrospectionResponderClient is an IntrospectionResponder which reports the client the introspection response is
// sent to, being the caller rather than the client the introspected token was issued to. RFC 9701 Section 6 bases the
// response signing and encryption parameters on that client's registered metadata, and Section 5 requires 'aud' to
// identify it.
//
// A responder which does not implement this is written as plain JSON: the parameters cannot be resolved from any
// other party without keying the response to one that is not receiving it.
type IntrospectionResponderClient interface {
	IntrospectionResponder

	// GetClient returns the client the introspection response is sent to.
	GetClient() (client Client)
}

// Requester is an abstract interface for handling requests in Fosite.
type Requester interface {
	// SetID sets the unique identifier.
	SetID(id string)

	// GetID returns a unique identifier.
	GetID() (id string)

	// GetRequestedAt returns the time the request was created.
	GetRequestedAt() (requestedAt time.Time)

	// SetRequestedAt sets the time the request was created.
	SetRequestedAt(rat time.Time)

	// GetClient returns the request's client.
	GetClient() (client Client)

	// GetRequestedScopes returns the request's scopes.
	GetRequestedScopes() (scopes Arguments)

	// GetRequestedAudience returns the requested audiences for this request.
	GetRequestedAudience() (audience Arguments)

	// SetRequestedScopes sets the request's scopes.
	SetRequestedScopes(scopes Arguments)

	// SetRequestedAudience sets the requested audience.
	SetRequestedAudience(audience Arguments)

	// AppendRequestedScope appends a scope to the request.
	AppendRequestedScope(scope string)

	// GetGrantedScopes returns all granted scopes.
	GetGrantedScopes() (grantedScopes Arguments)

	// GetGrantedAudience returns all granted audiences.
	GetGrantedAudience() (grantedAudience Arguments)

	// GrantScope marks a request's scope as granted.
	GrantScope(scope string)

	// GrantAudience marks a request's audience as granted.
	GrantAudience(audience string)

	// GetRequestedResource returns the requested resource indicators (RFC 8707) for this request.
	GetRequestedResource() (resource Arguments)

	// SetRequestedResource sets the requested resource indicators.
	SetRequestedResource(resource Arguments)

	// GetGrantedResource returns all granted resource indicators.
	GetGrantedResource() (grantedResource Arguments)

	// GrantResource marks a request's resource indicator as granted.
	GrantResource(resource string)

	// GetSession returns a pointer to the request's session or nil if none is set.
	GetSession() (session Session)

	// SetSession sets the request's session pointer.
	SetSession(session Session)

	// GetRequestForm returns the request's form input.
	GetRequestForm() (form url.Values)

	// Merge merges the argument into the method receiver.
	Merge(requester Requester)

	// Sanitize returns a sanitized clone of the request which can be used for storage.
	Sanitize(allowedParameters []string) (sanitized Requester)
}

// AccessRequester is a token endpoint's request context.
type AccessRequester interface {
	// GetGrantTypes returns the requests grant type.
	GetGrantTypes() (grantTypes Arguments)

	Requester
}

// RefreshTokenAccessRequester is an extended AccessRequester implementation that allows preserving
// the original Requester.
type RefreshTokenAccessRequester interface {
	// SanitizeRestoreRefreshTokenOriginalRequester returns a sanitized copy of this Requester and mutates the relevant
	// values from the provided Requester which is the original refresh token session Requester.
	SanitizeRestoreRefreshTokenOriginalRequester(requester Requester) (sanitized Requester)

	AccessRequester
}

// AuthorizeRequester is an authorize endpoint's request context.
type AuthorizeRequester interface {
	// GetResponseTypes returns the requested response types
	GetResponseTypes() (responseTypes Arguments)

	// SetResponseTypeHandled marks a response_type (e.g. token or code) as handled indicating that the response type
	// is supported.
	SetResponseTypeHandled(responseType string)

	// DidHandleAllResponseTypes returns if all requested response types have been handled correctly
	DidHandleAllResponseTypes() (didHandle bool)

	// GetRedirectURI returns the requested redirect URI.
	GetRedirectURI() (uri *url.URL)

	// IsRedirectURIValid returns false if the redirect is not rfc-conform (i.e. missing client, not on white list,
	// or malformed)
	IsRedirectURIValid() (isValid bool)

	// GetState returns the request's state.
	GetState() (state string)

	// GetResponseMode returns response_mode of the authorization request.
	GetResponseMode() (responseMode ResponseModeType)

	// SetDefaultResponseMode sets default response mode for a response type in a flow.
	SetDefaultResponseMode(responseMode ResponseModeType)

	// GetDefaultResponseMode gets default response mode for a response type in a flow.
	GetDefaultResponseMode() (responseMode ResponseModeType)

	Requester
}

// DeviceAuthorizeRequester is a device authorization endpoint's request context.
type DeviceAuthorizeRequester interface {
	// SetDeviceCodeSignature set the device code signature.
	SetDeviceCodeSignature(signature string)

	// GetDeviceCodeSignature returns the device code signature.
	GetDeviceCodeSignature() (signature string)

	// SetUserCodeSignature set the user code signature.
	SetUserCodeSignature(signature string)

	// GetUserCodeSignature returns the user code signature.
	GetUserCodeSignature() (signature string)

	SetStatus(status DeviceAuthorizeStatus)

	GetStatus() (status DeviceAuthorizeStatus)

	SetLastChecked(lastChecked time.Time)

	GetLastChecked() (lastChecked time.Time)

	Requester
}

// AccessResponder is a token endpoint's response.
type AccessResponder interface {
	// SetExtra sets a key value pair for the access response.
	SetExtra(key string, value any)

	// GetExtra returns a key's value.
	GetExtra(key string) (extra any)

	SetExpiresIn(time.Duration)

	SetScopes(scopes Arguments)

	// SetAccessToken sets the responses mandatory access token.
	SetAccessToken(token string)

	// SetTokenType set's the responses mandatory token type.
	SetTokenType(tokenType string)

	// GetAccessToken returns the responses access token.
	GetAccessToken() (token string)

	// GetTokenType returns the responses token type.
	GetTokenType() (token string)

	// ToMap converts the response to a map.
	ToMap() (values map[string]any)
}

// AuthorizeResponder is an authorization endpoint's response.
type AuthorizeResponder interface {
	// GetCode returns the response's authorize code if set.
	GetCode() (code string)

	// GetHeader returns the response's header.
	GetHeader() (header http.Header)

	// AddHeader adds a header key value pair to the response.
	AddHeader(key, value string)

	// GetParameters returns the response's parameters.
	GetParameters() (query url.Values)

	// AddParameter adds key value pair to the response.
	AddParameter(key, value string)
}

// PushedAuthorizeResponder is the response object for PAR.
type PushedAuthorizeResponder interface {
	// GetRequestURI returns the request_uri
	GetRequestURI() (uri string)

	// SetRequestURI sets the request_uri.
	SetRequestURI(requestURI string)

	// GetExpiresIn gets the expires_in.
	GetExpiresIn() (expires int)

	// SetExpiresIn sets the expires_in.
	SetExpiresIn(seconds int)

	// GetHeader returns the response's header.
	GetHeader() (header http.Header)

	// AddHeader adds a header key value pair to the response.
	AddHeader(key, value string)

	// SetExtra sets a key value pair for the response.
	SetExtra(key string, value any)

	// GetExtra returns a key's value.
	GetExtra(key string) (extra any)

	// ToMap converts the response to a map.
	ToMap() (values map[string]any)
}

type DeviceAuthorizeResponder interface {
	GetDeviceCode() string

	SetDeviceCode(code string)

	// GetHeader returns the response's header.
	GetHeader() (header http.Header)

	// AddHeader adds an header key value pair to the response.
	AddHeader(key, value string)

	GetUserCode() (code string)

	SetUserCode(code string)

	GetVerificationURI() (uri string)

	SetVerificationURI(uri string)

	GetVerificationURIComplete() (completeURI string)

	SetVerificationURIComplete(uri string)

	GetExpiresIn() (expires int64)

	SetExpiresIn(seconds int64)

	GetInterval() (interval int)

	SetInterval(seconds int)

	// SetExtra sets a key value pair for the access response.
	SetExtra(key string, value any)

	// GetExtra returns a key's value.
	GetExtra(key string) (extra any)

	// ToMap converts the response to a map.
	ToMap() (values map[string]any)
}

// DeviceUserAuthorizeResponder is device grant user verification endpoint response.
type DeviceUserAuthorizeResponder interface {
	// GetHeader returns the response's header.
	GetHeader() (header http.Header)

	// AddHeader adds an header key value pair to the response.
	AddHeader(key, value string)

	// GetParameters returns the response's parameters.
	GetParameters() (query url.Values)

	// AddParameter adds key value pair to the response.
	AddParameter(key, value string)

	// GetStatus returns the device grant user verification status.
	GetStatus() (status string)

	// SetStatus sets the device grant user verification status.
	SetStatus(status string)

	// SetExtra sets a key value pair for the access response.
	SetExtra(key string, value any)

	// GetExtra returns a key's value.
	GetExtra(key string) (extra any)

	// ToMap converts the response to a map.
	ToMap() (values map[string]any)
}

// G11NContext is the globalization context.
type G11NContext interface {
	// GetLang returns the current language in the context.
	GetLang() (lang language.Tag)
}

type RFC8693TokenType interface {
	GetName(ctx context.Context) (name string)

	GetType(ctx context.Context) (tokenType string)
}

// IDTokenValidationOpts are the resolved options for TokenValidationStrategy.ValidateIDToken.
type IDTokenValidationOpts struct {
	// AllowExpired permits an ID Token whose 'exp' claim is in the past to validate successfully.
	AllowExpired bool

	// AllowUnverified skips signature verification and all claim validation.
	AllowUnverified bool
}

// IDTokenValidationOpt configures IDTokenValidationOpts.
type IDTokenValidationOpt func(opts *IDTokenValidationOpts)

// NewIDTokenValidationOpts resolves the given options. Implementations of TokenValidationStrategy should use this
// rather than looping over the options themselves.
func NewIDTokenValidationOpts(opts ...IDTokenValidationOpt) (o *IDTokenValidationOpts) {
	o = &IDTokenValidationOpts{}

	for _, opt := range opts {
		opt(o)
	}

	return o
}

// WithAllowExpired permits an ID Token with an 'exp' claim in the past to validate successfully. It narrowly disables
// the expiration check; the 'iat' and 'nbf' claims remain enforced when present, as do signature verification and
// every other check.
//
// This exists for OpenID Connect RP-Initiated Logout, where the 'id_token_hint' identifies the session the Relying
// Party is asking to end and is therefore expected to be expired.
func WithAllowExpired() IDTokenValidationOpt {
	return func(opts *IDTokenValidationOpts) {
		opts.AllowExpired = true
	}
}

// WithAllowUnverified decodes the token WITHOUT verifying its signature and WITHOUT validating any claim.
//
// The result is untrusted. It must only be used to discover which client a token was issued to, so that the token can
// then be validated properly against that client's keys. Never return claims obtained this way to a caller and never
// make an authorization decision based on them.
func WithAllowUnverified() IDTokenValidationOpt {
	return func(opts *IDTokenValidationOpts) {
		opts.AllowUnverified = true
	}
}

// TokenValidationStrategy validates tokens presented to the authorization server by a client, as opposed to tokens
// the authorization server itself issued and stored.
type TokenValidationStrategy interface {
	// ValidateIDToken decodes and verifies an ID Token, returning its claims. Application-specific claim policy
	// ('iss' and 'aud' in particular) is the caller's responsibility; see DefaultIDTokenValidationStrategy.
	//
	// The request is always supplied, but it may carry no client: a caller which does not yet know the client, such
	// as one decoding a token with WithAllowUnverified in order to discover it, supplies an otherwise empty Requester.
	// Implementations must therefore tolerate Requester.GetClient returning nil.
	ValidateIDToken(ctx context.Context, request Requester, token string, opts ...IDTokenValidationOpt) (claims jwt.MapClaims, err error)
}

// BackChannelLogoutTokenStrategy generates the Logout Tokens delivered to Relying Parties for OpenID Connect
// Back-Channel Logout 1.0.
//
// See: https://openid.net/specs/openid-connect-backchannel-1_0.html
type BackChannelLogoutTokenStrategy interface {
	// GenerateBackChannelLogoutToken returns a signed Logout Token for the given client. The audience should
	// name exactly the client the token is delivered to, so that each Relying Party receives a token with its
	// own 'jti'.
	GenerateBackChannelLogoutToken(ctx context.Context, client Client, lifespan time.Duration, subject, sid string, audience []string, extra map[string]any) (token string, err error)
}
