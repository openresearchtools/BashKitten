// SPDX-FileCopyrightText: 2026 Authelia
//
// SPDX-License-Identifier: Apache-2.0

package oauth2

import (
	"context"
	"time"

	"github.com/pkg/errors"

	"authelia.com/provider/oauth2"
	"authelia.com/provider/oauth2/internal/consts"
	"authelia.com/provider/oauth2/storage"
	"authelia.com/provider/oauth2/token/jwt"
	"authelia.com/provider/oauth2/x/errorsx"
)

type CodeTokenEndpointHandler interface {
	ValidateGrantTypes(ctx context.Context, request oauth2.AccessRequester) (err error)
	ValidateCodeAndSession(ctx context.Context, request oauth2.AccessRequester, authorizeRequest oauth2.Requester, code string) (err error)
	GetCodeAndSession(ctx context.Context, request oauth2.AccessRequester) (code string, signature string, r oauth2.Requester, err error)
	UpdateLastChecked(ctx context.Context, request oauth2.AccessRequester, authorizeRequest oauth2.Requester) (err error)
	InvalidateSession(ctx context.Context, signature string, request oauth2.Requester) error
	CanSkipClientAuth(ctx context.Context, request oauth2.AccessRequester) bool
	CanHandleTokenEndpointRequest(ctx context.Context, request oauth2.AccessRequester) bool
	DeviceCodeSignature(ctx context.Context, code string) (signature string, err error)
}

type GenericCodeTokenEndpointHandler struct {
	CodeTokenEndpointHandler

	AccessTokenStrategy    AccessTokenStrategy
	RefreshTokenStrategy   RefreshTokenStrategy
	CoreStorage            CoreStorage
	TokenRevocationStorage TokenRevocationStorage
	Config                 interface {
		oauth2.AccessTokenLifespanProvider
		oauth2.RefreshTokenLifespanProvider
		oauth2.RefreshTokenScopesProvider
	}
}

// HandleTokenEndpointRequest handles verifying the access request.
//
//nolint:gocyclo
func (c *GenericCodeTokenEndpointHandler) HandleTokenEndpointRequest(ctx context.Context, request oauth2.AccessRequester) (err error) {
	if !c.CanHandleTokenEndpointRequest(ctx, request) {
		return errorsx.WithStack(errorsx.WithStack(oauth2.ErrUnknownRequest))
	}

	if err = c.ValidateGrantTypes(ctx, request); err != nil {
		return err
	}

	var (
		code            string
		deviceRequester oauth2.Requester
	)

	if code, _, deviceRequester, err = c.GetCodeAndSession(ctx, request); errors.Is(err, oauth2.ErrInvalidatedDeviceCode) {
		if deviceRequester == nil {
			return oauth2.ErrServerError.
				WithHint("Misconfigured code lead to an error that prohibited the OAuth 2.0 Framework from processing this request.").
				WithDebug(`getCodeSession must return a value for "oauth2.Requester" when returning "ErrInvalidatedAuthorizeCode" or "ErrInvalidatedDeviceCode".`)
		}

		hint := "The authorization code has already been used."
		return errorsx.WithStack(oauth2.ErrInvalidGrant.WithHint(hint))
	} else if errors.Is(err, oauth2.ErrInvalidatedAuthorizeCode) {
		if deviceRequester == nil {
			return oauth2.ErrServerError.
				WithHint("Misconfigured code lead to an error that prohibited the OAuth 2.0 Framework from processing this request.").
				WithDebug(`getCodeSession must return a value for "oauth2.Requester" when returning "ErrInvalidatedAuthorizeCode" or "ErrInvalidatedDeviceCode".`)
		}

		return revokeCodeGrant(ctx, c.TokenRevocationStorage, deviceRequester.GetID())
	} else if errors.Is(err, oauth2.ErrAuthorizationPending) || errors.Is(err, oauth2.ErrAccessDenied) ||
		errors.Is(err, oauth2.ErrDeviceExpiredToken) || errors.Is(err, oauth2.ErrSlowDown) ||
		errors.Is(err, oauth2.ErrInvalidGrant) {
		return errorsx.WithStack(err)
	} else if errors.Is(err, oauth2.ErrNotFound) {
		return errorsx.WithStack(oauth2.ErrInvalidGrant.WithWrap(err).WithDebugError(err))
	} else if err != nil {
		return errorsx.WithStack(oauth2.ErrServerError.WithWrap(err).WithDebugError(err))
	}

	// Update last checked if there is error validating / processing the request.
	defer func() {
		if err != nil && deviceRequester != nil {
			_ = c.UpdateLastChecked(ctx, request, deviceRequester)
		}
	}()

	if err = c.ValidateCodeAndSession(ctx, request, deviceRequester, code); err != nil {
		return errorsx.WithStack(err)
	}

	request.SetRequestedScopes(deviceRequester.GetRequestedScopes())
	request.SetRequestedAudience(deviceRequester.GetRequestedAudience())
	request.SetRequestedResource(deviceRequester.GetRequestedResource())

	// The authorization server MUST ensure that the authorization code was issued to the authenticated
	// confidential client, or if the client is public, ensure that the
	// code was issued to "client_id" in the request,
	if deviceRequester.GetClient().GetID() != request.GetClient().GetID() {
		return errorsx.WithStack(oauth2.ErrInvalidGrant.WithHint("The OAuth 2.0 Client ID from this request does not match the one from the authorize request."))
	}

	// ensure that the "redirect_uri" parameter is present if the
	// "redirect_uri" parameter was included in the initial authorization
	// request as described in Section 4.1.1, and if included ensure that
	// their values are identical.
	forcedRedirectURI := deviceRequester.GetRequestForm().Get(consts.FormParameterRedirectURI)
	if forcedRedirectURI != "" && forcedRedirectURI != request.GetRequestForm().Get(consts.FormParameterRedirectURI) {
		return errorsx.WithStack(oauth2.ErrInvalidGrant.WithHint("The 'redirect_uri' from this request does not match the one from the authorize request."))
	}

	// Checking of POST client_id skipped, because:
	// If the client type is confidential or the client was issued client
	// credentials (or assigned other authentication requirements), the
	// client MUST authenticate with the authorization server as described
	// in Section 3.2.1.
	request.SetSession(deviceRequester.GetSession())
	request.SetID(deviceRequester.GetID())

	gt := oauth2.GrantTypeAuthorizationCode

	if request.GetGrantTypes().ExactOne(string(oauth2.GrantTypeDeviceCode)) {
		gt = oauth2.GrantTypeDeviceCode
	}

	var lifespan time.Duration

	lifespan = oauth2.GetEffectiveLifespan(request.GetClient(), gt, oauth2.AccessToken, c.Config.GetAccessTokenLifespan(ctx))

	request.GetSession().SetExpiresAt(oauth2.AccessToken, time.Now().UTC().Add(lifespan).Truncate(jwt.TimePrecision))

	lifespan = oauth2.GetEffectiveLifespan(request.GetClient(), gt, oauth2.RefreshToken, c.Config.GetRefreshTokenLifespan(ctx))

	if lifespan > -1 {
		request.GetSession().SetExpiresAt(oauth2.RefreshToken, time.Now().UTC().Add(lifespan).Truncate(jwt.TimePrecision))
	}

	return nil
}

// PopulateTokenEndpointResponse handles populating the access response.
//
//nolint:gocyclo
func (c *GenericCodeTokenEndpointHandler) PopulateTokenEndpointResponse(ctx context.Context, request oauth2.AccessRequester, response oauth2.AccessResponder) (err error) {
	if !c.CanHandleTokenEndpointRequest(ctx, request) {
		return errorsx.WithStack(oauth2.ErrUnknownRequest)
	}

	// This re-read can observe a replay that HandleTokenEndpointRequest could not: two requests bearing the same code
	// both clear that phase while the code is still active, and only one of them goes on to invalidate it. The loser
	// arrives here, so this must reach the same conclusion the first phase would have rather than reporting every
	// error as a server fault, which would answer a replay with a 500 and skip the revocation RFC 6749 Section 4.1.2
	// mandates.
	code, signature, ar, err := c.GetCodeAndSession(ctx, request)
	if err != nil {
		switch {
		case errors.Is(err, oauth2.ErrInvalidatedDeviceCode):
			return errorsx.WithStack(oauth2.ErrInvalidGrant.WithHint("The authorization code has already been used."))
		case errors.Is(err, oauth2.ErrInvalidatedAuthorizeCode):
			if ar == nil {
				return errorsx.WithStack(oauth2.ErrServerError.
					WithHint("Misconfigured code lead to an error that prohibited the OAuth 2.0 Framework from processing this request.").
					WithDebug(`getCodeSession must return a value for "oauth2.Requester" when returning "ErrInvalidatedAuthorizeCode" or "ErrInvalidatedDeviceCode".`))
			}

			return revokeCodeGrant(ctx, c.TokenRevocationStorage, ar.GetID())
		case errors.Is(err, oauth2.ErrNotFound):
			return errorsx.WithStack(oauth2.ErrInvalidGrant.WithWrap(err).WithDebugError(err))
		default:
			return errorsx.WithStack(oauth2.ErrServerError.WithWrap(err).WithDebugError(err))
		}
	} else if err = c.ValidateCodeAndSession(ctx, request, ar, code); err != nil {
		// This needs to happen after store retrieval for the session to be hydrated properly
		return errorsx.WithStack(oauth2.ErrInvalidRequest.WithWrap(err).WithDebugError(err))
	}

	for _, scope := range ar.GetGrantedScopes() {
		request.GrantScope(scope)
	}

	for _, audience := range ar.GetGrantedAudience() {
		request.GrantAudience(audience)
	}

	for _, resource := range ar.GetGrantedResource() {
		request.GrantResource(resource)
	}

	var (
		access, accessSignature   string
		refresh, refreshSignature string
	)

	if access, accessSignature, err = c.AccessTokenStrategy.GenerateAccessToken(ctx, request); err != nil {
		return errorsx.WithStack(oauth2.ErrServerError.WithWrap(err).WithDebugError(err))
	}

	if c.canIssueRefreshToken(ctx, ar) {
		if refresh, refreshSignature, err = c.RefreshTokenStrategy.GenerateRefreshToken(ctx, request); err != nil {
			return errorsx.WithStack(oauth2.ErrServerError.WithWrap(err).WithDebugError(err))
		}
	}

	if ctx, err = storage.MaybeBeginTx(ctx, c.CoreStorage); err != nil {
		return errorsx.WithStack(oauth2.ErrServerError.WithWrap(err).WithDebugError(err))
	}

	defer func() {
		if err != nil {
			if rollBackTxnErr := storage.MaybeRollbackTx(ctx, c.CoreStorage); rollBackTxnErr != nil {
				err = errorsx.WithStack(oauth2.ErrServerError.WithWrap(err).WithDebugf("error: %s; rollback error: %s", err, rollBackTxnErr))
			}
		}
	}()

	if err = c.InvalidateSession(ctx, signature, ar); err != nil {
		return errorsx.WithStack(oauth2.ErrServerError.WithWrap(err).WithDebugError(err))
	}

	if err = c.CoreStorage.CreateAccessTokenSession(ctx, accessSignature, request.Sanitize([]string{})); err != nil {
		return errorsx.WithStack(oauth2.ErrServerError.WithWrap(err).WithDebugError(err))
	} else if refreshSignature != "" {
		if err = c.CoreStorage.CreateRefreshTokenSession(ctx, refreshSignature, accessSignature, request.Sanitize([]string{})); err != nil {
			return errorsx.WithStack(oauth2.ErrServerError.WithWrap(err).WithDebugError(err))
		}
	}

	response.SetAccessToken(access)
	response.SetTokenType(oauth2.BearerAccessToken)
	atLifespan := oauth2.GetEffectiveLifespan(request.GetClient(), oauth2.GrantTypeAuthorizationCode, oauth2.AccessToken, c.Config.GetAccessTokenLifespan(ctx))
	response.SetExpiresIn(getExpiresIn(request, oauth2.AccessToken, atLifespan, time.Now().UTC()))
	response.SetScopes(request.GetGrantedScopes())

	if refresh != "" {
		response.SetExtra(consts.AccessResponseRefreshToken, refresh)
	}

	if err = storage.MaybeCommitTx(ctx, c.CoreStorage); err != nil {
		return errorsx.WithStack(oauth2.ErrServerError.WithWrap(err).WithDebugError(err))
	}

	return nil
}

func (c *GenericCodeTokenEndpointHandler) canIssueRefreshToken(ctx context.Context, request oauth2.Requester) (issue bool) {
	scope := c.Config.GetRefreshTokenScopes(ctx)

	// Require one of the refresh token scopes, if set.
	if len(scope) > 0 && !request.GetGrantedScopes().HasOneOf(scope...) {
		return false
	}

	// Do not issue a refresh token to clients that cannot use the refresh token grant type.
	if !request.GetClient().GetGrantTypes().Has(consts.GrantTypeRefreshToken) {
		return false
	}

	return true
}

func (c *GenericCodeTokenEndpointHandler) CanSkipClientAuth(ctx context.Context, request oauth2.AccessRequester) (skip bool) {
	return c.CodeTokenEndpointHandler.CanSkipClientAuth(ctx, request)
}

func (c *GenericCodeTokenEndpointHandler) CanHandleTokenEndpointRequest(ctx context.Context, request oauth2.AccessRequester) (handle bool) {
	return c.CodeTokenEndpointHandler.CanHandleTokenEndpointRequest(ctx, request)
}

var (
	_ oauth2.TokenEndpointHandler = (*GenericCodeTokenEndpointHandler)(nil)
	_ CodeTokenEndpointHandler    = (*GenericCodeTokenEndpointHandler)(nil)
)
