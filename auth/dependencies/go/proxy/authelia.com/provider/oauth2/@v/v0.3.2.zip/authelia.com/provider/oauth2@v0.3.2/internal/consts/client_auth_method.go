// SPDX-FileCopyrightText: 2026 Authelia
//
// SPDX-License-Identifier: Apache-2.0

package consts

// Client Auth SignatureAlgorithm strings.
const (
	ClientAuthMethodClientSecretBasic       = "client_secret_basic"
	ClientAuthMethodClientSecretPost        = "client_secret_post"
	ClientAuthMethodClientSecretJWT         = "client_secret_jwt"
	ClientAuthMethodPrivateKeyJWT           = "private_key_jwt"
	ClientAuthMethodNone                    = valueNone
	ClientAuthMethodTLSClientAuth           = "tls_client_auth"
	ClientAuthMethodSelfSignedTLSClientAuth = "self_signed_tls_client_auth"
)
