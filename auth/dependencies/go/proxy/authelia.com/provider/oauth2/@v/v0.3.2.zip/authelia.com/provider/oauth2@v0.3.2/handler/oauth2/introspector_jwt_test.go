// SPDX-FileCopyrightText: 2026 Authelia
//
// SPDX-License-Identifier: Apache-2.0

package oauth2

import (
	"encoding/base64"
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"authelia.com/provider/oauth2"
	"authelia.com/provider/oauth2/internal/gen"
	"authelia.com/provider/oauth2/token/jwt"
)

func TestIntrospectJWT(t *testing.T) {
	config := &oauth2.Config{
		EnforceJWTProfileAccessTokens: true,
		GlobalSecret:                  []byte("foofoofoofoofoofoofoofoofoofoofoo"),
	}

	strategy := &JWTProfileCoreStrategy{
		HMACCoreStrategy: NewHMACCoreStrategy(config, "authelia_%s_"),
		Strategy: &jwt.DefaultStrategy{
			Config: config,
			Issuer: jwt.NewDefaultIssuerRS256Unverified(gen.MustRSAKey()),
		},
		Config: config,
	}

	validator := &StatelessJWTValidator{
		StatelessJWTStrategy: strategy,
		Config: &oauth2.Config{
			ScopeStrategy: oauth2.HierarchicScopeStrategy,
		},
	}

	testCases := []struct {
		name     string
		token    func(t *testing.T) string
		err      error
		expected string
		scopes   []string
	}{
		{
			name: "ShouldFailTokenExpired",
			token: func(t *testing.T) string {
				token := jwtExpiredCase(oauth2.AccessToken, time.Unix(1726972738, 0))
				tokenString, _, err := strategy.GenerateAccessToken(t.Context(), token)
				require.NoError(t, err)

				return tokenString
			},
			err:      oauth2.ErrTokenExpired,
			expected: "Token expired. The token expired. Token expired at 1726969138.",
		},
		{
			name: "ShouldPassScopeGranted",
			token: func(t *testing.T) string {
				token := jwtValidCase(oauth2.AccessToken)
				token.GrantedScope = []string{"foo", "bar"}
				tokenString, _, err := strategy.GenerateAccessToken(t.Context(), token)

				require.NoError(t, err)

				return tokenString
			},
			scopes: []string{"foo"},
		},
		{
			name: "ShouldFailWrongTyp",
			token: func(t *testing.T) string {
				token := jwtInvalidTypCase(oauth2.AccessToken)
				token.GrantedScope = []string{"foo", "bar"}
				tokenString, _, err := strategy.GenerateAccessToken(t.Context(), token)

				require.NoError(t, err)

				return tokenString
			},
			scopes:   []string{"foo"},
			err:      oauth2.ErrRequestUnauthorized,
			expected: "The request could not be authorized. Check that you provided valid credentials in the right format. The provided token is not a valid RFC9068 JWT Profile Access Token as it is missing the header 'typ' value of 'at+jwt'.",
		},
		{
			name: "ShouldFailScopeNotGranted",
			token: func(t *testing.T) string {
				token := jwtValidCase(oauth2.AccessToken)
				tokenString, _, err := strategy.GenerateAccessToken(t.Context(), token)
				require.NoError(t, err)

				return tokenString
			},
			scopes:   []string{"foo"},
			err:      oauth2.ErrInvalidScope,
			expected: "The requested scope is invalid, unknown, or malformed. The request scope 'foo' has not been granted or is not allowed to be requested.",
		},
		{
			name: "ShouldFailInvalidSignature",
			token: func(t *testing.T) string {
				token := jwtValidCase(oauth2.AccessToken)
				tokenString, _, err := strategy.GenerateAccessToken(t.Context(), token)
				require.NoError(t, err)
				parts := strings.Split(tokenString, ".")
				require.Len(t, parts, 3, "%s - %v", tokenString, parts)
				dec, err := base64.RawURLEncoding.DecodeString(parts[1])
				require.NoError(t, err)
				s := strings.ReplaceAll(string(dec), "peter", "piper")
				parts[1] = base64.RawURLEncoding.EncodeToString([]byte(s))

				return strings.Join(parts, ".")
			},
			err:      oauth2.ErrTokenSignatureMismatch,
			expected: "Token signature mismatch. Check that you provided a valid token in the right format. Token has an invalid signature.",
		},
		{
			name: "ShouldPass",
			token: func(t *testing.T) string {
				token := jwtValidCase(oauth2.AccessToken)
				tokenString, _, err := strategy.GenerateAccessToken(t.Context(), token)
				require.NoError(t, err)

				return tokenString
			},
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			if tc.scopes == nil {
				tc.scopes = []string{}
			}

			areq := oauth2.NewAccessRequest(nil)
			_, err := validator.IntrospectToken(t.Context(), tc.token(t), oauth2.AccessToken, areq, tc.scopes)

			if tc.err != nil {
				assert.EqualError(t, err, tc.err.Error())
				assert.EqualError(t, oauth2.ErrorToDebugRFC6749Error(err), tc.expected)
			} else {
				require.NoError(t, err)
				assert.Equal(t, "peter", areq.Session.GetSubject())
			}
		})
	}
}

func TestIntrospectJWTRecoversDPoPBinding(t *testing.T) {
	config := &oauth2.Config{
		EnforceJWTProfileAccessTokens: true,
		DPoPEnabled:                   true,
		GlobalSecret:                  []byte("foofoofoofoofoofoofoofoofoofoofoo"),
	}

	strategy := &JWTProfileCoreStrategy{
		HMACCoreStrategy: NewHMACCoreStrategy(config, "authelia_%s_"),
		Strategy: &jwt.DefaultStrategy{
			Config: config,
			Issuer: jwt.NewDefaultIssuerRS256Unverified(gen.MustRSAKey()),
		},
		Config: config,
	}

	validator := &StatelessJWTValidator{
		StatelessJWTStrategy: strategy,
		Config: &oauth2.Config{
			ScopeStrategy: oauth2.HierarchicScopeStrategy,
		},
	}

	testCases := []struct {
		name     string
		jkt      string
		expected string
	}{
		{"ShouldRecoverBindingWhenDPoPBound", "test-jkt", "test-jkt"},
		{"ShouldReportUnboundWhenNotDPoPBound", "", ""},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			r := jwtValidCase(oauth2.AccessToken)

			if tc.jkt != "" {
				r.GetSession().(oauth2.DPoPBoundSession).SetDPoPJWKThumbprint(tc.jkt)
			}

			tokenString, _, err := strategy.GenerateAccessToken(t.Context(), r)
			require.NoError(t, err)

			areq := oauth2.NewAccessRequest(nil)

			_, err = validator.IntrospectToken(t.Context(), tokenString, oauth2.AccessToken, areq, []string{})
			require.NoError(t, err)

			bound, ok := areq.GetSession().(oauth2.DPoPBoundSession)
			require.True(t, ok, "expected the merged session to support DPoP binding, got %T", areq.GetSession())
			assert.Equal(t, tc.expected, bound.GetDPoPJWKThumbprint())
		})
	}
}

func TestIntrospectJWTRecoversMTLSBinding(t *testing.T) {
	// Both methods are enabled because one case binds by both, and ApplyConfirmation asserts a confirmation method
	// only while that method is enabled.
	config := &oauth2.Config{
		EnforceJWTProfileAccessTokens: true,
		MTLSEnabled:                   true,
		DPoPEnabled:                   true,
		GlobalSecret:                  []byte("foofoofoofoofoofoofoofoofoofoofoo"),
	}

	strategy := &JWTProfileCoreStrategy{
		HMACCoreStrategy: NewHMACCoreStrategy(config, "authelia_%s_"),
		Strategy: &jwt.DefaultStrategy{
			Config: config,
			Issuer: jwt.NewDefaultIssuerRS256Unverified(gen.MustRSAKey()),
		},
		Config: config,
	}

	validator := &StatelessJWTValidator{
		StatelessJWTStrategy: strategy,
		Config: &oauth2.Config{
			ScopeStrategy: oauth2.HierarchicScopeStrategy,
		},
	}

	testCases := []struct {
		name     string
		x5t      string
		jkt      string
		expected string
	}{
		{name: "ShouldRecoverBindingWhenCertificateBound", x5t: "test-x5t", expected: "test-x5t"},
		{name: "ShouldRecoverBindingWhenBoundByBoth", x5t: "test-x5t", jkt: "test-jkt", expected: "test-x5t"},
		{name: "ShouldReportUnboundWhenNotCertificateBound", expected: ""},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			r := jwtValidCase(oauth2.AccessToken)

			if tc.x5t != "" {
				r.GetSession().(oauth2.MTLSBoundSession).SetClientCertificateSHA256Thumbprint(tc.x5t)
			}

			if tc.jkt != "" {
				r.GetSession().(oauth2.DPoPBoundSession).SetDPoPJWKThumbprint(tc.jkt)
			}

			tokenString, _, err := strategy.GenerateAccessToken(t.Context(), r)
			require.NoError(t, err)

			areq := oauth2.NewAccessRequest(nil)

			_, err = validator.IntrospectToken(t.Context(), tokenString, oauth2.AccessToken, areq, []string{})
			require.NoError(t, err)

			bound, ok := areq.GetSession().(oauth2.MTLSBoundSession)
			require.True(t, ok, "expected the merged session to support mutual-TLS binding, got %T", areq.GetSession())
			assert.Equal(t, tc.expected, bound.GetClientCertificateSHA256Thumbprint())

			assert.Equal(t, tc.jkt, areq.GetSession().(oauth2.DPoPBoundSession).GetDPoPJWKThumbprint())
		})
	}
}

// TestIntrospectJWTRecoversClientID pins the round trip: a stateless access token carries 'client_id', so the request
// this validator reconstructs names the client the token was issued to rather than an empty one.
func TestIntrospectJWTRecoversClientID(t *testing.T) {
	config := &oauth2.Config{
		EnforceJWTProfileAccessTokens: true,
		GlobalSecret:                  []byte("foofoofoofoofoofoofoofoofoofoofoo"),
	}

	strategy := &JWTProfileCoreStrategy{
		HMACCoreStrategy: NewHMACCoreStrategy(config, "authelia_%s_"),
		Strategy: &jwt.DefaultStrategy{
			Config: config,
			Issuer: jwt.NewDefaultIssuerRS256Unverified(gen.MustRSAKey()),
		},
		Config: config,
	}

	validator := &StatelessJWTValidator{
		StatelessJWTStrategy: strategy,
		Config: &oauth2.Config{
			ScopeStrategy: oauth2.HierarchicScopeStrategy,
		},
	}

	r := jwtValidCase(oauth2.AccessToken)
	r.Client = &oauth2.DefaultClient{ID: "client-abc"}

	tokenString, _, err := strategy.GenerateAccessToken(t.Context(), r)
	require.NoError(t, err)

	areq := oauth2.NewAccessRequest(nil)

	_, err = validator.IntrospectToken(t.Context(), tokenString, oauth2.AccessToken, areq, []string{})
	require.NoError(t, err)

	require.NotNil(t, areq.GetClient())
	assert.Equal(t, "client-abc", areq.GetClient().GetID())
}

func BenchmarkIntrospectJWT(b *testing.B) {
	config := &oauth2.Config{}

	strategy := &JWTProfileCoreStrategy{
		Strategy: &jwt.DefaultStrategy{
			Config: config,
			Issuer: jwt.NewDefaultIssuerRS256Unverified(gen.MustRSAKey()),
		},
		Config: config,
	}

	v := &StatelessJWTValidator{
		StatelessJWTStrategy: strategy,
	}

	jwt := jwtValidCase(oauth2.AccessToken)
	token, _, err := strategy.GenerateAccessToken(b.Context(), jwt)
	assert.NoError(b, err)
	areq := oauth2.NewAccessRequest(nil)

	for n := 0; n < b.N; n++ {
		_, err = v.IntrospectToken(b.Context(), token, oauth2.AccessToken, areq, []string{})
	}

	assert.NoError(b, err)
}
