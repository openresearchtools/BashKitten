// SPDX-FileCopyrightText: 2026 Authelia
//
// SPDX-License-Identifier: Apache-2.0

package oauth2

import (
	"context"
)

type AuthorizeEndpointHandler interface {
	// HandleAuthorizeEndpointRequest handles an authorize endpoint request. To extend the handler's capabilities, the http request
	// is passed along, if further information retrieval is required. If the handler feels that he is not responsible for
	// the authorize request, he must return nil and NOT modify session nor responder neither requester.
	//
	// The following spec is a good example of what HandleAuthorizeRequest should do.
	// * https://datatracker.ietf.org/doc/html/rfc6749#section-3.1.1
	//   response_type REQUIRED.
	//   The value MUST be one of "code" for requesting an
	//   authorization code as described by Section 4.1.1, "token" for
	//   requesting an access token (implicit grant) as described by
	//   Section 4.2.1, or a registered extension value as described by Section 8.4.
	HandleAuthorizeEndpointRequest(ctx context.Context, request AuthorizeRequester, response AuthorizeResponder) (err error)
}

type TokenEndpointHandler interface {
	// PopulateTokenEndpointResponse is responsible for setting return values and should only be executed if
	// the handler's HandleTokenEndpointRequest did not return ErrUnknownRequest.
	PopulateTokenEndpointResponse(ctx context.Context, request AccessRequester, response AccessResponder) (err error)

	// HandleTokenEndpointRequest handles an authorize request. If the handler is not responsible for handling
	// the request, this method should return ErrUnknownRequest and otherwise handle the request.
	HandleTokenEndpointRequest(ctx context.Context, request AccessRequester) (err error)

	// CanSkipClientAuth indicates if client authentication can be skipped. By default it MUST be false, unless you are
	// implementing extension grant type, which allows unauthenticated client. CanSkipClientAuth must be called
	// before HandleTokenEndpointRequest to decide, if AccessRequester will contain authenticated client.
	CanSkipClientAuth(ctx context.Context, request AccessRequester) (skip bool)

	// CanHandleTokenEndpointRequest indicates, if TokenEndpointHandler can handle this request or not. If true,
	// HandleTokenEndpointRequest can be called.
	CanHandleTokenEndpointRequest(ctx context.Context, request AccessRequester) (handle bool)
}

// AuthorizeEndpointBindingHandler records a proof-of-possession binding onto the session of an authorize request
// before any handler persists that session.
//
// A binding handler augments a flow another handler owns; it never satisfies a request by itself. Handlers in a
// binding list write disjoint session fields, so their order within the list is not significant.
type AuthorizeEndpointBindingHandler interface {
	// BindAuthorizeRequest records any binding the request asserts. It returns nil both when it records one and
	// when there is nothing to record; any error rejects the request.
	BindAuthorizeRequest(ctx context.Context, request AuthorizeRequester) (err error)
}

// TokenEndpointBindingHandler records and enforces a proof-of-possession binding on an access request that a grant
// handler has already accepted.
//
// A binding handler augments a grant another handler owns; it never satisfies one by itself. It is dispatched only
// for a request some TokenEndpointHandler accepted, so it needs neither a grant type claim nor a client
// authentication policy of its own. Handlers in a binding list write disjoint session fields, so their order within
// the list is not significant, with one exception: oidckb.Handler CONSUMES the validated *DPoPProof that
// rfc9449.Handler PUBLISHES via PublishDPoPProof, so it must be registered after it, or a grant that asked to be key
// bound fails with a server error on every token request. A handler added to this list that consumes what another
// one publishes must state its own ordering requirement the same way.
type TokenEndpointBindingHandler interface {
	// BindAccessRequest records the binding presented with this request and enforces any binding the session
	// already carries. It returns nil both when it records one and when there is nothing to record; any error
	// rejects the request.
	BindAccessRequest(ctx context.Context, request AccessRequester) (err error)

	// PopulateBoundTokenEndpointResponse adjusts the response to reflect the binding. It runs after every
	// TokenEndpointHandler has populated the response. Where two binding handlers write the same response field,
	// list order applies and the last write wins.
	PopulateBoundTokenEndpointResponse(ctx context.Context, request AccessRequester, response AccessResponder) (err error)
}

// RFC8628DeviceAuthorizeEndpointBindingHandler records a proof-of-possession binding onto the session of a device
// authorization request before any handler persists that session.
//
// It is a distinct interface from AuthorizeEndpointBindingHandler because DeviceAuthorizeRequester embeds Requester
// rather than AuthorizeRequester. Handlers in a binding list write disjoint session fields, so their order within the
// list is not significant.
type RFC8628DeviceAuthorizeEndpointBindingHandler interface {
	// BindRFC8628DeviceAuthorizeRequest records any binding the request asserts. It returns nil both when it
	// records one and when there is nothing to record; any error rejects the request.
	BindRFC8628DeviceAuthorizeRequest(ctx context.Context, request DeviceAuthorizeRequester) (err error)
}

// RevocationHandler is the interface that allows token revocation for an OAuth2.0 provider.
// https://datatracker.ietf.org/doc/html/rfc7009
//
// RevokeToken is invoked after a new token revocation request is parsed.
//
// https://datatracker.ietf.org/doc/html/rfc7009#section-2.1
// If the particular
// token is a refresh token and the authorization server supports the
// revocation of access tokens, then the authorization server SHOULD
// also invalidate all access tokens based on the same authorization
// grant (see Implementation Note). If the token passed to the request
// is an access token, the server MAY revoke the respective refresh
// token as well.
type RevocationHandler interface {
	// RevokeToken handles access and refresh token revocation.
	RevokeToken(ctx context.Context, token string, tokenType TokenType, client Client) (err error)
}

// PushedAuthorizeEndpointHandler is the interface that handles PAR (https://datatracker.ietf.org/doc/html/rfc9126)
type PushedAuthorizeEndpointHandler interface {
	// HandlePushedAuthorizeEndpointRequest handles a pushed authorize endpoint request. To extend the handler's capabilities, the http request
	// is passed along, if further information retrieval is required. If the handler feels that he is not responsible for
	// the pushed authorize request, he must return nil and NOT modify session nor responder neither requester.
	HandlePushedAuthorizeEndpointRequest(ctx context.Context, request AuthorizeRequester, response PushedAuthorizeResponder) (err error)
}

type RFC8628DeviceAuthorizeEndpointHandler interface {
	// HandleRFC8628DeviceAuthorizeEndpointRequest handles a device authorize endpoint request. To extend the handler's capabilities, the http request
	// is passed along, if further information retrieval is required. If the handler feels that he is not responsible for
	// the device authorize request, he must return nil and NOT modify session nor responder neither requester.
	//
	// The following spec is a good example of what HandleDeviceAuthorizeRequest should do.
	// * https://tools.ietf.org/html/rfc8628#section-3.2
	HandleRFC8628DeviceAuthorizeEndpointRequest(ctx context.Context, request DeviceAuthorizeRequester, response DeviceAuthorizeResponder) (err error)
}

type RFC8628UserAuthorizeEndpointHandler interface {
	// HandleRFC8628UserAuthorizeEndpointRequest validates the request with the given user code.
	//
	// The following spec is a good example of what PopulateRFC8628UserAuthorizeEndpointResponse should do.
	// * https://www.rfc-editor.org/rfc/rfc8628#section-3.3
	HandleRFC8628UserAuthorizeEndpointRequest(ctx context.Context, request DeviceAuthorizeRequester) (err error)

	// PopulateRFC8628UserAuthorizeEndpointResponse populates the response object as an outcome of user authorization during
	// the device authorization grant flow.
	//
	PopulateRFC8628UserAuthorizeEndpointResponse(ctx context.Context, request DeviceAuthorizeRequester, response DeviceUserAuthorizeResponder) (err error)
}

// RFC7591ClientRegistrationEndpointHandler is the interface that handles the client registration endpoint.
//
// See: https://datatracker.ietf.org/doc/html/rfc7591#section-3 and
// https://openid.net/specs/openid-connect-registration-1_0.html#ClientRegistration.
type RFC7591ClientRegistrationEndpointHandler interface {
	// HandleRFC7591ClientRegistrationEndpointRequest handles a client registration endpoint request. If the handler
	// is not responsible for the request it must return nil and modify neither the requester nor the responder.
	HandleRFC7591ClientRegistrationEndpointRequest(ctx context.Context, requester ClientRegistrationRequester, responder ClientRegistrationResponder) (err error)
}

// RFC7592ClientConfigurationEndpointHandler is the interface that handles the client configuration endpoint.
//
// See: https://datatracker.ietf.org/doc/html/rfc7592#section-2.
type RFC7592ClientConfigurationEndpointHandler interface {
	// HandleRFC7592ClientConfigurationEndpointRequest handles a read, update, or delete request at the client
	// configuration endpoint, dispatching on the requester's method.
	HandleRFC7592ClientConfigurationEndpointRequest(ctx context.Context, requester ClientConfigurationRequester, responder ClientConfigurationResponder) (err error)
}
