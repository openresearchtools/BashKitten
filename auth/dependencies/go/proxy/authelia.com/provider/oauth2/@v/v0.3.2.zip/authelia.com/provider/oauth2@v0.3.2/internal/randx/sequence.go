// SPDX-FileCopyrightText: 2026 Authelia
//
// SPDX-License-Identifier: Apache-2.0

package randx

import (
	"crypto/rand"
	"math/big"
)

var rander = rand.Reader // random function

var (
	// AlphaNum contains runes [abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789].
	AlphaNum = []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")

	// Alpha contains runes [abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ].
	Alpha = []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")

	// AlphaLowerNum contains runes [abcdefghijklmnopqrstuvwxyz0123456789].
	AlphaLowerNum = []rune("abcdefghijklmnopqrstuvwxyz0123456789")

	// AlphaUpperNum contains runes [ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789].
	AlphaUpperNum = []rune("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")

	// AlphaLower contains runes [abcdefghijklmnopqrstuvwxyz].
	AlphaLower = []rune("abcdefghijklmnopqrstuvwxyz")

	// AlphaUpperVowels contains runes [AEIOUY].
	AlphaUpperVowels = []rune("AEIOUY")

	// AlphaUpperNoVowels contains runes [BCDFGHJKLMNPQRSTVWXZ].
	AlphaUpperNoVowels = []rune("BCDFGHJKLMNPQRSTVWXZ")

	// AlphaUpper contains runes [ABCDEFGHIJKLMNOPQRSTUVWXYZ].
	AlphaUpper = []rune("ABCDEFGHIJKLMNOPQRSTUVWXYZ")

	// Numeric contains runes [0123456789].
	Numeric = []rune("0123456789")
)

// RuneSequence returns a random sequence using the defined allowed runes.
func RuneSequence(l int, allowedRunes []rune) (seq []rune, err error) {
	c := big.NewInt(int64(len(allowedRunes)))
	seq = make([]rune, l)

	var r *big.Int

	for i := 0; i < l; i++ {
		if r, err = rand.Int(rander, c); err != nil {
			return seq, err
		}

		rn := allowedRunes[r.Uint64()]
		seq[i] = rn
	}

	return seq, nil
}

// MustString returns a random string sequence using the defined runes. Panics on error.
func MustString(l int, allowedRunes []rune) string {
	if seq, err := RuneSequence(l, allowedRunes); err != nil {
		panic(err)
	} else {
		return string(seq)
	}
}
