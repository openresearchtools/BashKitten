// SPDX-FileCopyrightText: 2026 Authelia
//
// SPDX-License-Identifier: Apache-2.0

package oauth2

import (
	"context"
	"encoding/json"
	"net/http"
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/pkg/errors"

	"authelia.com/provider/oauth2/internal/consts"
	"authelia.com/provider/oauth2/token/jwt"
)

// WriteIntrospectionError responds with token metadata discovered by token introspection as defined in
// https://datatracker.ietf.org/doc/html/rfc7662#section-2.2
//
// If the protected resource uses OAuth 2.0 client credentials to
// authenticate to the introspection endpoint and its credentials are
// invalid, the authorization server responds with an HTTP 401
// (Unauthorized) as described in Section 5.2 of OAuth 2.0 [RFC6749].
//
// If the protected resource uses an OAuth 2.0 bearer token to authorize
// its call to the introspection endpoint and the token used for
// authorization does not contain sufficient privileges or is otherwise
// invalid for this request, the authorization server responds with an
// HTTP 401 code as described in Section 3 of OAuth 2.0 Bearer Token
// Usage [RFC6750].
//
// Note that a properly formed and authorized query for an inactive or
// otherwise invalid token (or a token the protected resource is not
// allowed to know about) is not considered an error response by this
// specification.  In these cases, the authorization server MUST instead
// respond with an introspection response with the "active" field set to
// "false" as described in Section 2.2.
func (f *Fosite) WriteIntrospectionError(ctx context.Context, rw http.ResponseWriter, err error) {
	if err == nil {
		return
	}

	// Inactive token errors should never written out as an error.
	if !errors.Is(err, ErrInactiveToken) && (errors.Is(err, ErrInvalidRequest) || errors.Is(err, ErrRequestUnauthorized)) {
		f.writeErrorJSON(ctx, rw, nil, err)

		return
	}

	// A rejected bearer credential additionally warrants a challenge naming the schemes this endpoint accepts.
	if !errors.Is(err, ErrInactiveToken) && IsBearerCredentialError(err) {
		// The request is present when the caller writes the error from the context NewIntrospectionRequest derived,
		// and absent otherwise. WriteBearerAuthorizationChallenge accepts either.
		r, _ := ctx.Value(RequestContextKey).(*http.Request)

		rfc := f.WriteBearerAuthorizationChallenge(ctx, rw, r, err)

		// RFC 7662 Section 2.3: a bearer credential that "does not contain sufficient privileges or is otherwise
		// invalid for this request" is answered with HTTP 401. That is more specific than RFC 6750 Section 3.1's
		// general 403 for insufficient_scope, so it wins here. The RFC 7591 client registration endpoint has no such
		// override and answers 403 for the same condition.
		if rfc.ErrorField == errInsufficientScopeName {
			rfc = rfc.WithCode(http.StatusUnauthorized)
		}

		f.writeErrorJSONRFC(ctx, rw, rfc)

		return
	}

	rw.Header().Set(consts.HeaderContentType, consts.ContentTypeApplicationJSON)
	rw.Header().Set(consts.HeaderCacheControl, consts.CacheControlNoStore)
	rw.Header().Set(consts.HeaderPragma, consts.PragmaNoCache)
	_ = json.NewEncoder(rw).Encode(struct {
		Active bool `json:"active"`
	}{Active: false})
}

// WriteIntrospectionResponse responds with an error if token introspection failed as defined in
// https://datatracker.ietf.org/doc/html/rfc7662#section-2.3
//
// The server responds with a JSON object [RFC7159] in "application/
// json" format with the following top-level members.
//
// * active
// REQUIRED.  Boolean indicator of whether or not the presented token
// is currently active.  The specifics of a token's "active" state
// will vary depending on the implementation of the authorization
// server and the information it keeps about its tokens, but a "true"
// value return for the "active" property will generally indicate
// that a given token has been issued by this authorization server,
// has not been revoked by the resource owner, and is within its
// given time window of validity (e.g., after its issuance time and
// before its expiration time).  See Section 4 for information on
// implementation of such checks.
//
// * scope
// OPTIONAL.  A JSON string containing a space-separated list of
// scopes associated with this token, in the format described in
// Section 3.3 of OAuth 2.0 [RFC6749].
//
// * client_id
// OPTIONAL.  Client identifier for the OAuth 2.0 client that
// requested this token.
//
// * username
// OPTIONAL.  Human-readable identifier for the resource owner who
// authorized this token.
//
// * token_type
// OPTIONAL.  Type of the token as defined in Section 5.1 of OAuth
// 2.0 [RFC6749].
//
// * exp
// OPTIONAL.  Integer timestamp, measured in the number of seconds
// since January 1 1970 UTC, indicating when this token will expire,
// as defined in JWT [RFC7519].
//
// * iat
// OPTIONAL.  Integer timestamp, measured in the number of seconds
// since January 1 1970 UTC, indicating when this token was
// originally issued, as defined in JWT [RFC7519].
//
// * nbf
// OPTIONAL.  Integer timestamp, measured in the number of seconds
// since January 1 1970 UTC, indicating when this token is not to be
// used before, as defined in JWT [RFC7519].
//
// * sub
// OPTIONAL.  Subject of the token, as defined in JWT [RFC7519].
// Usually a machine-readable identifier of the resource owner who
// authorized this token.
//
// * aud
// OPTIONAL.  Service-specific string identifier or list of string
// identifiers representing the intended audience for this token, as
// defined in JWT [RFC7519].
//
// * iss
// OPTIONAL.  String representing the issuer of this token, as
// defined in JWT [RFC7519].
//
// * jti
// OPTIONAL.  String identifier for the token, as defined in JWT
// [RFC7519].
//
// Specific implementations MAY extend this structure with their own
// service-specific response names as top-level members of this JSON
// object.  Response names intended to be used across domains MUST be
// registered in the "OAuth Token Introspection Response" registry
// defined in Section 3.1.
//
// The authorization server MAY respond differently to different
// protected resources making the same request.  For instance, an
// authorization server MAY limit which scopes from a given token are
// returned for each protected resource to prevent a protected resource
// from learning more about the larger network than is necessary for its
// operation.
//
// The response MAY be cached by the protected resource to improve
// performance and reduce load on the introspection endpoint, but at the
// cost of liveness of the information used by the protected resource to
// make authorization decisions.  See Section 4 for more information
// regarding the trade off when the response is cached.
//
// For example, the following response contains a set of information
// about an active token:
//
// The following is a non-normative example response:
//
//	HTTP/1.1 200 OK
//	Content-Type: application/json
//
//	{
//	  "active": true,
//	  "client_id": "l238j323ds-23ij4",
//	  "username": "jdoe",
//	  "scope": "read write dolphin",
//	  "sub": "Z5O3upPC88QrAjx00dis",
//	  "aud": "https://protected.example.net/resource",
//	  "iss": "https://server.example.com/",
//	  "exp": 1419356238,
//	  "iat": 1419350238,
//	  "extension_field": "twenty-seven"
//	}
//
// If the introspection call is properly authorized but the token is not
// active, does not exist on this server, or the protected resource is
// not allowed to introspect this particular token, then the
// authorization server MUST return an introspection response with the
// "active" field set to "false".  Note that to avoid disclosing too
// much of the authorization server's state to a third party, the
// authorization server SHOULD NOT include any additional information
// about an inactive token, including why the token is inactive.
//
// The following is a non-normative example response for a token that
// has been revoked or is otherwise invalid:
//
//	HTTP/1.1 200 OK
//	Content-Type: application/json
//
//	{
//	  "active": false
//	}
func (f *Fosite) WriteIntrospectionResponse(ctx context.Context, rw http.ResponseWriter, r IntrospectionResponder) {
	var (
		caller   Client
		client   IntrospectionJWTResponseClient
		ok       bool
		alg, kid string
	)

	if responder, isResponderClient := r.(IntrospectionResponderClient); isResponderClient {
		caller = responder.GetClient()
	}

	// RFC 9701 Section 6 bases the algorithm decision on "registered metadata parameters for the resource server",
	// and Section 5 requires 'aud' to identify the resource server receiving the response. Both halves therefore
	// come from the caller. Reading them from the introspected token's client would derive one JWT from two parties:
	// a resource server that registered 'introspection_signed_response_alg' would be sent plain JSON unless the
	// token it happened to introspect belonged to a client that registered one too.
	//
	// See: https://www.rfc-editor.org/rfc/rfc9701#section-6
	if client, ok = caller.(IntrospectionJWTResponseClient); ok {
		alg, kid = client.GetIntrospectionSignedResponseAlg(), client.GetIntrospectionSignedResponseKeyID()
	}

	response := map[string]any{jwt.ClaimActive: false}

	if !r.IsActive() {
		f.writeIntrospectionResponse(ctx, rw, r, caller, response, alg, kid)

		return
	}

	response[jwt.ClaimActive] = true

	extraClaimsSession, ok := r.GetAccessRequester().GetSession().(ExtraClaimsSession)
	if ok {
		extraClaims := extraClaimsSession.GetExtraClaims()
		for name, value := range extraClaims {
			switch name {
			// We do not allow these to be set through extra claims.
			case jwt.ClaimExpirationTime, jwt.ClaimClientIdentifier, jwt.ClaimScope, jwt.ClaimIssuedAt, jwt.ClaimSubject, jwt.ClaimAudience, jwt.ClaimUsername, jwt.ClaimConfirmation:
				continue
			default:
				response[name] = value
			}
		}
	}

	if expires := r.GetAccessRequester().GetSession().GetExpiresAt(r.GetTokenUse()); !expires.IsZero() {
		response[jwt.ClaimExpirationTime] = expires.Unix()
	}
	if r.GetAccessRequester().GetClient().GetID() != "" {
		response[jwt.ClaimClientIdentifier] = r.GetAccessRequester().GetClient().GetID()
	}
	if len(r.GetAccessRequester().GetGrantedScopes()) > 0 {
		response[jwt.ClaimScope] = strings.Join(r.GetAccessRequester().GetGrantedScopes(), " ")
	}
	if !r.GetAccessRequester().GetRequestedAt().IsZero() {
		response[jwt.ClaimIssuedAt] = r.GetAccessRequester().GetRequestedAt().Unix()
	}
	if r.GetAccessRequester().GetSession().GetSubject() != "" {
		response[jwt.ClaimSubject] = r.GetAccessRequester().GetSession().GetSubject()
	}
	if aud := JoinGrantedAudienceAndResource(r.GetAccessRequester().GetGrantedAudience(), r.GetAccessRequester().GetGrantedResource()); len(aud) > 0 {
		response[jwt.ClaimAudience] = aud
	}
	if r.GetAccessRequester().GetSession().GetUsername() != "" {
		response[jwt.ClaimUsername] = r.GetAccessRequester().GetSession().GetUsername()
	}

	ApplyConfirmation(ctx, f.Config, response, r.GetAccessRequester().GetSession())

	f.writeIntrospectionResponse(ctx, rw, r, caller, response, alg, kid)
}

func (f *Fosite) writeIntrospectionResponse(ctx context.Context, rw http.ResponseWriter, r IntrospectionResponder, caller Client, response map[string]any, alg, kid string) {
	switch {
	case (alg != "" && alg != jwt.JSONWebTokenAlgNone) || (kid != "" && alg != jwt.JSONWebTokenAlgNone):
		var (
			token string
			jti   uuid.UUID
			err   error
		)

		header := &jwt.Headers{
			Extra: map[string]any{
				jwt.JSONWebTokenHeaderType: jwt.JSONWebTokenTypeTokenIntrospection,
			},
		}

		if alg != "" {
			header.Add(jwt.JSONWebTokenHeaderAlgorithm, alg)
		}

		if kid != "" {
			header.Add(jwt.JSONWebTokenHeaderKeyIdentifier, kid)
		}

		if jti, err = uuid.NewRandom(); err != nil {
			f.WriteIntrospectionError(ctx, rw, errors.WithStack(ErrServerError.WithHint("Failed to lookup required information to perform this request.").WithDebugf("The JTI could not be generated for the Introspection JWT response type with error %+v.", err)))

			return
		}

		claims := jwt.MapClaims{
			jwt.ClaimJWTID:              jti.String(),
			jwt.ClaimIssuer:             f.Config.GetIntrospectionIssuer(ctx),
			jwt.ClaimIssuedAt:           time.Now().UTC().Unix(),
			jwt.ClaimTokenIntrospection: response,
		}

		if aud, _ := r.ToMap(); len(aud) != 0 {
			claims[jwt.ClaimAudience] = aud
		}

		strategy := f.Config.GetIntrospectionJWTResponseStrategy(ctx)

		if strategy == nil {
			f.WriteIntrospectionError(ctx, rw, errors.WithStack(ErrServerError.WithHint("Failed to generate the response.").WithDebug("The Introspection JWT could not be generated as the server is misconfigured. The Introspection jwt.Strategy was not configured.")))

			return
		}

		if token, _, err = strategy.Encode(ctx, claims, jwt.WithHeaders(header), jwt.WithIntrospectionClient(caller)); err != nil {
			f.WriteIntrospectionError(ctx, rw, errors.WithStack(ErrServerError.WithHint("Failed to generate the response.").WithDebugf("The Introspection JWT itself could not be generated with error %+v.", err)))

			return
		}

		rw.Header().Set(consts.HeaderContentType, consts.ContentTypeApplicationTokenIntrospectionJWT)
		rw.Header().Set(consts.HeaderCacheControl, consts.CacheControlNoStore)
		rw.Header().Set(consts.HeaderPragma, consts.PragmaNoCache)
		rw.WriteHeader(http.StatusOK)

		_, _ = rw.Write([]byte(token))
	default:
		rw.Header().Set(consts.HeaderContentType, consts.ContentTypeApplicationJSON)
		rw.Header().Set(consts.HeaderCacheControl, consts.CacheControlNoStore)
		rw.Header().Set(consts.HeaderPragma, consts.PragmaNoCache)
		rw.WriteHeader(http.StatusOK)

		_ = json.NewEncoder(rw).Encode(response)
	}
}
