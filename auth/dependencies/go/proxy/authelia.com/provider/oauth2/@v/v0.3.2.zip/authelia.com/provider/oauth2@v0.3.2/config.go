// SPDX-FileCopyrightText: 2026 Authelia
//
// SPDX-License-Identifier: Apache-2.0

package oauth2

import (
	"context"
	"hash"
	"html/template"
	"net/url"
	"time"

	"github.com/hashicorp/go-retryablehttp"

	"authelia.com/provider/oauth2/i18n"
	"authelia.com/provider/oauth2/token/jwt"
)

// AuthorizeCodeLifespanProvider returns the provider for configuring the authorization code lifespan.
type AuthorizeCodeLifespanProvider interface {
	// GetAuthorizeCodeLifespan returns the authorization code lifespan.
	GetAuthorizeCodeLifespan(ctx context.Context) (lifespan time.Duration)
}

// RefreshTokenLifespanProvider returns the provider for configuring the refresh token lifespan.
type RefreshTokenLifespanProvider interface {
	// GetRefreshTokenLifespan returns the refresh token lifespan.
	GetRefreshTokenLifespan(ctx context.Context) (lifespan time.Duration)
}

// AccessTokenLifespanProvider returns the provider for configuring the access token lifespan.
type AccessTokenLifespanProvider interface {
	// GetAccessTokenLifespan returns the access token lifespan.
	GetAccessTokenLifespan(ctx context.Context) (lifespan time.Duration)
}

// VerifiableCredentialsNonceLifespanProvider returns the provider for configuring the access token lifespan.
type VerifiableCredentialsNonceLifespanProvider interface {
	// GetVerifiableCredentialsNonceLifespan returns the nonce lifespan.
	GetVerifiableCredentialsNonceLifespan(ctx context.Context) (lifespan time.Duration)
}

// IDTokenLifespanProvider returns the provider for configuring the ID token lifespan.
type IDTokenLifespanProvider interface {
	// GetIDTokenLifespan returns the ID token lifespan.
	GetIDTokenLifespan(ctx context.Context) (lifespan time.Duration)
}

// ScopeStrategyProvider returns the provider for configuring the scope strategy.
type ScopeStrategyProvider interface {
	// GetScopeStrategy returns the scope strategy.
	GetScopeStrategy(ctx context.Context) (strategy ScopeStrategy)
}

// AudienceStrategyProvider returns the provider for configuring the audience strategy.
type AudienceStrategyProvider interface {
	// GetAudienceStrategy returns the audience strategy.
	GetAudienceStrategy(ctx context.Context) (strategy AudienceStrategy)
}

// ResourceStrategyProvider returns the provider for configuring the RFC 8707 resource indicator strategy.
type ResourceStrategyProvider interface {
	// GetResourceStrategy returns the resource indicator matching strategy.
	GetResourceStrategy(ctx context.Context) (strategy ResourceStrategy)
}

// ClientCredentialsImplicitProvider describes the provider of the Client Credentials Flow Implicit actions.
type ClientCredentialsImplicitProvider interface {
	// GetClientCredentialsFlowImplicitGrantRequested returns true if the PopulateTokenEndpointResponse portion of the
	// oauth2.ClientCredentialsGrantHandler should implicitly grant all requested and validated scopes and audiences.
	GetClientCredentialsFlowImplicitGrantRequested(ctx context.Context) (implicit bool)
}

// RedirectSecureCheckerProvider returns the provider for configuring the redirect URL security validator.
type RedirectSecureCheckerProvider interface {
	// GetRedirectSecureChecker returns the redirect URL security validator.
	GetRedirectSecureChecker(ctx context.Context) func(context.Context, *url.URL) bool
}

// RefreshTokenScopesProvider returns the provider for configuring the refresh token scopes.
type RefreshTokenScopesProvider interface {
	// GetRefreshTokenScopes returns the refresh token scopes.
	GetRefreshTokenScopes(ctx context.Context) []string
}

// DisableRefreshTokenValidationProvider returns the provider for configuring the refresh token validation.
type DisableRefreshTokenValidationProvider interface {
	// GetDisableRefreshTokenValidation returns the disable refresh token validation flag.
	GetDisableRefreshTokenValidation(ctx context.Context) bool
}

// AccessTokenIssuerProvider returns the provider for configuring the JWT issuer.
type AccessTokenIssuerProvider interface {
	// GetAccessTokenIssuer returns the access token issuer.
	GetAccessTokenIssuer(ctx context.Context) (issuer string)
}

// IDTokenIssuerProvider returns the provider for configuring the ID token issuer.
type IDTokenIssuerProvider interface {
	// GetIDTokenIssuer returns the ID token issuer.
	GetIDTokenIssuer(ctx context.Context) (issuer string)
}

// IDTokenValidationStrategyProvider returns the provider for configuring the ID Token validation strategy, which
// validates ID Tokens presented to the authorization server by a client.
type IDTokenValidationStrategyProvider interface {
	// GetIDTokenValidationStrategy returns the ID Token validation strategy. Has no default and may be nil.
	GetIDTokenValidationStrategy(ctx context.Context) (strategy TokenValidationStrategy)
}

// BackChannelLogoutTokenStrategyProvider returns the provider for configuring the Back-Channel Logout token
// strategy, which generates the Logout Tokens delivered to Relying Parties.
type BackChannelLogoutTokenStrategyProvider interface {
	// GetBackChannelLogoutTokenStrategy returns the Back-Channel Logout token strategy. Has no default and may
	// be nil.
	GetBackChannelLogoutTokenStrategy(ctx context.Context) (strategy BackChannelLogoutTokenStrategy)
}

// BackChannelLogoutLifespanProvider returns the provider for configuring the Logout Token lifespan.
type BackChannelLogoutLifespanProvider interface {
	// GetBackChannelLogoutLifespan returns the Logout Token lifespan. Defaults to 5 minutes.
	GetBackChannelLogoutLifespan(ctx context.Context) (lifespan time.Duration)
}

// BackChannelLogoutConcurrencyProvider returns the provider for configuring how many Back-Channel Logout
// requests are delivered concurrently.
type BackChannelLogoutConcurrencyProvider interface {
	// GetBackChannelLogoutConcurrency returns the maximum number of Back-Channel Logout requests delivered
	// concurrently. Defaults to 10.
	GetBackChannelLogoutConcurrency(ctx context.Context) (n int)
}

// IntrospectionIssuerProvider returns the provider for configuring the Introspection issuer.
type IntrospectionIssuerProvider interface {
	// GetIntrospectionIssuer returns the Introspection token issuer.
	GetIntrospectionIssuer(ctx context.Context) (issuer string)
}

// IntrospectionJWTResponseStrategyProvider returns the provider for configuring the Introspection jwt.Strategy.
type IntrospectionJWTResponseStrategyProvider interface {
	// GetIntrospectionJWTResponseStrategy returns the Introspection JWT Strategy.
	GetIntrospectionJWTResponseStrategy(ctx context.Context) jwt.Strategy
}

// AuthorizationServerIssuerIdentificationProvider provides OAuth 2.0 Authorization Server Issuer Identification related methods.
type AuthorizationServerIssuerIdentificationProvider interface {
	GetAuthorizationServerIdentificationIssuer(ctx context.Context) (issuer string)
}

// JWTScopeFieldProvider returns the provider for configuring the JWT scope field.
type JWTScopeFieldProvider interface {
	// GetJWTScopeField returns the JWT scope field.
	GetJWTScopeField(ctx context.Context) jwt.JWTScopeFieldEnum
}

// JWTSecuredAuthorizeResponseModeIssuerProvider returns the provider for configuring the JARM issuer.
type JWTSecuredAuthorizeResponseModeIssuerProvider interface {
	// GetJWTSecuredAuthorizeResponseModeIssuer returns the JARM issuer.
	GetJWTSecuredAuthorizeResponseModeIssuer(ctx context.Context) string
}

// JWTSecuredAuthorizeResponseModeStrategyProvider returns the provider for configuring the JARM jwt.Strategy.
type JWTSecuredAuthorizeResponseModeStrategyProvider interface {
	// GetJWTSecuredAuthorizeResponseModeStrategy returns the JARM Strategy.
	GetJWTSecuredAuthorizeResponseModeStrategy(ctx context.Context) jwt.Strategy
}

// JWTStrategyProvider returns the provider for configuring the jwt.Strategy.
type JWTStrategyProvider interface {
	GetJWTStrategy(ctx context.Context) jwt.Strategy
}

// JWTSecuredAuthorizeResponseModeLifespanProvider returns the provider for configuring the JWT Secured Authorize Response Mode token lifespan.
type JWTSecuredAuthorizeResponseModeLifespanProvider interface {
	GetJWTSecuredAuthorizeResponseModeLifespan(ctx context.Context) time.Duration
}

// JWTProfileAccessTokensProvider provides configuration options to the JWT Profile strategies.
type JWTProfileAccessTokensProvider interface {
	// GetEnforceJWTProfileAccessTokens when returning true will disregard the registered client capabilities for
	// Access Token generation and produce only JWT Profile Access Tokens.
	GetEnforceJWTProfileAccessTokens(ctx context.Context) (enable bool)
}

// AllowedPromptsProvider returns the provider for configuring the allowed prompts.
type AllowedPromptsProvider interface {
	// GetAllowedPrompts returns the allowed prompts.
	GetAllowedPrompts(ctx context.Context) (prompts []string)
}

// MinParameterEntropyProvider returns the provider for configuring the minimum parameter entropy.
type MinParameterEntropyProvider interface {
	// GetMinParameterEntropy returns the minimum parameter entropy.
	GetMinParameterEntropy(_ context.Context) (min int)
}

// SanitationAllowedProvider returns the provider for configuring the sanitation white list.
type SanitationAllowedProvider interface {
	// GetSanitationWhiteList is a whitelist of form values that are required by the token endpoint. These values
	// are safe for storage in a database (cleartext).
	GetSanitationWhiteList(ctx context.Context) (whitelist []string)
}

// OmitRedirectScopeParamProvider returns the provider for configuring the omit redirect scope param.
type OmitRedirectScopeParamProvider interface {
	// GetOmitRedirectScopeParam must be set to true if the scope query param is to be omitted
	// in the authorization's redirect URI
	GetOmitRedirectScopeParam(ctx context.Context) (omit bool)
}

// EnforcePKCEProvider returns the provider for configuring the enforcement of PKCE.
type EnforcePKCEProvider interface {
	// GetEnforcePKCE returns the enforcement of PKCE.
	GetEnforcePKCE(ctx context.Context) (enforce bool)
}

// EnforcePKCEForPublicClientsProvider returns the provider for configuring the enforcement of PKCE for public clients.
type EnforcePKCEForPublicClientsProvider interface {
	// GetEnforcePKCEForPublicClients returns the enforcement of PKCE for public clients.
	GetEnforcePKCEForPublicClients(ctx context.Context) (enforce bool)
}

// EnablePKCEPlainChallengeMethodProvider returns the provider for configuring the enable PKCE plain challenge method.
type EnablePKCEPlainChallengeMethodProvider interface {
	// GetEnablePKCEPlainChallengeMethod returns the enable PKCE plain challenge method.
	GetEnablePKCEPlainChallengeMethod(ctx context.Context) (enable bool)
}

// GrantTypeJWTBearerCanSkipClientAuthProvider returns the provider for configuring the grant type JWT bearer can skip client auth.
type GrantTypeJWTBearerCanSkipClientAuthProvider interface {
	// GetGrantTypeJWTBearerCanSkipClientAuth returns the grant type JWT bearer can skip client auth.
	GetGrantTypeJWTBearerCanSkipClientAuth(ctx context.Context) (permitted bool)
}

// GrantTypeJWTBearerIDOptionalProvider returns the provider for configuring the grant type JWT bearer ID optional.
type GrantTypeJWTBearerIDOptionalProvider interface {
	// GetGrantTypeJWTBearerIDOptional returns the grant type JWT bearer ID optional.
	GetGrantTypeJWTBearerIDOptional(ctx context.Context) (optional bool)
}

// GrantTypeJWTBearerIssuedDateOptionalProvider returns the provider for configuring the grant type JWT bearer issued date optional.
type GrantTypeJWTBearerIssuedDateOptionalProvider interface {
	// GetGrantTypeJWTBearerIssuedDateOptional returns the grant type JWT bearer issued date optional.
	GetGrantTypeJWTBearerIssuedDateOptional(ctx context.Context) (optional bool)
}

// GetJWTMaxDurationProvider returns the provider for configuring the JWT max duration.
type GetJWTMaxDurationProvider interface {
	// GetJWTMaxDuration returns the JWT max duration.
	GetJWTMaxDuration(ctx context.Context) (max time.Duration)
}

// TokenEntropyProvider returns the provider for configuring the token entropy.
type TokenEntropyProvider interface {
	// GetTokenEntropy returns the token entropy.
	GetTokenEntropy(ctx context.Context) (entropy int)
}

// GlobalSecretProvider returns the provider for configuring the global secret.
type GlobalSecretProvider interface {
	// GetGlobalSecret returns the global secret.
	GetGlobalSecret(ctx context.Context) (secret []byte, err error)
}

// RotatedGlobalSecretsProvider returns the provider for configuring the rotated global secrets.
type RotatedGlobalSecretsProvider interface {
	// GetRotatedGlobalSecrets returns the rotated global secrets.
	GetRotatedGlobalSecrets(ctx context.Context) (secrets [][]byte, err error)
}

// HMACHashingProvider returns the provider for configuring the hash function.
type HMACHashingProvider interface {
	// GetHMACHasher returns the hash function.
	GetHMACHasher(ctx context.Context) func() (hasher hash.Hash)
}

// SendDebugMessagesToClientsProvider returns the provider for configuring the send debug messages to clients.
type SendDebugMessagesToClientsProvider interface {
	// GetSendDebugMessagesToClients returns the send debug messages to clients.
	GetSendDebugMessagesToClients(ctx context.Context) (send bool)
}

// RevokeRefreshTokensExplicitlyProvider returns the provider for configuring the Refresh Token Explicit Revocation policy.
type RevokeRefreshTokensExplicitlyProvider interface {
	// GetRevokeRefreshTokensExplicit returns true if a refresh token should only be revoked explicitly.
	GetRevokeRefreshTokensExplicit(ctx context.Context) (explicit bool)

	// GetEnforceRevokeFlowRevokeRefreshTokensExplicitClient returns true if a
	// RevokeFlowRevokeRefreshTokensExplicitClient returning false should be enforced.
	GetEnforceRevokeFlowRevokeRefreshTokensExplicitClient(ctx context.Context) (explicit bool)
}

// JWKSFetcherStrategyProvider returns the provider for configuring the JWKS fetcher strategy.
type JWKSFetcherStrategyProvider interface {
	// GetJWKSFetcherStrategy returns the JWKS fetcher strategy.
	GetJWKSFetcherStrategy(ctx context.Context) (strategy jwt.JWKSFetcherStrategy)
}

// HTTPClientProvider returns the provider for configuring the HTTP client.
type HTTPClientProvider interface {
	// GetHTTPClient returns the HTTP client provider.
	GetHTTPClient(ctx context.Context) (client *retryablehttp.Client)
}

// ClientAuthenticationStrategyProvider returns the provider for configuring the client authentication strategy.
type ClientAuthenticationStrategyProvider interface {
	// GetClientAuthenticationStrategy returns the client authentication strategy.
	GetClientAuthenticationStrategy(ctx context.Context) (strategy ClientAuthenticationStrategy)
}

// ResponseModeHandlerProvider returns the provider for configuring the response mode handlers.
type ResponseModeHandlerProvider interface {
	// GetResponseModeHandlers returns the response mode handlers in order of execution.
	GetResponseModeHandlers(ctx context.Context) (handlers ResponseModeHandlers)
}

// ResponseModeParameterHandlerProvider returns the providers for configuring additional parameters in the response
// mode phase of an Authorization Request which may not be possible to determine until the final response mode is known.
type ResponseModeParameterHandlerProvider interface {
	// GetResponseModeParameterHandlers returns the ResponseModeParameterHandler's to process.
	GetResponseModeParameterHandlers(ctx context.Context) (handlers ResponseModeParameterHandlers)
}

// MessageCatalogProvider returns the provider for configuring the message catalog.
type MessageCatalogProvider interface {
	// GetMessageCatalog returns the message catalog.
	GetMessageCatalog(ctx context.Context) (catalog i18n.MessageCatalog)
}

// FormPostHTMLTemplateProvider returns the provider for configuring the form post HTML template.
type FormPostHTMLTemplateProvider interface {
	// GetFormPostHTMLTemplate returns the form post HTML template.
	GetFormPostHTMLTemplate(ctx context.Context) (tmpl *template.Template)
}

// FormPostResponseProvider provides a writer interface for writing the form post responses.
type FormPostResponseProvider interface {
	// GetFormPostResponseWriter returns a FormPostResponseWriter which should be utilized for writing the
	// form post response type.
	GetFormPostResponseWriter(ctx context.Context) FormPostResponseWriter
}

// AllowedJWTAssertionAudiencesProvider is a provider used in contexts where the permitted audiences for a JWT assertion
// is required to validate a request.
type AllowedJWTAssertionAudiencesProvider interface {
	// GetAllowedJWTAssertionAudiences returns the permitted audience list for JWT Assertions.
	GetAllowedJWTAssertionAudiences(ctx context.Context) (audiences []string)

	// GetEnforceClientAssertionIssuerAudience returns whether a JWT client authentication assertion must carry the
	// issuer identifier as the sole value of its 'aud' claim, per draft-ietf-oauth-rfc7523bis Section 4. The
	// authorization grant is unaffected: the draft preserves the looser rule for it.
	GetEnforceClientAssertionIssuerAudience(ctx context.Context) (enforce bool)
}

// AllowedIntrospectionAudiencesProvider is a provider used in contexts where the permitted audiences for an Access
// Token used to authenticate a request to the introspection endpoint is required to validate a request.
type AllowedIntrospectionAudiencesProvider interface {
	// GetAllowedIntrospectionAudiences returns the permitted audience list for introspection authentication. The
	// Access Token must carry at least one of them. An empty list does not disable the check: it means the URL the
	// request was made to is expected instead. See BearerAuthorization for the full fallback chain.
	GetAllowedIntrospectionAudiences(ctx context.Context) (audiences []string)
}

// AllowedIntrospectionScopesProvider is a provider used in contexts where the required scopes for an Access Token
// used to authenticate a request to the introspection endpoint is required to validate a request.
type AllowedIntrospectionScopesProvider interface {
	// GetAllowedIntrospectionScopes returns the scopes an Access Token may carry to authenticate a request to the
	// introspection endpoint. The token must carry at least one of them. Defaults to consts.ScopeIntrospection.
	GetAllowedIntrospectionScopes(ctx context.Context) (scopes []string)
}

// AuthorizeEndpointHandlersProvider returns the provider for configuring the authorize endpoint handlers.
type AuthorizeEndpointHandlersProvider interface {
	// GetAuthorizeEndpointHandlers returns the authorize endpoint handlers.
	GetAuthorizeEndpointHandlers(ctx context.Context) (handlers AuthorizeEndpointHandlers)
}

// TokenEndpointHandlersProvider returns the provider for configuring the token endpoint handlers.
type TokenEndpointHandlersProvider interface {
	// GetTokenEndpointHandlers returns the token endpoint handlers.
	GetTokenEndpointHandlers(ctx context.Context) (handlers TokenEndpointHandlers)
}

// AuthorizeEndpointBindingHandlersProvider returns the provider for configuring the authorize endpoint binding handlers.
type AuthorizeEndpointBindingHandlersProvider interface {
	// GetAuthorizeEndpointBindingHandlers returns the authorize endpoint binding handlers.
	GetAuthorizeEndpointBindingHandlers(ctx context.Context) (handlers AuthorizeEndpointBindingHandlers)
}

// TokenEndpointBindingHandlersProvider returns the provider for configuring the token endpoint binding handlers.
type TokenEndpointBindingHandlersProvider interface {
	// GetTokenEndpointBindingHandlers returns the token endpoint binding handlers.
	GetTokenEndpointBindingHandlers(ctx context.Context) (handlers TokenEndpointBindingHandlers)
}

// RFC8628DeviceAuthorizeEndpointBindingHandlersProvider returns the provider for configuring the device authorization
// endpoint binding handlers.
type RFC8628DeviceAuthorizeEndpointBindingHandlersProvider interface {
	// GetRFC8628DeviceAuthorizeEndpointBindingHandlers returns the device authorization endpoint binding handlers.
	GetRFC8628DeviceAuthorizeEndpointBindingHandlers(ctx context.Context) (handlers RFC8628DeviceAuthorizeEndpointBindingHandlers)
}

// TokenIntrospectionHandlersProvider returns the provider for configuring the token introspection handlers.
type TokenIntrospectionHandlersProvider interface {
	// GetTokenIntrospectionHandlers returns the token introspection handlers.
	GetTokenIntrospectionHandlers(ctx context.Context) (handlers TokenIntrospectionHandlers)
}

// RevocationHandlersProvider returns the provider for configuring the revocation handlers.
type RevocationHandlersProvider interface {
	// GetRevocationHandlers returns the revocation handlers.
	GetRevocationHandlers(ctx context.Context) (handlers RevocationHandlers)
}

// PushedAuthorizeRequestHandlersProvider returns the provider for configuring the PAR handlers.
type PushedAuthorizeRequestHandlersProvider interface {
	// GetPushedAuthorizeEndpointHandlers returns the handlers.
	GetPushedAuthorizeEndpointHandlers(ctx context.Context) (handlers PushedAuthorizeEndpointHandlers)
}

// RFC8628DeviceAuthorizeConfigProvider returns the provider for configuring the device authorization response.
//
// See: https://www.rfc-editor.org/rfc/rfc8628#section-3.2
type RFC8628DeviceAuthorizeConfigProvider interface {
	// GetRFC8628CodeLifespan returns the device and user code lifespan.
	GetRFC8628CodeLifespan(ctx context.Context) (lifespan time.Duration)

	// GetRFC8628UserVerificationURL returns the end-user verification URL returned to the device as the
	// 'verification_uri' where the user enters their user code to authorize the device.
	GetRFC8628UserVerificationURL(ctx context.Context) (url string)

	// GetRFC8628TokenPollingInterval returns the minimum interval the device should wait between polling the token
	// endpoint, returned to the device as the 'interval' value.
	GetRFC8628TokenPollingInterval(ctx context.Context) (interval time.Duration)
}

// RFC7591ClientRegistrationTokenSecretProvider returns the provider for configuring the secret client registration
// tokens are signed and verified with. It is declared once here, rather than inline wherever a configurator needs
// it, because it is embedded by more than one interface across packages (RFC7591ClientRegistrationConfigProvider
// here; HMACCoreStrategyConfigurator in handler/oauth2 and HMACSHAStrategyConfigurator in compose both need it to
// build a hmac.HMACStrategy for client registration tokens) and three independently-maintained copies of the same
// two methods and doc comments would drift.
type RFC7591ClientRegistrationTokenSecretProvider interface {
	// GetRFC7591ClientRegistrationGlobalSecret returns the secret used to sign client registration tokens. It is
	// deliberately separate from the global secret: a client management token never expires and RFC 7592 provides no
	// way to re-issue one, so signing it with the global secret would mean routine rotation of that secret
	// permanently locked every registered client out of its own registration.
	GetRFC7591ClientRegistrationGlobalSecret(ctx context.Context) (secret []byte, err error)

	// GetRFC7591ClientRegistrationRotatedGlobalSecrets returns the rotated client registration token secrets, which
	// remain valid for verification but are not used for signing.
	GetRFC7591ClientRegistrationRotatedGlobalSecrets(ctx context.Context) (secrets [][]byte, err error)
}

// RFC7591ClientRegistrationConfigProvider is the configuration provider for RFC 7591, RFC 7592, and OpenID Connect
// Dynamic Client Registration 1.0.
// RFC7591ClientRegistrationGrantTypesProvider returns the provider for the grant types a client may register for.
type RFC7591ClientRegistrationGrantTypesProvider interface {
	// GetRFC7591ClientRegistrationGrantTypes returns the grant types a client may register for. A registered grant
	// type outside this set is rejected with 'invalid_client_metadata'.
	GetRFC7591ClientRegistrationGrantTypes(ctx context.Context) (grantTypes []string)
}

type RFC7591ClientRegistrationConfigProvider interface {
	RFC7591ClientRegistrationTokenSecretProvider
	RFC7591ClientRegistrationGrantTypesProvider

	// GetRFC7591ClientRegistrationEndpointURL returns the absolute URL of the client registration endpoint. It is
	// used to build 'registration_client_uri' values and to audience initial access tokens.
	GetRFC7591ClientRegistrationEndpointURL(ctx context.Context) (endpoint string)

	// GetRFC7591ClientSecretLifespan returns the lifespan used to derive 'client_secret_expires_at'. A zero
	// duration indicates the secret does not expire.
	GetRFC7591ClientSecretLifespan(ctx context.Context) (lifespan time.Duration)

	// GetRFC7591ClientRegistrationStrategy returns the strategy used to construct and patch clients.
	GetRFC7591ClientRegistrationStrategy(ctx context.Context) (strategy ClientRegistrationStrategy)

	// GetRFC7591ClientRegistrationMetadataStrategy returns the strategy used to filter client metadata before it
	// reaches the client registration strategy and before it is returned to the client. A nil strategy leaves the
	// handlers to apply their default.
	GetRFC7591ClientRegistrationMetadataStrategy(ctx context.Context) (strategy ClientRegistrationMetadataStrategy)

	// GetRFC7591ClientRegistrationEndpointAuthStrategy returns the strategy used to authenticate requests at the
	// client registration and client configuration endpoints.
	GetRFC7591ClientRegistrationEndpointAuthStrategy(ctx context.Context) (strategy ClientRegistrationEndpointAuthStrategy)

	// GetRFC7591ClientRegistrationValidators returns the validators run in order against submitted metadata.
	GetRFC7591ClientRegistrationValidators(ctx context.Context) (validators []ClientRegistrationValidator)

	// GetRFC7591ClientRegistrationEndpointAudiences returns the audiences a client creation token may carry to be
	// accepted at the client registration endpoint. The token must carry at least one of them. An empty value means
	// the configured registration endpoint URL is expected, falling back to the URL the request was made to. A
	// deployment authorises a client to obtain such a token by adding one of these values to that client's
	// registered audience.
	GetRFC7591ClientRegistrationEndpointAudiences(ctx context.Context) (audiences []string)

	// GetRFC7591ClientRegistrationScopes returns the scopes a client creation token may carry to be accepted at the
	// client registration endpoint, defaulting to consts.ScopeClientRegistration. The token must carry at least one
	// of them. They are a second authorization dimension alongside the audience: the audience says a token is for
	// this endpoint, the scope says its holder may register clients. None of these scopes is ever grantable to a
	// registered client - see CheckGrantableScopes.
	GetRFC7591ClientRegistrationScopes(ctx context.Context) (scopes []string)
}

// RFC7591ClientRegistrationEndpointHandlersProvider returns the provider for configuring the client registration
// endpoint handlers.
type RFC7591ClientRegistrationEndpointHandlersProvider interface {
	// GetRFC7591ClientRegistrationEndpointHandlers returns the handlers.
	GetRFC7591ClientRegistrationEndpointHandlers(ctx context.Context) (handlers RFC7591ClientRegistrationEndpointHandlers)
}

// RFC7592ClientConfigurationEndpointHandlersProvider returns the provider for configuring the client configuration
// endpoint handlers.
type RFC7592ClientConfigurationEndpointHandlersProvider interface {
	// GetRFC7592ClientConfigurationEndpointHandlers returns the handlers.
	GetRFC7592ClientConfigurationEndpointHandlers(ctx context.Context) (handlers RFC7592ClientConfigurationEndpointHandlers)
}

// RFC8628DeviceAuthorizeEndpointHandlersProvider returns the provider for setting up the Device authorization handlers.
type RFC8628DeviceAuthorizeEndpointHandlersProvider interface {
	// GetRFC8628DeviceAuthorizeEndpointHandlers returns the handlers.
	GetRFC8628DeviceAuthorizeEndpointHandlers(ctx context.Context) (handlers RFC8628DeviceAuthorizeEndpointHandlers)
}

// RFC8628UserAuthorizeEndpointHandlersProvider returns the provider for setting up the Device grant user interaction handlers.
type RFC8628UserAuthorizeEndpointHandlersProvider interface {
	// GetRFC8628UserAuthorizeEndpointHandlers returns the handlers.
	GetRFC8628UserAuthorizeEndpointHandlers(ctx context.Context) (handlers RFC8628UserAuthorizeEndpointHandlers)
}

// RFC8693ConfigProvider is the configuration provider for RFC8693 Token Exchange.
type RFC8693ConfigProvider interface {
	// GetRFC8693TokenTypes returns the supported token types for Token Exchange keyed by their token type identifier
	// (i.e. the 'subject_token_type', 'actor_token_type', and 'requested_token_type' URN values).
	GetRFC8693TokenTypes(ctx context.Context) (types map[string]RFC8693TokenType)

	// GetDefaultRFC8693RequestedTokenType returns the token type identifier used as the 'requested_token_type' when the
	// Token Exchange request does not explicitly specify one.
	GetDefaultRFC8693RequestedTokenType(ctx context.Context) (tokenType string)

	// GetScopeStrategy returns the scope strategy used to validate scopes during Token Exchange.
	GetScopeStrategy(ctx context.Context) (strategy ScopeStrategy)

	// GetAudienceStrategy returns the audience strategy used to validate audiences during Token Exchange.
	GetAudienceStrategy(ctx context.Context) (strategy AudienceStrategy)

	// GetResourceStrategy returns the RFC 8707 resource indicator strategy used during Token Exchange.
	GetResourceStrategy(ctx context.Context) (strategy ResourceStrategy)
}

// UseLegacyErrorFormatProvider returns the provider for configuring whether to use the legacy error format.
//
// Deprecated: Do not use this flag anymore.
type UseLegacyErrorFormatProvider interface {
	// GetUseLegacyErrorFormat returns whether to use the legacy error format.
	//
	// Deprecated: Do not use this flag anymore.
	GetUseLegacyErrorFormat(ctx context.Context) (use bool)
}

// PushedAuthorizeRequestConfigProvider is the configuration provider for pushed
// authorization requests.
type PushedAuthorizeRequestConfigProvider interface {
	// GetPushedAuthorizeRequestURIPrefix is the request URI prefix. This is
	// usually 'urn:ietf:params:oauth:request_uri:'.
	GetPushedAuthorizeRequestURIPrefix(ctx context.Context) (prefix string)

	// GetPushedAuthorizeContextLifespan is the lifespan of the short-lived PAR context.
	GetPushedAuthorizeContextLifespan(ctx context.Context) (lifespan time.Duration)

	// GetRequirePushedAuthorizationRequests indicates if the use of Pushed Authorization Requests is gobally required.
	// In this mode, a client cannot pass authorize parameters at the 'authorize' endpoint. The 'authorize' endpoint
	// must contain the PAR request_uri.
	GetRequirePushedAuthorizationRequests(ctx context.Context) (enforce bool)
}

// JWTSecuredAuthorizationRequestConfigProvider is the configuration provider for JWT-Secured Authorization
// Requests (JAR).
//
// See: https://www.rfc-editor.org/rfc/rfc9101#section-9.2
type JWTSecuredAuthorizationRequestConfigProvider interface {
	// GetRequireSignedRequestObject is equivalent to the 'require_signed_request_object' authorization server metadata
	// value which indicates if the use of JWT-Secured Authorization Requests is globally required. In this mode a
	// client cannot pass authorization parameters via the OAuth 2.0 request syntax alone; the request must be
	// protected as a signed Request Object provided by either the 'request' or 'request_uri' parameter.
	GetRequireSignedRequestObject(ctx context.Context) (require bool)

	// GetRequireSignedRequestObjectSkipPushedAuthorizationRequests indicates if the requirement enforced by
	// GetRequireSignedRequestObject, or by the client metadata value of the same name, is skipped for requests made
	// directly to the Pushed Authorization Request endpoint. A Pushed Authorization Request is submitted via an
	// authenticated back-channel request which provides similar integrity guarantees to a Request Object, so some
	// deployments may consider it a sufficient substitute. This does not affect requests made to the authorization
	// endpoint.
	GetRequireSignedRequestObjectSkipPushedAuthorizationRequests(ctx context.Context) (skip bool)
}

// AuthorizeErrorFieldResponseStrategyProvider returns the provider for the strategy used to write authorization
// endpoint errors that cannot be delivered via a response_mode handler.
type AuthorizeErrorFieldResponseStrategyProvider interface {
	// GetAuthorizeErrorFieldResponseStrategy returns the AuthorizeErrorFieldResponseStrategy used to write authorization
	// endpoint errors directly to the response writer when no response_mode handler matches, such as when the user
	// cannot be safely redirected back to the client.
	GetAuthorizeErrorFieldResponseStrategy(ctx context.Context) (strategy AuthorizeErrorFieldResponseStrategy)
}

// TokenEndpointClientAuthStrategyProvider returns the provider for the client authentication strategy used at the token
// endpoint.
type TokenEndpointClientAuthStrategyProvider interface {
	// GetTokenEndpointClientAuthStrategy returns the EndpointClientAuthStrategy used to authenticate clients at the
	// token endpoint. This endpoint permits public clients to authenticate using the 'none' method.
	GetTokenEndpointClientAuthStrategy(ctx context.Context) (strategy EndpointClientAuthStrategy)
}

// IntrospectionEndpointClientAuthStrategyProvider returns the provider for the client authentication strategy used at
// the introspection endpoint.
type IntrospectionEndpointClientAuthStrategyProvider interface {
	// GetIntrospectionEndpointClientAuthStrategy returns the EndpointClientAuthStrategy used to authenticate clients at
	// the introspection endpoint. This endpoint does not permit public clients to authenticate using the 'none' method.
	GetIntrospectionEndpointClientAuthStrategy(ctx context.Context) (strategy EndpointClientAuthStrategy)
}

// IntrospectionEndpointClientAuthDisabledProvider returns the provider for turning off client authentication at the
// introspection endpoint.
type IntrospectionEndpointClientAuthDisabledProvider interface {
	// GetIntrospectionEndpointClientAuthDisabled returns true when the introspection endpoint must not accept client
	// authentication, leaving an Access Token presented as a bearer credential the only way to authorize a call.
	//
	// RFC 7662 Section 2.1 requires the endpoint to "require some form of authorization", naming client
	// authentication and a bearer token as the two examples, and leaves the choice open. This narrows it to the
	// second. It is off by default, because turning it on rejects every caller using the first.
	//
	// A deployment turns this on to make one property hold: that authorizing a call to this endpoint always means
	// presenting a credential carrying a grant, which can be scoped, audienced, bound to a key or a certificate, and
	// revoked on its own. Client credentials carry none of those - a client registered for introspection can call it
	// for as long as it holds its secret - so while both methods are available the weaker one sets the bar.
	GetIntrospectionEndpointClientAuthDisabled(ctx context.Context) (disabled bool)
}

// RevocationEndpointClientAuthStrategyProvider returns the provider for the client authentication strategy used at the
// revocation endpoint.
type RevocationEndpointClientAuthStrategyProvider interface {
	// GetRevocationEndpointClientAuthStrategy returns the EndpointClientAuthStrategy used to authenticate clients at the
	// revocation endpoint. This endpoint permits public clients to authenticate using the 'none' method.
	GetRevocationEndpointClientAuthStrategy(ctx context.Context) (strategy EndpointClientAuthStrategy)
}

// DPoPConfigProvider is the configuration provider for RFC 9449 DPoP.
type DPoPConfigProvider interface {
	// GetDPoPEnabled returns true if DPoP handling is enabled.
	GetDPoPEnabled(ctx context.Context) (enabled bool)

	// GetDPoPEnforce returns true if DPoP is required for all clients regardless of client metadata.
	GetDPoPEnforce(ctx context.Context) (enforce bool)

	// GetDPoPAllowedJWSAlgorithms returns the permitted asymmetric DPoP proof signing algorithms.
	GetDPoPAllowedJWSAlgorithms(ctx context.Context) (algs []string)

	// GetDPoPClockSkew returns the tolerance allowed for disagreement between this server's clock and the client's
	// when judging a DPoP proof's 'iat' claim. It widens the acceptance window at both ends and is not itself a
	// lifespan; see GetDPoPProofLifespan for that.
	GetDPoPClockSkew(ctx context.Context) (skew time.Duration)

	// GetDPoPProofLifespan returns how long a DPoP proof remains valid after the 'iat' it was minted with.
	//
	// Together with GetDPoPClockSkew this fixes the acceptance window: a proof is accepted from one clock skew
	// before its 'iat' until one lifespan plus one clock skew after it.
	GetDPoPProofLifespan(ctx context.Context) (lifespan time.Duration)

	// GetDPoPNonceRequired returns true if a server nonce is required in DPoP proofs.
	GetDPoPNonceRequired(ctx context.Context) (required bool)

	// GetDPoPNonceLifespan returns the lifespan of issued DPoP server nonces.
	GetDPoPNonceLifespan(ctx context.Context) (lifespan time.Duration)

	// GetDPoPStrategy returns the configured DPoP strategy, or nil when DPoP is not wired.
	GetDPoPStrategy(ctx context.Context) (strategy DPoPStrategy)
}

// MTLSConfigProvider is the configuration provider for RFC 8705 Mutual-TLS.
type MTLSConfigProvider interface {
	// GetMTLSEnabled returns true if RFC 8705 handling is enabled.
	GetMTLSEnabled(ctx context.Context) (enabled bool)

	// GetMTLSEnforce returns true if certificate-bound access tokens are required for all clients regardless of
	// client metadata.
	GetMTLSEnforce(ctx context.Context) (enforce bool)

	// GetMTLSClientCertificateHeader returns the name of the header carrying the client certificate forwarded by a
	// trusted TLS terminating proxy, or an empty string to never read one.
	GetMTLSClientCertificateHeader(ctx context.Context) (header string)
}

// ConfirmationConfigProvider is the configuration ApplyConfirmation consults to decide whether a given RFC 7800
// confirmation method may be asserted in a token or an introspection response.
//
// It deliberately restates the two 'enabled' getters rather than embedding DPoPConfigProvider and MTLSConfigProvider,
// which together carry ten methods where two are needed. Go interfaces are structural, so any configuration already
// satisfying those providers satisfies this one without change.
type ConfirmationConfigProvider interface {
	// GetDPoPEnabled returns true if DPoP handling is enabled.
	GetDPoPEnabled(ctx context.Context) (enabled bool)

	// GetMTLSEnabled returns true if RFC 8705 handling is enabled.
	GetMTLSEnabled(ctx context.Context) (enabled bool)
}

// IDTokenConfirmationConfigProvider is the configuration ApplyIDTokenConfirmation consults to decide whether the
// OpenID Connect Key Binding 1.0 confirmation may be asserted in an ID Token.
//
// Both getters are required, for the reason documented on confirmationMethod.enabled: the 'cnf' claim tells a Relying
// Party that a proof of possession was checked, and the handlers that check one run only while DPoP is enabled. A
// session outlives a configuration change, so a key recorded while DPoP was enabled survives on it afterwards; without
// the DPoP getter this claim would still be asserted for a refresh no proof was demanded on.
//
// It restates the getters rather than embedding the two providers, as ConfirmationConfigProvider does and for the same
// reason: Go interfaces are structural, so any configuration already satisfying those providers satisfies this one.
type IDTokenConfirmationConfigProvider interface {
	// GetOIDCKeyBindingEnabled returns true if OpenID Connect Key Binding 1.0 handling is enabled.
	GetOIDCKeyBindingEnabled(ctx context.Context) (enabled bool)

	// GetDPoPEnabled returns true if DPoP handling is enabled.
	GetDPoPEnabled(ctx context.Context) (enabled bool)
}

// OIDCKeyBindingConfigProvider is the configuration provider for OpenID Connect Key Binding 1.0.
type OIDCKeyBindingConfigProvider interface {
	// GetOIDCKeyBindingEnabled returns true if OpenID Connect Key Binding 1.0 handling is enabled.
	GetOIDCKeyBindingEnabled(ctx context.Context) (enabled bool)
}
