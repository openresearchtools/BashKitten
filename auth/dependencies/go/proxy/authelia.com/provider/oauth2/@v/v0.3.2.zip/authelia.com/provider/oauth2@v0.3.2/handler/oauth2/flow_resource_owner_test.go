// SPDX-FileCopyrightText: 2026 Authelia
//
// SPDX-License-Identifier: Apache-2.0

package oauth2

import (
	"net/url"
	"testing"
	"time"

	"github.com/pkg/errors"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.uber.org/mock/gomock"

	"authelia.com/provider/oauth2"
	"authelia.com/provider/oauth2/internal/consts"
	"authelia.com/provider/oauth2/testing/mock"
	"authelia.com/provider/oauth2/token/jwt"
)

func TestResourceOwnerFlow_HandleTokenEndpointRequest(t *testing.T) {
	testCases := []struct {
		name  string
		setup func(areq *oauth2.AccessRequest, store *mock.MockResourceOwnerPasswordCredentialsGrantStorage, config *oauth2.Config)
		err   string
		check func(t *testing.T, areq *oauth2.AccessRequest)
	}{
		{
			name: "ShouldFailNotResponsible",
			err:  "The handler is not responsible for this request.",
			setup: func(areq *oauth2.AccessRequest, store *mock.MockResourceOwnerPasswordCredentialsGrantStorage, config *oauth2.Config) {
				areq.GrantTypes = oauth2.Arguments{"123"}
			},
		},
		{
			name: "ShouldFailScopeMissing",
			setup: func(areq *oauth2.AccessRequest, store *mock.MockResourceOwnerPasswordCredentialsGrantStorage, config *oauth2.Config) {
				areq.GrantTypes = oauth2.Arguments{consts.GrantTypeResourceOwnerPasswordCredentials}
				areq.Client = &oauth2.DefaultClient{GrantTypes: oauth2.Arguments{consts.GrantTypeResourceOwnerPasswordCredentials}, Scopes: []string{}}
				areq.RequestedScope = []string{"foo-scope"}
			},
			err: "The requested scope is invalid, unknown, or malformed. The OAuth 2.0 Client is not allowed to request scope 'foo-scope'.",
		},
		{
			name: "ShouldFailAudienceMissing",
			setup: func(areq *oauth2.AccessRequest, store *mock.MockResourceOwnerPasswordCredentialsGrantStorage, config *oauth2.Config) {
				areq.GrantTypes = oauth2.Arguments{consts.GrantTypeResourceOwnerPasswordCredentials}
				areq.RequestedAudience = oauth2.Arguments{"https://www.authelia.com/api"}
				areq.Client = &oauth2.DefaultClient{GrantTypes: oauth2.Arguments{consts.GrantTypeResourceOwnerPasswordCredentials}, Scopes: []string{"foo-scope"}}
			},
			err: "The requested resource is invalid, missing, unknown, or malformed. Ensure the requested resource is an absolute URI without a fragment component that identifies a resource server known to the authorization server and that it is permitted for this client. Requested audience 'https://www.authelia.com/api' has not been whitelisted by the OAuth 2.0 Client.",
		},
		{
			name: "ShouldFailInvalidGrantTypeSpecified",
			setup: func(areq *oauth2.AccessRequest, store *mock.MockResourceOwnerPasswordCredentialsGrantStorage, config *oauth2.Config) {
				areq.GrantTypes = oauth2.Arguments{consts.GrantTypeResourceOwnerPasswordCredentials}
				areq.Client = &oauth2.DefaultClient{GrantTypes: oauth2.Arguments{consts.GrantTypeAuthorizationCode}, Scopes: []string{"foo-scope"}}
			},
			err: "The client is not authorized to request a token using this method. The client is not allowed to use authorization grant 'password'.",
		},
		{
			name: "ShouldFailInvalidCredentials",
			setup: func(areq *oauth2.AccessRequest, store *mock.MockResourceOwnerPasswordCredentialsGrantStorage, config *oauth2.Config) {
				areq.GrantTypes = oauth2.Arguments{consts.GrantTypeResourceOwnerPasswordCredentials}
				areq.Form.Set(consts.FormParameterUsername, "peter")
				areq.Form.Set(consts.FormParameterPassword, "pan")
				areq.Client = &oauth2.DefaultClient{GrantTypes: oauth2.Arguments{consts.GrantTypeResourceOwnerPasswordCredentials}, Scopes: []string{"foo-scope"}, Audience: []string{"https://www.authelia.com/api"}}

				store.EXPECT().Authenticate(gomock.Any(), "peter", "pan").Return("", oauth2.ErrNotFound)
			},
			err: "The provided authorization grant (e.g., authorization code, resource owner credentials) or refresh token is invalid, expired, revoked, does not match the redirection URI used in the authorization request, or was issued to another client. Unable to authenticate the provided username and password credentials. Could not find the requested resource(s).",
		},
		{
			name: "ShouldFailErrorOnLookup",
			setup: func(areq *oauth2.AccessRequest, store *mock.MockResourceOwnerPasswordCredentialsGrantStorage, config *oauth2.Config) {
				areq.GrantTypes = oauth2.Arguments{consts.GrantTypeResourceOwnerPasswordCredentials}
				areq.Form.Set(consts.FormParameterUsername, "peter")
				areq.Form.Set(consts.FormParameterPassword, "pan")
				areq.Client = &oauth2.DefaultClient{GrantTypes: oauth2.Arguments{consts.GrantTypeResourceOwnerPasswordCredentials}, Scopes: []string{"foo-scope"}, Audience: []string{"https://www.authelia.com/api"}}

				store.EXPECT().Authenticate(gomock.Any(), "peter", "pan").Return("", errors.New(""))
			},
			err: "The authorization server encountered an unexpected condition that prevented it from fulfilling the request.",
		},
		{
			name: "ShouldPass",
			setup: func(areq *oauth2.AccessRequest, store *mock.MockResourceOwnerPasswordCredentialsGrantStorage, config *oauth2.Config) {
				areq.GrantTypes = oauth2.Arguments{consts.GrantTypeResourceOwnerPasswordCredentials}
				areq.Form.Set(consts.FormParameterUsername, "peter")
				areq.Form.Set(consts.FormParameterPassword, "pan")
				areq.Client = &oauth2.DefaultClient{GrantTypes: oauth2.Arguments{consts.GrantTypeResourceOwnerPasswordCredentials}, Scopes: []string{"foo-scope"}, Audience: []string{"https://www.authelia.com/api"}}

				store.EXPECT().Authenticate(gomock.Any(), "peter", "pan").Return("", nil)
			},
			check: func(t *testing.T, areq *oauth2.AccessRequest) {
				assert.Equal(t, time.Now().Add(time.Hour).UTC().Truncate(jwt.TimePrecision), areq.GetSession().GetExpiresAt(oauth2.AccessToken))
				assert.Equal(t, time.Now().Add(time.Hour).UTC().Truncate(jwt.TimePrecision), areq.GetSession().GetExpiresAt(oauth2.RefreshToken))
			},
		},
		{
			// Coverage for the new behavior: when the session implements ResourceOwnerSession, the subject
			// returned by Authenticate MUST be set on the session via SetSubject so it surfaces in the issued
			// access token's 'sub' claim. oauth2.DefaultSession satisfies ResourceOwnerSession via its embedded
			// SetSubject method, so the default request session is sufficient to exercise this path.
			name: "ShouldSetSubjectOnSessionFromAuthenticate",
			setup: func(areq *oauth2.AccessRequest, store *mock.MockResourceOwnerPasswordCredentialsGrantStorage, config *oauth2.Config) {
				areq.GrantTypes = oauth2.Arguments{consts.GrantTypeResourceOwnerPasswordCredentials}
				areq.Form.Set(consts.FormParameterUsername, "peter")
				areq.Form.Set(consts.FormParameterPassword, "pan")
				areq.Client = &oauth2.DefaultClient{GrantTypes: oauth2.Arguments{consts.GrantTypeResourceOwnerPasswordCredentials}, Scopes: []string{"foo-scope"}, Audience: []string{"https://www.authelia.com/api"}}

				store.EXPECT().Authenticate(gomock.Any(), "peter", "pan").Return("peter-subject-id", nil)
			},
			check: func(t *testing.T, areq *oauth2.AccessRequest) {
				assert.Equal(t, "peter-subject-id", areq.GetSession().GetSubject(),
					"Authenticate's returned subject must propagate to the session so the issued access token carries it as the 'sub' claim")
			},
		},
		{
			// Coverage for the resilience branch: when the session does NOT implement ResourceOwnerSession,
			// the handler must skip the SetSubject call rather than panic. nonResourceOwnerSession satisfies
			// oauth2.Session but intentionally omits SetSubject(string), so the type assertion to
			// ResourceOwnerSession fails and the handler's `if session, ok := ...` branch is exercised.
			name: "ShouldNotPanicWhenSessionLacksResourceOwnerSession",
			setup: func(areq *oauth2.AccessRequest, store *mock.MockResourceOwnerPasswordCredentialsGrantStorage, config *oauth2.Config) {
				areq.GrantTypes = oauth2.Arguments{consts.GrantTypeResourceOwnerPasswordCredentials}
				areq.Form.Set(consts.FormParameterUsername, "peter")
				areq.Form.Set(consts.FormParameterPassword, "pan")
				areq.Client = &oauth2.DefaultClient{GrantTypes: oauth2.Arguments{consts.GrantTypeResourceOwnerPasswordCredentials}, Scopes: []string{"foo-scope"}, Audience: []string{"https://www.authelia.com/api"}}
				areq.Session = &nonResourceOwnerSession{}

				store.EXPECT().Authenticate(gomock.Any(), "peter", "pan").Return("peter-subject-id", nil)
			},
			check: func(t *testing.T, areq *oauth2.AccessRequest) {
				_, ok := areq.GetSession().(ResourceOwnerSession)
				assert.False(t, ok, "test guard: this case requires a session that does NOT implement ResourceOwnerSession")
			},
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			ctrl := gomock.NewController(t)
			defer ctrl.Finish()

			store := mock.NewMockResourceOwnerPasswordCredentialsGrantStorage(ctrl)

			areq := oauth2.NewAccessRequest(new(oauth2.DefaultSession))
			areq.Form = url.Values{}

			config := &oauth2.Config{
				AccessTokenLifespan:  time.Hour,
				RefreshTokenLifespan: time.Hour,
				ScopeStrategy:        oauth2.HierarchicScopeStrategy,
				AudienceStrategy:     oauth2.DefaultAudienceStrategy,
			}
			h := ResourceOwnerPasswordCredentialsGrantHandler{
				ResourceOwnerPasswordCredentialsGrantStorage: store,
				HandleHelper: &HandleHelper{
					AccessTokenStorage: store,
					Config:             config,
				},
				Config: config,
			}
			tc.setup(areq, store, config)
			err := h.HandleTokenEndpointRequest(t.Context(), areq)

			if tc.err != "" {
				require.EqualError(t, oauth2.ErrorToDebugRFC6749Error(err), tc.err)
			} else {
				require.NoError(t, err)
				if tc.check != nil {
					tc.check(t, areq)
				}
			}
		})
	}
}

func TestResourceOwnerFlow_PopulateTokenEndpointResponse(t *testing.T) {
	mockAT := "accesstoken.foo.bar"
	mockRT := "refreshtoken.bar.foo"

	testCases := []struct {
		name   string
		setup  func(areq *oauth2.AccessRequest, store *mock.MockResourceOwnerPasswordCredentialsGrantStorage, chgen *mock.MockAccessTokenStrategy, rtstr *mock.MockRefreshTokenStrategy, config *oauth2.Config)
		err    string
		expect func(t *testing.T, aresp *oauth2.AccessResponse)
	}{
		{
			name: "ShouldFailNotResponsible",
			err:  "The handler is not responsible for this request.",
			setup: func(areq *oauth2.AccessRequest, store *mock.MockResourceOwnerPasswordCredentialsGrantStorage, chgen *mock.MockAccessTokenStrategy, rtstr *mock.MockRefreshTokenStrategy, config *oauth2.Config) {
				areq.GrantTypes = oauth2.Arguments{""}
			},
		},
		{
			name: "ShouldPass",
			setup: func(areq *oauth2.AccessRequest, store *mock.MockResourceOwnerPasswordCredentialsGrantStorage, chgen *mock.MockAccessTokenStrategy, rtstr *mock.MockRefreshTokenStrategy, config *oauth2.Config) {
				areq.GrantTypes = oauth2.Arguments{consts.GrantTypeResourceOwnerPasswordCredentials}
				chgen.EXPECT().GenerateAccessToken(t.Context(), areq).Return(mockAT, "bar", nil)
				store.EXPECT().CreateAccessTokenSession(t.Context(), "bar", gomock.Eq(areq.Sanitize([]string{}))).Return(nil)
			},
			expect: func(t *testing.T, aresp *oauth2.AccessResponse) {
				assert.Nil(t, aresp.GetExtra(consts.AccessResponseRefreshToken))
			},
		},
		{
			name: "ShouldPassOfflineScope",
			setup: func(areq *oauth2.AccessRequest, store *mock.MockResourceOwnerPasswordCredentialsGrantStorage, chgen *mock.MockAccessTokenStrategy, rtstr *mock.MockRefreshTokenStrategy, config *oauth2.Config) {
				areq.GrantTypes = oauth2.Arguments{consts.GrantTypeResourceOwnerPasswordCredentials}
				areq.GrantScope(consts.ScopeOffline)
				chgen.EXPECT().GenerateAccessToken(t.Context(), areq).Return(mockAT, "at-sig", nil)
				store.EXPECT().CreateAccessTokenSession(t.Context(), "at-sig", gomock.Eq(areq.Sanitize([]string{}))).Return(nil)
				rtstr.EXPECT().GenerateRefreshToken(t.Context(), areq).Return(mockRT, "rt-sig", nil)
				store.EXPECT().CreateRefreshTokenSession(t.Context(), "rt-sig", "at-sig", gomock.Eq(areq.Sanitize([]string{}))).Return(nil)
			},
			expect: func(t *testing.T, aresp *oauth2.AccessResponse) {
				assert.NotNil(t, aresp.GetExtra(consts.AccessResponseRefreshToken))
			},
		},
		{
			name: "ShouldPassRefreshTokenWithoutOfflineScope",
			setup: func(areq *oauth2.AccessRequest, store *mock.MockResourceOwnerPasswordCredentialsGrantStorage, chgen *mock.MockAccessTokenStrategy, rtstr *mock.MockRefreshTokenStrategy, config *oauth2.Config) {
				config.RefreshTokenScopes = []string{}
				areq.GrantTypes = oauth2.Arguments{consts.GrantTypeResourceOwnerPasswordCredentials}
				chgen.EXPECT().GenerateAccessToken(t.Context(), areq).Return(mockAT, "at-sig", nil)
				store.EXPECT().CreateAccessTokenSession(t.Context(), "at-sig", gomock.Eq(areq.Sanitize([]string{}))).Return(nil)
				rtstr.EXPECT().GenerateRefreshToken(t.Context(), areq).Return(mockRT, "rt-sig", nil)
				store.EXPECT().CreateRefreshTokenSession(t.Context(), "rt-sig", "at-sig", gomock.Eq(areq.Sanitize([]string{}))).Return(nil)
			},
			expect: func(t *testing.T, aresp *oauth2.AccessResponse) {
				assert.NotNil(t, aresp.GetExtra(consts.AccessResponseRefreshToken))
			},
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			ctrl := gomock.NewController(t)
			defer ctrl.Finish()

			store := mock.NewMockResourceOwnerPasswordCredentialsGrantStorage(ctrl)
			chgen := mock.NewMockAccessTokenStrategy(ctrl)
			rtstr := mock.NewMockRefreshTokenStrategy(ctrl)

			areq := oauth2.NewAccessRequest(nil)
			aresp := oauth2.NewAccessResponse()
			areq.Session = &oauth2.DefaultSession{}
			config := &oauth2.Config{
				RefreshTokenScopes:  []string{consts.ScopeOffline},
				AccessTokenLifespan: time.Hour,
			}
			h := ResourceOwnerPasswordCredentialsGrantHandler{
				ResourceOwnerPasswordCredentialsGrantStorage: store,
				HandleHelper: &HandleHelper{
					AccessTokenStorage:  store,
					AccessTokenStrategy: chgen, Config: config,
				},
				RefreshTokenStrategy: rtstr, Config: config,
			}
			tc.setup(areq, store, chgen, rtstr, config)
			err := h.PopulateTokenEndpointResponse(t.Context(), areq, aresp)
			if tc.err != "" {
				assert.EqualError(t, oauth2.ErrorToDebugRFC6749Error(err), tc.err)
			} else {
				assert.NoError(t, err)
				if tc.expect != nil {
					tc.expect(t, aresp)
				}
			}
		})
	}
}

// nonResourceOwnerSession is an oauth2.Session implementation that intentionally omits SetSubject(string), so it
// does NOT satisfy ResourceOwnerSession. Used to exercise the handler's "skip subject propagation" branch.
type nonResourceOwnerSession struct {
	expiresAt map[oauth2.TokenType]time.Time
}

func (s *nonResourceOwnerSession) SetExpiresAt(key oauth2.TokenType, exp time.Time) {
	if s.expiresAt == nil {
		s.expiresAt = map[oauth2.TokenType]time.Time{}
	}

	s.expiresAt[key] = exp
}

func (s *nonResourceOwnerSession) GetExpiresAt(key oauth2.TokenType) time.Time {
	return s.expiresAt[key]
}

func (s *nonResourceOwnerSession) GetUsername() string { return "" }

func (s *nonResourceOwnerSession) GetSubject() string { return "" }

func (s *nonResourceOwnerSession) Clone() oauth2.Session { return &nonResourceOwnerSession{} }
