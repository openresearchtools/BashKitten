// SPDX-FileCopyrightText: 2026 Authelia
//
// SPDX-License-Identifier: Apache-2.0

package oauth2

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"authelia.com/provider/oauth2"
	"authelia.com/provider/oauth2/internal/consts"
	"authelia.com/provider/oauth2/internal/gen"
	"authelia.com/provider/oauth2/token/jwt"
)

func TestAccessToken(t *testing.T) {
	scopeFields := []struct {
		name  string
		field jwt.JWTScopeFieldEnum
	}{
		{name: "ScopeFieldList", field: jwt.JWTScopeFieldList},
		{name: "ScopeFieldString", field: jwt.JWTScopeFieldString},
		{name: "ScopeFieldBoth", field: jwt.JWTScopeFieldBoth},
	}

	for _, scopeField := range scopeFields {
		testCases := []struct {
			name string
			r    *oauth2.Request
			pass bool
		}{
			{
				name: "ShouldAcceptAValidToken",
				r:    jwtValidCase(oauth2.AccessToken),
				pass: true,
			},
			{
				name: "ShouldRejectAnExpiredToken",
				r:    jwtExpiredCase(oauth2.AccessToken, time.Unix(1726972738, 0)),
				pass: false,
			},
			{
				name: "ShouldAcceptAValidTokenWithZeroRefreshExpiry",
				r:    jwtValidCaseWithZeroRefreshExpiry(oauth2.AccessToken),
				pass: true,
			},
			{
				name: "ShouldAcceptAValidTokenWithRefreshExpiry",
				r:    jwtValidCaseWithRefreshExpiry(oauth2.AccessToken),
				pass: true,
			},
		}

		for _, tc := range testCases {
			t.Run(tc.name, func(t *testing.T) {
				config := &oauth2.Config{
					EnforceJWTProfileAccessTokens: true,
					GlobalSecret:                  []byte("foofoofoofoofoofoofoofoofoofoofoo"),
					JWTScopeClaimKey:              scopeField.field,
				}

				jwtStrategy := &jwt.DefaultStrategy{
					Config: config,
					Issuer: jwt.NewDefaultIssuerRS256Unverified(rsaKey),
				}

				strategy := NewCoreStrategy(config, "authelia_%s_", jwtStrategy)

				token, signature, err := strategy.GenerateAccessToken(t.Context(), tc.r)
				assert.NoError(t, err)

				parts := strings.Split(token, ".")
				require.Len(t, parts, 3, "%s - %v", token, parts)
				assert.Equal(t, parts[2], signature)

				rawPayload, err := base64.RawURLEncoding.DecodeString(parts[1])
				require.NoError(t, err)

				var payload map[string]any

				require.NoError(t, json.Unmarshal(rawPayload, &payload))

				if scopeField.field == jwt.JWTScopeFieldList || scopeField.field == jwt.JWTScopeFieldBoth {
					scope, ok := payload[consts.ClaimScopeNonStandard]
					require.True(t, ok)
					assert.Equal(t, []any{consts.ScopeEmail, consts.ScopeOffline}, scope)
				}
				if scopeField.field == jwt.JWTScopeFieldString || scopeField.field == jwt.JWTScopeFieldBoth {
					scope, ok := payload[consts.ClaimScope]
					require.True(t, ok)
					assert.Equal(t, "email offline", scope)
				}

				rawHeader, err := base64.RawURLEncoding.DecodeString(parts[0])
				require.NoError(t, err)
				var header map[string]any

				require.NoError(t, json.Unmarshal(rawHeader, &header))

				assert.Equal(t, consts.JSONWebTokenTypeAccessToken, header[consts.JSONWebTokenHeaderType])

				extraClaimsSession, ok := tc.r.GetSession().(oauth2.ExtraClaimsSession)
				require.True(t, ok)
				claims := extraClaimsSession.GetExtraClaims()
				assert.Equal(t, "bar", claims["foo"])
				// Returned, but will be ignored by the introspect handler.
				assert.Equal(t, "peter", claims[consts.ClaimSubject])
				assert.Equal(t, []string{"group0"}, claims[consts.ClaimAudience])
				// Scope field is always a string.
				assert.Equal(t, "email offline", claims[consts.ClaimScope])

				assert.WithinDuration(t, time.Now(), anyInt64ToTime(claims[consts.ClaimIssuedAt]), time.Second)
				assert.WithinDuration(t, time.Now(), anyInt64ToTime(claims[consts.ClaimNotBefore]), time.Second)

				err = strategy.ValidateAccessToken(context.Background(), tc.r, token)
				if tc.pass {
					assert.NoError(t, err)
				} else {
					assert.Error(t, err)
				}
			})
		}
	}
}

func TestGenerateJWTIncludesCnf(t *testing.T) {
	config := &oauth2.Config{
		EnforceJWTProfileAccessTokens: true,
		DPoPEnabled:                   true,
		MTLSEnabled:                   true,
		GlobalSecret:                  []byte("foofoofoofoofoofoofoofoofoofoofoo"),
	}

	jwtStrategy := &jwt.DefaultStrategy{
		Config: config,
		Issuer: jwt.NewDefaultIssuerRS256Unverified(rsaKey),
	}

	strategy := NewCoreStrategy(config, "authelia_%s_", jwtStrategy)

	t.Run("ShouldIncludeCnfWhenDPoPBound", func(t *testing.T) {
		r := jwtValidCase(oauth2.AccessToken)

		dpopSession, ok := r.GetSession().(oauth2.DPoPBoundSession)
		require.True(t, ok)
		dpopSession.SetDPoPJWKThumbprint("test-jkt")

		token, _, err := strategy.GenerateAccessToken(t.Context(), r)
		require.NoError(t, err)

		parts := strings.Split(token, ".")
		require.Len(t, parts, 3, "%s - %v", token, parts)

		rawPayload, err := base64.RawURLEncoding.DecodeString(parts[1])
		require.NoError(t, err)

		var payload map[string]any
		require.NoError(t, json.Unmarshal(rawPayload, &payload))

		cnf, ok := payload[jwt.ClaimConfirmation].(map[string]any)
		require.True(t, ok, "expected cnf claim to be present and a map, got %#v", payload[jwt.ClaimConfirmation])
		assert.Equal(t, "test-jkt", cnf[jwt.ClaimConfirmationJWKThumbprint])
	})

	t.Run("ShouldNotIncludeCnfWhenNotDPoPBound", func(t *testing.T) {
		r := jwtValidCase(oauth2.AccessToken)

		token, _, err := strategy.GenerateAccessToken(t.Context(), r)
		require.NoError(t, err)

		parts := strings.Split(token, ".")
		require.Len(t, parts, 3, "%s - %v", token, parts)

		rawPayload, err := base64.RawURLEncoding.DecodeString(parts[1])
		require.NoError(t, err)

		var payload map[string]any
		require.NoError(t, json.Unmarshal(rawPayload, &payload))

		assert.NotContains(t, payload, jwt.ClaimConfirmation)
	})

	// The session's extra claims are merged into the token's claims, so a 'cnf.jkt' placed there must not be able to
	// assert a binding no DPoP proof was ever checked against.
	t.Run("ShouldNotAllowExtraClaimsToForgeCnfWhenNotDPoPBound", func(t *testing.T) {
		r := jwtValidCase(oauth2.AccessToken)
		r.GetSession().(*JWTSession).JWTClaims.Extra[jwt.ClaimConfirmation] = map[string]any{
			jwt.ClaimConfirmationJWKThumbprint: "forged-jkt",
		}

		token, _, err := strategy.GenerateAccessToken(t.Context(), r)
		require.NoError(t, err)

		parts := strings.Split(token, ".")
		require.Len(t, parts, 3, "%s - %v", token, parts)

		rawPayload, err := base64.RawURLEncoding.DecodeString(parts[1])
		require.NoError(t, err)

		var payload map[string]any
		require.NoError(t, json.Unmarshal(rawPayload, &payload))

		assert.NotContains(t, payload, jwt.ClaimConfirmation)
	})

	t.Run("ShouldNotAllowExtraClaimsToForgeCnfWhenDPoPBound", func(t *testing.T) {
		r := jwtValidCase(oauth2.AccessToken)
		r.GetSession().(*JWTSession).JWTClaims.Extra[jwt.ClaimConfirmation] = map[string]any{
			jwt.ClaimConfirmationJWKThumbprint: "forged-jkt",
		}
		r.GetSession().(oauth2.DPoPBoundSession).SetDPoPJWKThumbprint("test-jkt")

		token, _, err := strategy.GenerateAccessToken(t.Context(), r)
		require.NoError(t, err)

		parts := strings.Split(token, ".")
		require.Len(t, parts, 3, "%s - %v", token, parts)

		rawPayload, err := base64.RawURLEncoding.DecodeString(parts[1])
		require.NoError(t, err)

		var payload map[string]any
		require.NoError(t, json.Unmarshal(rawPayload, &payload))

		cnf, ok := payload[jwt.ClaimConfirmation].(map[string]any)
		require.True(t, ok, "expected cnf claim to be present and a map, got %#v", payload[jwt.ClaimConfirmation])
		assert.Equal(t, "test-jkt", cnf[jwt.ClaimConfirmationJWKThumbprint])
	})

	t.Run("ShouldNotAllowExtraClaimsToSupplyOtherConfirmationMethods", func(t *testing.T) {
		r := jwtValidCase(oauth2.AccessToken)
		r.GetSession().(*JWTSession).JWTClaims.Extra[jwt.ClaimConfirmation] = map[string]any{
			jwt.ClaimConfirmationX509SHA256Thumbprint: "forged-x5t",
		}
		r.GetSession().(oauth2.DPoPBoundSession).SetDPoPJWKThumbprint("test-jkt")

		token, _, err := strategy.GenerateAccessToken(t.Context(), r)
		require.NoError(t, err)

		parts := strings.Split(token, ".")
		require.Len(t, parts, 3, "%s - %v", token, parts)

		rawPayload, err := base64.RawURLEncoding.DecodeString(parts[1])
		require.NoError(t, err)

		var payload map[string]any
		require.NoError(t, json.Unmarshal(rawPayload, &payload))

		cnf, ok := payload[jwt.ClaimConfirmation].(map[string]any)
		require.True(t, ok, "expected cnf claim to be present and a map, got %#v", payload[jwt.ClaimConfirmation])
		assert.Equal(t, "test-jkt", cnf[jwt.ClaimConfirmationJWKThumbprint])
		assert.NotContains(t, cnf, jwt.ClaimConfirmationX509SHA256Thumbprint)
	})
}

func TestSplitN(t *testing.T) {
	value1 := "a.b.c"

	split1 := strings.SplitN(value1, ".", 3)

	value2 := "a.b"

	split2 := strings.SplitN(value2, ".", 3)

	value3 := "a.b.c.d"

	split3 := strings.SplitN(value3, ".", 3)

	assert.Len(t, split1, 3)
	assert.Len(t, split2, 2)
	assert.Len(t, split3, 3)
}

// TestGenerateJWTIncludesClientID covers the 'client_id' claim RFC 9068 Section 2.2 makes REQUIRED of a JWT profile
// access token.
func TestGenerateJWTIncludesClientID(t *testing.T) {
	config := &oauth2.Config{
		EnforceJWTProfileAccessTokens: true,
		GlobalSecret:                  []byte("foofoofoofoofoofoofoofoofoofoofoo"),
	}

	jwtStrategy := &jwt.DefaultStrategy{
		Config: config,
		Issuer: jwt.NewDefaultIssuerRS256Unverified(rsaKey),
	}

	strategy := NewCoreStrategy(config, "authelia_%s_", jwtStrategy)

	r := jwtValidCase(oauth2.AccessToken)
	r.Client = &oauth2.DefaultClient{ID: "client-abc"}

	token, _, err := strategy.GenerateAccessToken(t.Context(), r)
	require.NoError(t, err)

	parts := strings.Split(token, ".")
	require.Len(t, parts, 3, "%s - %v", token, parts)

	rawPayload, err := base64.RawURLEncoding.DecodeString(parts[1])
	require.NoError(t, err)

	var payload map[string]any

	require.NoError(t, json.Unmarshal(rawPayload, &payload))

	assert.Equal(t, "client-abc", payload[consts.ClaimClientIdentifier])
}

func anyInt64ToTime(in any) time.Time {
	return time.Unix(in.(int64), 0)
}

var rsaKey = gen.MustRSAKey()

// returns a valid JWT type. The JWTClaims.ExpirationTime time is intentionally
// left empty to ensure it is pulled from the session's ExpirationTime map for
// the given oauth2.TokenType.
var jwtValidCase = func(tokenType oauth2.TokenType) *oauth2.Request {
	r := &oauth2.Request{
		Client: &oauth2.DefaultClient{
			ClientSecret: mustNewBCryptClientSecretPlain("foobarfoobarfoobarfoobar"),
		},
		Session: &JWTSession{
			JWTClaims: &jwt.JWTClaims{
				Issuer:    "oauth2",
				Subject:   "peter",
				IssuedAt:  time.Now().UTC(),
				NotBefore: time.Now().UTC(),
				Extra:     map[string]any{"foo": "bar"},
			},
			JWTHeader: &jwt.Headers{
				Extra: make(map[string]any),
			},
			ExpiresAt: map[oauth2.TokenType]time.Time{
				tokenType: time.Now().UTC().Add(time.Hour),
			},
		},
	}
	r.SetRequestedScopes([]string{consts.ScopeEmail, consts.ScopeOffline})
	r.GrantScope(consts.ScopeEmail)
	r.GrantScope(consts.ScopeOffline)
	r.SetRequestedAudience([]string{"group0"})
	r.GrantAudience("group0")
	return r
}

var jwtInvalidTypCase = func(tokenType oauth2.TokenType) *oauth2.Request {
	r := &oauth2.Request{
		Client: &oauth2.DefaultClient{
			ClientSecret: mustNewBCryptClientSecretPlain("xfoobarfoobarfoobarfoobar"),
		},
		Session: &JWTSession{
			JWTClaims: &jwt.JWTClaims{
				Issuer:    "oauth2",
				Subject:   "peter",
				IssuedAt:  time.Now().UTC(),
				NotBefore: time.Now().UTC(),
				Extra:     map[string]any{"foo": "bar"},
			},
			JWTHeader: &jwt.Headers{
				Extra: map[string]any{consts.JSONWebTokenHeaderType: consts.JSONWebTokenTypeJWT},
			},
			ExpiresAt: map[oauth2.TokenType]time.Time{
				tokenType: time.Now().UTC().Add(time.Hour),
			},
		},
	}
	r.SetRequestedScopes([]string{consts.ScopeEmail, consts.ScopeOffline})
	r.GrantScope(consts.ScopeEmail)
	r.GrantScope(consts.ScopeOffline)
	r.SetRequestedAudience([]string{"group0"})
	r.GrantAudience("group0")
	return r
}

var jwtValidCaseWithZeroRefreshExpiry = func(tokenType oauth2.TokenType) *oauth2.Request {
	r := &oauth2.Request{
		Client: &oauth2.DefaultClient{
			ClientSecret: mustNewBCryptClientSecretPlain("foobarfoobarfoobarfoobar"),
		},
		Session: &JWTSession{
			JWTClaims: &jwt.JWTClaims{
				Issuer:    "oauth2",
				Subject:   "peter",
				IssuedAt:  time.Now().UTC(),
				NotBefore: time.Now().UTC(),
				Extra:     map[string]any{"foo": "bar"},
			},
			JWTHeader: &jwt.Headers{
				Extra: make(map[string]any),
			},
			ExpiresAt: map[oauth2.TokenType]time.Time{
				tokenType:           time.Now().UTC().Add(time.Hour),
				oauth2.RefreshToken: {},
			},
		},
	}
	r.SetRequestedScopes([]string{consts.ScopeEmail, consts.ScopeOffline})
	r.GrantScope(consts.ScopeEmail)
	r.GrantScope(consts.ScopeOffline)
	r.SetRequestedAudience([]string{"group0"})
	r.GrantAudience("group0")
	return r
}

var jwtValidCaseWithRefreshExpiry = func(tokenType oauth2.TokenType) *oauth2.Request {
	r := &oauth2.Request{
		Client: &oauth2.DefaultClient{
			ClientSecret: mustNewBCryptClientSecretPlain("foobarfoobarfoobarfoobar"),
		},
		Session: &JWTSession{
			JWTClaims: &jwt.JWTClaims{
				Issuer:    "oauth2",
				Subject:   "peter",
				IssuedAt:  time.Now().UTC(),
				NotBefore: time.Now().UTC(),
				Extra:     map[string]any{"foo": "bar"},
			},
			JWTHeader: &jwt.Headers{
				Extra: make(map[string]any),
			},
			ExpiresAt: map[oauth2.TokenType]time.Time{
				tokenType:           time.Now().UTC().Add(time.Hour),
				oauth2.RefreshToken: time.Now().UTC().Add(time.Hour * 2).Truncate(time.Hour),
			},
		},
	}
	r.SetRequestedScopes([]string{consts.ScopeEmail, consts.ScopeOffline})
	r.GrantScope(consts.ScopeEmail)
	r.GrantScope(consts.ScopeOffline)
	r.SetRequestedAudience([]string{"group0"})
	r.GrantAudience("group0")
	return r
}

// returns an expired JWT type. The JWTClaims.ExpirationTime time is intentionally
// left empty to ensure it is pulled from the session's ExpirationTime map for
// the given oauth2.TokenType.
var jwtExpiredCase = func(tokenType oauth2.TokenType, now time.Time) *oauth2.Request {
	r := &oauth2.Request{
		Client: &oauth2.DefaultClient{
			ClientSecret: mustNewBCryptClientSecretPlain("foobarfoobarfoobarfoobar"),
		},
		Session: &JWTSession{
			JWTClaims: &jwt.JWTClaims{
				Issuer:    "oauth2",
				Subject:   "peter",
				IssuedAt:  now.UTC().Add(-time.Minute * 10),
				NotBefore: now.UTC().Add(-time.Minute * 10),
				ExpiresAt: now.UTC().Add(-time.Minute),
				Extra:     map[string]any{"foo": "bar"},
			},
			JWTHeader: &jwt.Headers{
				Extra: make(map[string]any),
			},
			ExpiresAt: map[oauth2.TokenType]time.Time{
				tokenType: now.UTC().Add(-time.Hour),
			},
		},
	}
	r.SetRequestedScopes([]string{consts.ScopeEmail, consts.ScopeOffline})
	r.GrantScope(consts.ScopeEmail)
	r.GrantScope(consts.ScopeOffline)
	r.SetRequestedAudience([]string{"group0"})
	r.GrantAudience("group0")
	return r
}
