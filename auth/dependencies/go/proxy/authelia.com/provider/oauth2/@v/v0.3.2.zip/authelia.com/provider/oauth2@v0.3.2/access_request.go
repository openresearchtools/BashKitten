// SPDX-FileCopyrightText: 2026 Authelia
//
// SPDX-License-Identifier: Apache-2.0

package oauth2

type AccessRequest struct {
	GrantTypes       Arguments `json:"grantTypes" gorethink:"grantTypes"`
	HandledGrantType Arguments `json:"handledGrantType" gorethink:"handledGrantType"`

	Request
}

// NewAccessRequest returns an empty AccessRequest seeded with the given session.
func NewAccessRequest(session Session) *AccessRequest {
	r := &AccessRequest{
		GrantTypes:       Arguments{},
		HandledGrantType: Arguments{},
		Request:          *NewRequest(),
	}
	r.Session = session
	return r
}

func (a *AccessRequest) GetGrantTypes() Arguments {
	return a.GrantTypes
}

func (a *AccessRequest) SetGrantedScopes(scopes Arguments) {
	a.GrantedScope = scopes
}

// SanitizeRestoreRefreshTokenOriginalRequester returns a sanitized Requester carrying the original refresh token
// session's requested and granted scopes alongside the supplied requester's ID. It is used by refresh token handlers to
// preserve the lineage between an issued refresh token and its preceding access request.
func (a *AccessRequest) SanitizeRestoreRefreshTokenOriginalRequester(requester Requester) Requester {
	r := a.Sanitize(nil).(*Request)

	ar := &AccessRequest{
		Request: *r,
	}

	ar.SetID(requester.GetID())

	ar.SetRequestedScopes(requester.GetRequestedScopes())
	ar.SetGrantedScopes(requester.GetGrantedScopes())

	return ar
}
