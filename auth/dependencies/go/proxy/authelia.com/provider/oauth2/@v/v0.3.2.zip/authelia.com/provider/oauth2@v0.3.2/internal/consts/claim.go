// SPDX-FileCopyrightText: 2026 Authelia
//
// SPDX-License-Identifier: Apache-2.0

package consts

// Registered Claim strings. See https://www.iana.org/assignments/jwt/jwt.xhtml.
const (
	ClaimJWTID                               = "jti"
	ClaimSessionID                           = "sid"
	ClaimIssuedAt                            = "iat"
	ClaimNotBefore                           = "nbf"
	ClaimRequestedAt                         = "rat"
	ClaimExpirationTime                      = "exp"
	ClaimAuthenticationTime                  = "auth_time"
	ClaimIssuer                              = valueIss
	ClaimSubject                             = "sub"
	ClaimAudience                            = "aud"
	ClaimGroups                              = "groups"
	ClaimFullName                            = "name"
	ClaimPreferredUsername                   = "preferred_username"
	ClaimPreferredEmail                      = "email"
	ClaimEmailVerified                       = "email_verified"
	ClaimAuthorizedParty                     = "azp"
	ClaimAuthenticationContextClassReference = "acr"
	ClaimAuthenticationMethodsReference      = "amr"
	ClaimClientIdentifier                    = valueClientID
	ClaimScope                               = valueScope
	ClaimScopeNonStandard                    = "scp"
	ClaimExtra                               = "ext"
	ClaimActive                              = "active"
	ClaimUsername                            = "username"
	ClaimTokenIntrospection                  = "token_introspection"
	ClaimAccessTokenHash                     = "at_hash"
	ClaimCodeHash                            = "c_hash"
	ClaimStateHash                           = "s_hash"
	ClaimNonce                               = valueNonce
	ClaimAuthorizedActor                     = "may_act"
	ClaimActor                               = "act"
	ClaimEvents                              = "events"
	ClaimConfirmation                        = "cnf"
	ClaimConfirmationJWKThumbprint           = "jkt"
	ClaimConfirmationX509SHA256Thumbprint    = "x5t#S256"
	ClaimHTTPMethod                          = "htm"
	ClaimHTTPURI                             = "htu"
	ClaimDPoPAccessTokenHash                 = "ath"
	ClaimConfirmationJWK                     = "jwk"
	ClaimDPoPCodeHash                        = "c_s256"
)

const (
	ClaimEventBackChannelLogout = "http://schemas.openid.net/event/backchannel-logout"
)
