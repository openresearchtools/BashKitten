// SPDX-FileCopyrightText: 2026 Authelia
//
// SPDX-License-Identifier: Apache-2.0

package rfc8693

import (
	"context"
	"encoding/json"
	"time"

	"github.com/google/uuid"

	"authelia.com/provider/oauth2"
	"authelia.com/provider/oauth2/handler/openid"
	"authelia.com/provider/oauth2/internal/consts"
	"authelia.com/provider/oauth2/token/jwt"
	"authelia.com/provider/oauth2/x/errorsx"
)

type CustomJWTTypeHandler struct {
	Config oauth2.RFC8693ConfigProvider

	jwt.Strategy
	Storage
}

// HandleTokenEndpointRequest implements https://tools.ietf.org/html/rfc6749#section-4.3.2
func (c *CustomJWTTypeHandler) HandleTokenEndpointRequest(ctx context.Context, request oauth2.AccessRequester) (err error) {
	if !c.CanHandleTokenEndpointRequest(ctx, request) {
		return errorsx.WithStack(oauth2.ErrUnknownRequest)
	}

	var (
		session Session
		ok      bool
	)

	if session, ok = request.GetSession().(Session); !ok || session == nil {
		return errorsx.WithStack(oauth2.ErrServerError.WithDebug("Failed to perform token exchange because the session is not of the right type."))
	}

	form := request.GetRequestForm()
	tokenTypes := c.Config.GetRFC8693TokenTypes(ctx)
	actorTokenType := tokenTypes[form.Get(consts.FormParameterActorTokenType)]
	subjectTokenType := tokenTypes[form.Get(consts.FormParameterSubjectTokenType)]

	if actorTokenType != nil && actorTokenType.GetType(ctx) == consts.TokenTypeRFC8693JWT {
		var unpacked map[string]any

		token := form.Get(consts.FormParameterActorToken)

		if unpacked, err = c.validate(ctx, request, actorTokenType, token, tokenRoleActor); err != nil {
			return err
		}

		session.SetActorToken(unpacked)
	}

	if subjectTokenType != nil && subjectTokenType.GetType(ctx) == consts.TokenTypeRFC8693JWT {
		var unpacked map[string]any

		token := form.Get(consts.FormParameterSubjectToken)

		if unpacked, err = c.validate(ctx, request, subjectTokenType, token, tokenRoleSubject); err != nil {
			return err
		}

		session.SetSubjectToken(unpacked)

		var subject string

		// Get the subject and populate session.
		if subject, err = c.GetSubjectForTokenExchange(ctx, request, unpacked); err != nil {
			return err
		}

		session.SetSubject(subject)
	}

	return nil
}

// PopulateTokenEndpointResponse implements https://tools.ietf.org/html/rfc6749#section-4.3.3
func (c *CustomJWTTypeHandler) PopulateTokenEndpointResponse(ctx context.Context, request oauth2.AccessRequester, response oauth2.AccessResponder) (err error) {
	if !c.CanHandleTokenEndpointRequest(ctx, request) {
		return errorsx.WithStack(oauth2.ErrUnknownRequest)
	}

	var (
		session Session
		ok      bool
	)

	if session, ok = request.GetSession().(Session); !ok || session == nil {
		return errorsx.WithStack(oauth2.ErrServerError.WithDebug("Failed to perform token exchange because the session is not of the right type."))
	}

	form := request.GetRequestForm()
	requestedTokenType := form.Get(consts.FormParameterRequestedTokenType)

	if requestedTokenType == "" {
		requestedTokenType = c.Config.GetDefaultRFC8693RequestedTokenType(ctx)
	}

	tokenTypes := c.Config.GetRFC8693TokenTypes(ctx)
	tokenType := tokenTypes[requestedTokenType]

	if tokenType == nil || tokenType.GetType(ctx) != consts.TokenTypeRFC8693JWT {
		return nil
	}

	if err = c.issue(ctx, request, tokenType, response); err != nil {
		return err
	}

	return nil
}

// CanSkipClientAuth indicates if client auth can be skipped
func (c *CustomJWTTypeHandler) CanSkipClientAuth(_ context.Context, _ oauth2.AccessRequester) bool {
	return false
}

// CanHandleTokenEndpointRequest indicates if the token endpoint request can be handled
func (c *CustomJWTTypeHandler) CanHandleTokenEndpointRequest(_ context.Context, request oauth2.AccessRequester) bool {
	// The parameter 'grant_type' is REQUIRED. Value MUST be set to "urn:ietf:params:oauth:grant-type:token-exchange".
	return request.GetGrantTypes().ExactOne(consts.GrantTypeOAuthTokenExchange)
}

func (c *CustomJWTTypeHandler) validate(ctx context.Context, request oauth2.AccessRequester, tokenType oauth2.RFC8693TokenType, token string, role tokenRole) (map[string]any, error) {
	jwtType, ok := tokenType.(*JWTType)
	if !ok || jwtType == nil {
		return nil, errorsx.WithStack(oauth2.ErrServerError.WithDebugf("Token type '%s' is supposed to be of type JWT but is not castable to 'JWTType'", tokenType.GetName(ctx)))
	}

	ftoken, err := jwt.ParseWithClaims(token, jwt.MapClaims{}, jwtType.ValidateFunc)
	if err != nil {
		return nil, errorsx.WithStack(oauth2.ErrInvalidRequest.WithHint("Unable to parse the JSON web token").WithWrap(err).WithDebugError(err))
	}

	window := jwtType.JWTLifetimeToleranceWindow
	if window == 0 {
		window = 1 * time.Hour
	}

	claims := ftoken.Claims.ToMapClaims()

	if issued, exists := claims[consts.ClaimIssuedAt]; exists {
		if time.Unix(toInt64(issued), 0).Add(window).Before(time.Now()) {
			return nil, errorsx.WithStack(oauth2.ErrInvalidRequest.WithHint("Claim 'iat' from token is too far in the past."))
		}
	}

	if _, exists := claims[consts.ClaimExpirationTime]; !exists {
		return nil, errorsx.WithStack(oauth2.ErrInvalidRequest.WithHint("Claim 'exp' from token is missing."))
	}

	expiry := toInt64(claims[consts.ClaimExpirationTime])
	if time.Now().Add(window).Before(time.Unix(expiry, 0)) {
		return nil, errorsx.WithStack(oauth2.ErrInvalidRequest.WithHint("Claim 'exp' from token is too far in the future."))
	}

	iss, _ := claims[consts.ClaimIssuer].(string)
	allowed := clientAllowedIssuers(request.GetClient(), role)

	if _, ok = ValidateIssuer(iss, jwtType.Issuer, allowed); !ok {
		if len(allowed) > 0 {
			return nil, errorsx.WithStack(oauth2.ErrInvalidRequest.WithHint("Claim 'iss' from token is not in the OAuth 2.0 Client's permitted issuer list."))
		}

		return nil, errorsx.WithStack(oauth2.ErrInvalidRequest.WithHintf("Claim 'iss' from token must match the '%s'.", jwtType.Issuer))
	}

	// Validate the JTI is unique if required.
	if jwtType.ValidateJTI {
		jti, _ := claims[consts.ClaimJWTID].(string)

		if jti == "" {
			return nil, errorsx.WithStack(oauth2.ErrInvalidRequest.WithHint("Claim 'jti' from token is missing."))
		}

		if c.SetTokenExchangeCustomJWT(ctx, jti, time.Unix(expiry, 0)) != nil {
			return nil, errorsx.WithStack(oauth2.ErrInvalidRequest.WithHint("Claim 'jti' from the token must be used only once."))
		}
	}

	return claims, nil
}

func (c *CustomJWTTypeHandler) issue(ctx context.Context, request oauth2.AccessRequester, tokenType oauth2.RFC8693TokenType, response oauth2.AccessResponder) (err error) {
	jwtType, _ := tokenType.(*JWTType)
	if jwtType == nil {
		return errorsx.WithStack(
			oauth2.ErrServerError.WithDebugf("Token type '%s' is supposed to be of type JWT but is not castable to 'JWTType'", tokenType.GetName(ctx)))
	}

	session, ok := request.GetSession().(openid.Session)
	if !ok {
		return errorsx.WithStack(oauth2.ErrServerError.WithDebug("Failed to generate JWT because session must be of type 'openid.Session'."))
	}

	claims := session.IDTokenClaims()

	if claims.Subject == "" {
		return errorsx.WithStack(oauth2.ErrServerError.
			WithDebug("Failed to generate the JSON Web Token because the session subject is empty. The token exchange handler chain must populate the subject from the subject_token before the custom JWT handler runs."))
	}

	if claims.ExpirationTime == nil || claims.ExpirationTime.IsZero() {
		claims.ExpirationTime = jwt.NewNumericDate(time.Now().Add(jwtType.Expiry))
	}

	if claims.Issuer == "" {
		claims.Issuer = jwtType.Issuer
	}

	// The issued JWT's audience MUST reflect THIS exchange's audience/resource parameters per RFC 8693 §2.1, not
	// any audience that happened to be on the session from a prior OIDC flow. Replace rather than append.
	switch {
	case len(request.GetGrantedAudience()) > 0 || len(request.GetGrantedResource()) > 0:
		claims.Audience = oauth2.JoinGrantedAudienceAndResource(request.GetGrantedAudience(), request.GetGrantedResource())
	case len(jwtType.Audience) > 0:
		claims.Audience = append([]string(nil), jwtType.Audience...)
	default:
		return errorsx.WithStack(oauth2.ErrInvalidTarget.
			WithHint("Unable to determine the audience for the issued JSON Web Token.").
			WithDebugf("The token exchange request did not include an 'audience' or 'resource' parameter and the JSON Web Token type '%s' has no default audience configured.", jwtType.GetName(ctx)))
	}

	if claims.JTI == "" {
		claims.JTI = uuid.New().String()
	}

	claims.IssuedAt = jwt.Now()

	// OpenID Connect Key Binding 1.0 Section 4 pairs the 'cnf' claim with a 'typ' of 'dpop+id_token', and Section 9.3
	// has the Relying Party read that pair as the marker of a key-bound ID Token. The exchanged token is not an ID
	// Token and no proof of possession is confirmed for it, so neither may be carried over from the ID Token state
	// oauth2.ApplyIDTokenConfirmation leaves on the session.
	mapped := claims.ToMapClaims()

	delete(mapped, consts.ClaimConfirmation)

	headers := stripIDTokenConfirmationHeader(session.IDTokenHeaders())

	var token string

	if token, _, err = c.Encode(ctx, mapped, jwt.WithHeaders(headers), jwt.WithIDTokenClient(request.GetClient())); err != nil {
		return err
	}

	response.SetAccessToken(token)
	response.SetTokenType(oauth2.RFC8693NAToken)
	response.SetExpiresIn(time.Duration(claims.GetExpirationTimeSafe().UnixNano() - time.Now().UTC().UnixNano()))
	response.SetScopes(request.GetGrantedScopes())
	response.SetExtra(consts.FormParameterIssuedTokenType, jwtType.GetName(ctx))

	return nil
}

func stripIDTokenConfirmationHeader(headers *jwt.Headers) (stripped *jwt.Headers) {
	if headers == nil {
		return nil
	}

	if typ, ok := headers.Get(consts.JSONWebTokenHeaderType).(string); !ok || typ != consts.JSONWebTokenTypeDPoPIDToken {
		return headers
	}

	stripped = &jwt.Headers{Extra: make(map[string]any, len(headers.Extra))}

	for key, value := range headers.Extra {
		if key == consts.JSONWebTokenHeaderType {
			continue
		}

		stripped.Extra[key] = value
	}

	return stripped
}

func toInt64(claim any) int64 {
	switch t := claim.(type) {
	case float64:
		return int64(t)
	case int64:
		return t
	case json.Number:
		v, err := t.Int64()
		if err == nil {
			return v
		}
		vf, err := t.Float64()
		if err != nil {
			return 0
		}
		return int64(vf)
	}
	return 0
}
