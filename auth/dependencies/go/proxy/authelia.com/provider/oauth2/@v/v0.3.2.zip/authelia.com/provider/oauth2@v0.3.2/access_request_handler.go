// SPDX-FileCopyrightText: 2026 Authelia
//
// SPDX-License-Identifier: Apache-2.0

package oauth2

import (
	"context"
	"net/http"
	"strings"

	"github.com/pkg/errors"

	"authelia.com/provider/oauth2/i18n"
	"authelia.com/provider/oauth2/internal/consts"
	"authelia.com/provider/oauth2/x/errorsx"
)

// NewAccessRequest Implements
//   - https://datatracker.ietf.org/doc/html/rfc6749#section-2.3.1
//     Clients in possession of a client password MAY use the HTTP Basic
//     authentication scheme as defined in [RFC2617] to authenticate with
//     the authorization server.  The client identifier is encoded using the
//     "application/x-www-form-urlencoded" encoding algorithm per
//     Appendix B, and the encoded value is used as the username; the client
//     password is encoded using the same algorithm and used as the
//     password.  The authorization server MUST support the HTTP Basic
//     authentication scheme for authenticating clients that were issued a
//     client password.
//     Including the client credentials in the request-body using the two
//     parameters is NOT RECOMMENDED and SHOULD be limited to clients unable
//     to directly utilize the HTTP Basic authentication scheme (or other
//     password-based HTTP authentication schemes).  The parameters can only
//     be transmitted in the request-body and MUST NOT be included in the
//     request URI.
//   - https://datatracker.ietf.org/doc/html/rfc6749#section-3.2.1
//   - Confidential clients or other clients issued client credentials MUST
//     authenticate with the authorization server as described in
//     Section 2.3 when making requests to the token endpoint.
//   - If the client type is confidential or the client was issued client
//     credentials (or assigned other authentication requirements), the
//     client MUST authenticate with the authorization server as described
//     in Section 3.2.1.
//
// TODO: Refactor time permitting.
//
//nolint:gocyclo
func (f *Fosite) NewAccessRequest(ctx context.Context, r *http.Request, session Session) (ar AccessRequester, err error) {
	requester := NewAccessRequest(session)
	requester.Lang = i18n.GetLangFromRequest(f.Config.GetMessageCatalog(ctx), r)

	ctx = context.WithValue(ctx, RequestContextKey, r)
	ctx = context.WithValue(ctx, AccessRequestContextKey, requester)

	if r.Method != http.MethodPost {
		return requester, errorsx.WithStack(ErrInvalidRequest.WithHintf("HTTP method is '%s', expected 'POST'.", r.Method))
	} else if err = r.ParseMultipartForm(1 << 20); err != nil && !errors.Is(err, http.ErrNotMultipart) {
		return requester, errorsx.WithStack(ErrInvalidRequest.WithHint("Unable to parse HTTP body, make sure to send a properly formatted form request body.").WithWrap(err).WithDebugError(err))
	} else if len(r.PostForm) == 0 {
		return requester, errorsx.WithStack(ErrInvalidRequest.WithHint("The POST body can not be empty."))
	}

	requester.Form = r.PostForm

	if session == nil {
		return requester, errors.New("Session must not be nil")
	}

	if err = ValidateResourceIndicators(requester.Form); err != nil {
		return requester, err
	}

	requester.SetRequestedScopes(RemoveEmpty(strings.Split(r.PostForm.Get(consts.FormParameterScope), " ")))
	requester.SetRequestedAudience(GetRequestedAudiences(r.PostForm))
	requester.SetRequestedResource(GetRequestedResources(r.PostForm))

	requester.GrantTypes = RemoveEmpty(strings.Split(r.PostForm.Get(consts.FormParameterGrantType), " "))

	if len(requester.GrantTypes) < 1 {
		return requester, errorsx.WithStack(ErrInvalidRequest.WithHint("Request parameter 'grant_type' is missing"))
	}

	client, _, clientErr := f.AuthenticateClientWithAuthHandler(ctx, r, r.PostForm, f.Config.GetTokenEndpointClientAuthStrategy(ctx))
	if clientErr == nil {
		requester.Client = client
	}

	var found = false
	for _, loader := range f.Config.GetTokenEndpointHandlers(ctx) {
		if !loader.CanHandleTokenEndpointRequest(ctx, requester) {
			continue
		}

		if !loader.CanSkipClientAuth(ctx, requester) && clientErr != nil {
			return requester, clientErr
		}

		if err = loader.HandleTokenEndpointRequest(ctx, requester); err == nil {
			found = true
		} else if errors.Is(err, ErrUnknownRequest) {
			// This is a duplicate because it should already have been handled by
			// `loader.CanHandleTokenEndpointRequest` but let's keep it for sanity.

			continue
		} else if err != nil {
			return requester, err
		}
	}

	if !found {
		return nil, errorsx.WithStack(ErrInvalidRequest.WithDebugf("The client with id '%s' requested grant type '%s' which is invalid, unknown, not supported, or not configured to be handled.", requester.GetRequestForm().Get(consts.FormParameterClientID), strings.Join(requester.GetGrantTypes(), " ")))
	}

	// Created here rather than by a handler because context values do not propagate between the handlers in this
	// loop: the container must exist before the first handler runs for a later one to observe what an earlier one
	// published.
	ctx = context.WithValue(ctx, DPoPProofContextKey, &DPoPProofHolder{})

	// Binding handlers run only once a grant handler has accepted the request, so a binding handler needs neither a
	// grant type claim nor a client authentication policy of its own: by this point the accepting grant handler has
	// enforced whatever authentication it requires, or legitimately waived it.
	for _, binding := range f.Config.GetTokenEndpointBindingHandlers(ctx) {
		if err = binding.BindAccessRequest(ctx, requester); err != nil {
			return requester, err
		}
	}

	return requester, nil
}
