// SPDX-FileCopyrightText: 2026 Authelia
//
// SPDX-License-Identifier: Apache-2.0

package openid

import (
	"context"
	"maps"
	"slices"
	"time"

	"github.com/pkg/errors"

	"authelia.com/provider/oauth2"
	"authelia.com/provider/oauth2/internal/consts"
	"authelia.com/provider/oauth2/internal/stringslice"
	"authelia.com/provider/oauth2/token/jwt"
	"authelia.com/provider/oauth2/x/errorsx"
)

const (
	defaultExpiryTime                  = time.Hour
	defaultBackChannelLogoutExpiryTime = 5 * time.Minute
)

// The Session represents the structure that a valid OpenID Connect 1.0 session has.
type Session interface {
	// IDTokenClaims returns a pointer to claims which will be modified in-place by handlers.
	// Session should store this pointer and return always the same pointer.
	IDTokenClaims() *jwt.IDTokenClaims

	// IDTokenHeaders returns a pointer to header values which will be modified in-place by handlers.
	// Session should store this pointer and return always the same pointer.
	IDTokenHeaders() *jwt.Headers

	// SetRequestedAt sets when this request was originally requested.
	SetRequestedAt(rat time.Time)

	// GetRequestedAt returns when this request was originally requested.
	GetRequestedAt() (rat time.Time)

	oauth2.Session
}

// DefaultSession is a session container for the id token.
type DefaultSession struct {
	Claims                      *jwt.IDTokenClaims             `json:"id_token_claims,omitempty"`
	Headers                     *jwt.Headers                   `json:"headers,omitempty"`
	ExpiresAt                   map[oauth2.TokenType]time.Time `json:"expires_at,omitempty"`
	Username                    string                         `json:"username,omitempty"`
	Subject                     string                         `json:"subject,omitempty"`
	JWKThumbprint               string                         `json:"jwk_thumbprint,omitempty"`
	ClientCertificateThumbprint string                         `json:"client_certificate_thumbprint,omitempty"`
	PublicKeyJWK                []byte                         `json:"public_key_jwk,omitempty"`
	RequestedJWKThumbprint      string                         `json:"requested_jwk_thumbprint,omitempty"`
	KeyBindingGranted           bool                           `json:"key_binding_granted,omitempty"`
	RequestedAt                 time.Time                      `json:"requested_at"`
}

func NewDefaultSession() *DefaultSession {
	return &DefaultSession{
		Claims:      &jwt.IDTokenClaims{},
		Headers:     &jwt.Headers{},
		RequestedAt: time.Now().UTC(),
	}
}

func (s *DefaultSession) Clone() oauth2.Session {
	if s == nil {
		return nil
	}

	cloned := *s

	cloned.Claims = s.Claims.Clone()
	cloned.Headers = s.Headers.Clone()
	cloned.ExpiresAt = maps.Clone(s.ExpiresAt)
	cloned.PublicKeyJWK = slices.Clone(s.PublicKeyJWK)

	return &cloned
}

func (s *DefaultSession) SetExpiresAt(key oauth2.TokenType, exp time.Time) {
	if s.ExpiresAt == nil {
		s.ExpiresAt = make(map[oauth2.TokenType]time.Time)
	}

	s.ExpiresAt[key] = exp.UTC()
}

func (s *DefaultSession) GetExpiresAt(key oauth2.TokenType) time.Time {
	if s.ExpiresAt == nil {
		s.ExpiresAt = make(map[oauth2.TokenType]time.Time)
	}

	if _, ok := s.ExpiresAt[key]; !ok {
		return time.Time{}
	}
	return s.ExpiresAt[key]
}

func (s *DefaultSession) SetRequestedAt(rat time.Time) {
	s.RequestedAt = rat.UTC()
}

func (s *DefaultSession) GetRequestedAt() (rat time.Time) {
	return s.RequestedAt.UTC()
}

func (s *DefaultSession) GetUsername() string {
	if s == nil {
		return ""
	}
	return s.Username
}

func (s *DefaultSession) SetSubject(subject string) {
	s.Subject = subject
}

func (s *DefaultSession) GetSubject() string {
	if s == nil {
		return ""
	}

	return s.Subject
}

func (s *DefaultSession) SetDPoPJWKThumbprint(jkt string) {
	s.JWKThumbprint = jkt
}

func (s *DefaultSession) GetDPoPJWKThumbprint() string {
	if s == nil {
		return ""
	}

	return s.JWKThumbprint
}

// SetClientCertificateSHA256Thumbprint implements oauth2.MTLSBoundSession for DefaultSession.
func (s *DefaultSession) SetClientCertificateSHA256Thumbprint(x5t string) {
	s.ClientCertificateThumbprint = x5t
}

// GetClientCertificateSHA256Thumbprint implements oauth2.MTLSBoundSession for DefaultSession.
func (s *DefaultSession) GetClientCertificateSHA256Thumbprint() string {
	if s == nil {
		return ""
	}

	return s.ClientCertificateThumbprint
}

// SetDPoPPublicKeyJWK implements oauth2.DPoPBoundSession for DefaultSession.
func (s *DefaultSession) SetDPoPPublicKeyJWK(jwk []byte) {
	s.PublicKeyJWK = jwk
}

// GetDPoPPublicKeyJWK implements oauth2.DPoPBoundSession for DefaultSession.
func (s *DefaultSession) GetDPoPPublicKeyJWK() (jwk []byte) {
	if s == nil {
		return nil
	}

	return s.PublicKeyJWK
}

// SetRequestedDPoPJWKThumbprint implements oauth2.DPoPBoundSession for DefaultSession.
func (s *DefaultSession) SetRequestedDPoPJWKThumbprint(jkt string) {
	s.RequestedJWKThumbprint = jkt
}

// GetRequestedDPoPJWKThumbprint implements oauth2.DPoPBoundSession for DefaultSession.
func (s *DefaultSession) GetRequestedDPoPJWKThumbprint() (jkt string) {
	if s == nil {
		return ""
	}

	return s.RequestedJWKThumbprint
}

func (s *DefaultSession) IDTokenHeaders() *jwt.Headers {
	if s.Headers == nil {
		s.Headers = &jwt.Headers{}
	}
	return s.Headers
}

func (s *DefaultSession) IDTokenClaims() *jwt.IDTokenClaims {
	if s.Claims == nil {
		s.Claims = &jwt.IDTokenClaims{}
	}
	return s.Claims
}

type DefaultStrategy struct {
	jwt.Strategy

	Config interface {
		oauth2.IDTokenIssuerProvider
		oauth2.IDTokenLifespanProvider
		oauth2.MinParameterEntropyProvider
		oauth2.IDTokenConfirmationConfigProvider
	}
}

// GenerateIDToken returns a JWT string.
//
// lifespan is ignored if requester.GetSession().IDTokenClaims().ExpirationTime is not zero.
//
// TODO: Refactor time permitting.
//
//nolint:gocyclo
func (h DefaultStrategy) GenerateIDToken(ctx context.Context, lifespan time.Duration, request oauth2.Requester) (token string, err error) {
	if lifespan == 0 {
		lifespan = defaultExpiryTime
	}

	session, ok := request.GetSession().(Session)
	if !ok {
		return "", errorsx.WithStack(oauth2.ErrServerError.WithDebug("Failed to generate ID Token because the session is not of type 'openid.Session' which is required"))
	}

	claims := session.IDTokenClaims()
	if claims.Subject == "" {
		return "", errorsx.WithStack(oauth2.ErrServerError.WithDebug("Failed to generate ID Token because subject is an empty string."))
	}

	jwtClient := jwt.NewIDTokenClient(request.GetClient())

	if request.GetRequestForm().Get(consts.FormParameterGrantType) != consts.GrantTypeRefreshToken {
		var (
			maxAge    int64
			hasMaxAge bool
		)

		if maxAge, hasMaxAge, err = requestedMaxAge(request.GetRequestForm()); err != nil {
			return "", errorsx.WithStack(oauth2.ErrInvalidRequest.WithHint("Parameter 'max_age' must be a non-negative integer.").WithWrap(err).WithDebugError(err))
		}

		// Adds a bit of wiggle room for timing issues
		if claims.GetAuthTimeSafe().After(time.Now().UTC().Add(time.Second * 5)) {
			return "", errorsx.WithStack(oauth2.ErrServerError.WithDebug("Failed to validate OpenID Connect request because authentication time is in the future."))
		}

		rat := session.GetRequestedAt()

		if hasMaxAge {
			switch {
			case claims.AuthTime == nil, claims.AuthTime.IsZero():
				return "", errorsx.WithStack(oauth2.ErrServerError.WithDebug("Failed to generate ID Token because authentication time claim is required when max_age is set."))
			case rat.IsZero():
				return "", errorsx.WithStack(oauth2.ErrServerError.WithDebug("Failed to generate ID Token because requested at value is required when max_age is set."))
			case claims.AuthTime.Add(time.Second * time.Duration(maxAge)).Before(rat):
				return "", errorsx.WithStack(oauth2.ErrServerError.WithDebug("Failed to generate ID Token because authentication time does not satisfy max_age time."))
			}
		}

		prompt := request.GetRequestForm().Get(consts.FormParameterPrompt)
		if prompt != "" {
			if claims.AuthTime == nil || claims.AuthTime.IsZero() {
				return "", errorsx.WithStack(oauth2.ErrServerError.WithDebug("Unable to determine validity of prompt parameter because auth_time is missing in ID Token claims."))
			}
		}

		switch prompt {
		case consts.PromptTypeNone:
			if !claims.GetAuthTimeSafe().Equal(rat) && claims.GetAuthTimeSafe().After(rat) {
				return "", errorsx.WithStack(oauth2.ErrServerError.
					WithDebugf("Failed to generate ID Token because prompt was set to 'none' but auth_time ('%s') happened after the authorization request ('%s') was registered, indicating that the user was logged in during this request which is not allowed.", claims.GetAuthTimeSafe(), rat))
			}
		case consts.PromptTypeLogin:
			if !claims.GetAuthTimeSafe().Equal(rat) && claims.GetAuthTimeSafe().Before(rat) {
				return "", errorsx.WithStack(oauth2.ErrServerError.
					WithDebugf("Failed to generate ID Token because prompt was set to 'login' but auth_time ('%s') happened before the authorization request ('%s') was registered, indicating that the user was not re-authenticated which is forbidden.", claims.GetAuthTimeSafe(), rat))
			}
		}

		// If acr_values was requested but no acr value was provided in the ID token, fall back to level 0 which means least
		// confidence in authentication.
		if request.GetRequestForm().Get(consts.FormParameterAuthenticationContextClassReferenceValues) != "" && claims.AuthenticationContextClassReference == "" {
			claims.AuthenticationContextClassReference = "0"
		}

		if tokenHintString := request.GetRequestForm().Get(consts.FormParameterIDTokenHint); tokenHintString != "" {
			var tokenHint *jwt.Token

			tokenHint, err = h.Decode(ctx, tokenHintString, jwt.WithClient(jwtClient))

			var ve *jwt.ValidationError
			if errors.As(err, &ve) && ve.Is(jwt.ValidationErrorExpired) {
				// Expired ID Tokens are allowed as values to id_token_hint
			} else if err != nil {
				return "", errorsx.WithStack(oauth2.ErrServerError.WithWrap(err).WithDebugf("Unable to decode ID Token from 'id_token_hint' parameter because %s.", err.Error()))
			}

			var subHint string

			if subHint, err = tokenHint.Claims.GetSubject(); subHint == "" || err != nil {
				return "", errorsx.WithStack(oauth2.ErrServerError.WithDebug("Provided ID Token from 'id_token_hint' does not have a subject."))
			} else if subHint != claims.Subject {
				return "", errorsx.WithStack(oauth2.ErrServerError.WithDebug("Subject from authorization mismatches ID Token subject from 'id_token_hint'."))
			}
		}
	}

	if claims.ExpirationTime == nil || claims.ExpirationTime.IsZero() {
		claims.ExpirationTime = jwt.NewNumericDate(time.Now().Add(lifespan))
	}

	if claims.ExpirationTime.Before(time.Now().UTC()) {
		return "", errorsx.WithStack(oauth2.ErrServerError.WithDebug("Failed to generate ID Token because expiry claim can not be in the past."))
	}

	if claims.AuthTime == nil || claims.AuthTime.IsZero() {
		claims.AuthTime = jwt.Now()
	}

	if claims.Issuer == "" {
		claims.Issuer = h.Config.GetIDTokenIssuer(ctx)
	}

	// OPTIONAL. String value used to associate a Client session with an ID Token, and to mitigate replay attacks.
	if nonce := request.GetRequestForm().Get(consts.FormParameterNonce); len(nonce) == 0 {
	} else if len(nonce) > 0 && len(nonce) < h.Config.GetMinParameterEntropy(ctx) {
		// We're assuming that using less then, by default, 8 characters for the state can not be considered "unguessable"
		return "", errorsx.WithStack(oauth2.ErrInsufficientEntropy.WithHintf("Parameter 'nonce' is set but does not satisfy the minimum entropy of %d characters.", h.Config.GetMinParameterEntropy(ctx)))
	} else if len(nonce) > 0 {
		claims.Nonce = nonce
	}

	claims.Audience = stringslice.Unique(append(claims.Audience, request.GetClient().GetID()))
	claims.IssuedAt = jwt.Now()

	// OpenID Connect Key Binding 1.0 Section 4. Applied last so the confirmation reflects the final claim set, and
	// before the headers are read by Encode.
	if err = oauth2.ApplyIDTokenConfirmation(ctx, h.Config, claims, session.IDTokenHeaders()); err != nil {
		return "", err
	}

	token, _, err = h.Encode(ctx, claims.ToMapClaims(), jwt.WithHeaders(session.IDTokenHeaders()), jwt.WithClient(jwtClient))

	return token, err
}

func (h DefaultStrategy) GenerateBackChannelLogoutToken(ctx context.Context, client oauth2.Client, lifespan time.Duration, subject, sid string, audience []string, extra map[string]any) (token string, err error) {
	if lifespan == 0 {
		lifespan = defaultBackChannelLogoutExpiryTime
	}

	claims := jwt.NewLogoutTokenClaims(subject, audience, sid, extra)

	// REQUIRED. The 'iss' claim. LogoutTokenClaims.ToMap deletes 'iss' when empty and the JWT strategy injects
	// no claims of its own, so the issuer must be set here as it is for ID Tokens.
	if len(claims.Issuer) == 0 {
		claims.Issuer = h.Config.GetIDTokenIssuer(ctx)
	}

	if claims.ExpirationTime == nil || claims.ExpirationTime.IsZero() {
		claims.ExpirationTime = jwt.NewNumericDate(time.Now().UTC().Add(lifespan))
	}

	if claims.ExpirationTime.Before(time.Now().UTC()) {
		return "", errorsx.WithStack(oauth2.ErrServerError.WithDebug("Failed to generate Logout Token because expiry claim can not be in the past."))
	}

	token, _, err = h.Encode(
		ctx,
		claims.ToMapClaims(),
		jwt.WithHeaders(&jwt.Headers{Extra: map[string]any{jwt.JSONWebTokenHeaderType: jwt.JSONWebTokenTypeLogoutToken}}),
		jwt.WithClient(jwt.NewIDTokenClient(client)),
	)

	return token, err
}

// SetOIDCKeyBindingGranted implements DPoPBoundSession for DefaultSession.
func (s *DefaultSession) SetOIDCKeyBindingGranted(granted bool) {
	s.KeyBindingGranted = granted
}

// GetOIDCKeyBindingGranted implements DPoPBoundSession for DefaultSession.
func (s *DefaultSession) GetOIDCKeyBindingGranted() (granted bool) {
	if s == nil {
		return false
	}

	return s.KeyBindingGranted
}

var (
	_ oauth2.DPoPBoundSession = (*DefaultSession)(nil)
	_ oauth2.MTLSBoundSession = (*DefaultSession)(nil)
)
