// SPDX-FileCopyrightText: 2026 Authelia
//
// SPDX-License-Identifier: Apache-2.0

package rfc7523

import (
	"context"
	"crypto/subtle"
	"strings"
	"time"

	"authelia.com/provider/oauth2"
	hoauth2 "authelia.com/provider/oauth2/handler/oauth2"
	"authelia.com/provider/oauth2/internal/consts"
	"authelia.com/provider/oauth2/token/jose"
	"authelia.com/provider/oauth2/token/jose/jwt"
	"authelia.com/provider/oauth2/x/errorsx"
)

type Handler struct {
	Storage Storage

	Config interface {
		oauth2.AccessTokenLifespanProvider
		oauth2.AllowedJWTAssertionAudiencesProvider
		oauth2.GrantTypeJWTBearerCanSkipClientAuthProvider
		oauth2.GrantTypeJWTBearerIDOptionalProvider
		oauth2.GrantTypeJWTBearerIssuedDateOptionalProvider
		oauth2.GetJWTMaxDurationProvider
		oauth2.AudienceStrategyProvider
		oauth2.ScopeStrategyProvider
	}

	*hoauth2.HandleHelper
}

// HandleTokenEndpointRequest implements https://datatracker.ietf.org/doc/html/rfc6749#section-4.1.3 (everything) and
// https://datatracker.ietf.org/doc/html/rfc7523#section-2.1 (everything)
//
// TODO: Refactor time permitting.
//
//nolint:gocyclo
func (c *Handler) HandleTokenEndpointRequest(ctx context.Context, request oauth2.AccessRequester) (err error) {
	if err = c.CheckRequest(ctx, request); err != nil {
		return err
	}

	assertion := request.GetRequestForm().Get(consts.FormParameterAssertion)
	if assertion == "" {
		return errorsx.WithStack(oauth2.ErrInvalidRequest.WithHintf("The assertion request parameter must be set when using grant_type of '%s'.", consts.GrantTypeOAuthJWTBearer))
	}

	token, err := jwt.ParseSigned(assertion, []jose.SignatureAlgorithm{jose.HS256, jose.HS384, jose.HS512, jose.RS256, jose.RS384, jose.RS512, jose.PS256, jose.PS384, jose.PS512, jose.ES256, jose.ES384, jose.ES512})
	if err != nil {
		return errorsx.WithStack(oauth2.ErrInvalidGrant.WithHint("Unable to parse JSON Web Token passed in 'assertion' request parameter.").WithWrap(err).WithDebugError(err))
	}

	// Reject anything whose JOSE 'typ' header explicitly declares it is not a JWT (RFC 7519
	// §5.1; RFC 8725 §3.11). Defends against cross-profile substitution where a token minted
	// for a different purpose (e.g. 'secevent+jwt', 'dpop+jwt') is replayed as an assertion.
	if err = c.validateTokenType(token); err != nil {
		return err
	}

	// Check fo required claims in token, so we can later find public key based on them.
	if err = c.validateTokenPreRequisites(token); err != nil {
		return err
	}

	key, err := c.findPublicKeyForToken(ctx, token)
	if err != nil {
		return err
	}

	claims := jwt.Claims{}

	if err = token.Claims(key, &claims); err != nil {
		return errorsx.WithStack(oauth2.ErrInvalidGrant.WithHint("Unable to verify the integrity of the 'assertion' value.").WithWrap(err).WithDebugError(err))
	}

	if err = c.validateTokenClaims(ctx, claims, key); err != nil {
		return err
	}

	scopes, err := c.Storage.GetRFC7523PublicKeyScopes(ctx, claims.Issuer, claims.Subject, key.KeyID)
	if err != nil {
		return errorsx.WithStack(oauth2.ErrServerError.WithWrap(err).WithDebugError(err))
	}

	for _, scope := range request.GetRequestedScopes() {
		if !c.Config.GetScopeStrategy(ctx)(scopes, scope) {
			return errorsx.WithStack(oauth2.ErrInvalidScope.WithHintf("The public key registered for issuer '%s' and subject '%s' is not allowed to request scope '%s'.", claims.Issuer, claims.Subject, scope))
		}
	}

	if claims.ID != "" {
		if err = c.Storage.MarkRFC7523JWTUsedForTime(ctx, claims.Issuer, claims.ID, claims.Expiry.Time()); err != nil {
			return errorsx.WithStack(oauth2.ErrServerError.WithWrap(err).WithDebugError(err))
		}
	}

	for _, scope := range request.GetRequestedScopes() {
		request.GrantScope(scope)
	}

	for _, audience := range claims.Audience {
		request.GrantAudience(audience)
	}

	session, err := c.getSessionFromRequest(request)
	if err != nil {
		return err
	}

	atLifespan := oauth2.GetEffectiveLifespan(request.GetClient(), oauth2.GrantTypeJWTBearer, oauth2.AccessToken, c.HandleHelper.Config.GetAccessTokenLifespan(ctx))

	session.SetExpiresAt(oauth2.AccessToken, time.Now().UTC().Add(atLifespan).Round(time.Second))
	session.SetSubject(claims.Subject)

	return nil
}

func (c *Handler) PopulateTokenEndpointResponse(ctx context.Context, request oauth2.AccessRequester, response oauth2.AccessResponder) (err error) {
	if err = c.CheckRequest(ctx, request); err != nil {
		return err
	}

	atLifespan := oauth2.GetEffectiveLifespan(request.GetClient(), oauth2.GrantTypeJWTBearer, oauth2.AccessToken, c.Config.GetAccessTokenLifespan(ctx))

	_, err = c.IssueAccessToken(ctx, atLifespan, request, response)

	return err
}

func (c *Handler) CanSkipClientAuth(ctx context.Context, request oauth2.AccessRequester) bool {
	return c.Config.GetGrantTypeJWTBearerCanSkipClientAuth(ctx)
}

func (c *Handler) CanHandleTokenEndpointRequest(ctx context.Context, request oauth2.AccessRequester) bool {
	// The 'grant_type' parameter is REQUIRED. Value MUST be set to "urn:ietf:params:oauth:grant-type:jwt-bearer".
	return request.GetGrantTypes().ExactOne(consts.GrantTypeOAuthJWTBearer)
}

func (c *Handler) CheckRequest(ctx context.Context, request oauth2.AccessRequester) error {
	if !c.CanHandleTokenEndpointRequest(ctx, request) {
		return errorsx.WithStack(oauth2.ErrUnknownRequest)
	}

	// Client Authentication is optional:
	//
	// Authentication of the client is optional, as described in
	//   Section 3.2.1 of OAuth 2.0 [RFC6749] and consequently, the
	//   "client_id" is only needed when a form of client authentication that
	//   relies on the parameter is used.

	// if client is authenticated, check grant types
	if !c.CanSkipClientAuth(ctx, request) && !request.GetClient().GetGrantTypes().Has(consts.GrantTypeOAuthJWTBearer) {
		return errorsx.WithStack(oauth2.ErrUnauthorizedClient.WithHintf("The OAuth 2.0 Client is not allowed to use authorization grant '%s'.", consts.GrantTypeOAuthJWTBearer))
	}

	return nil
}

// validateTokenType enforces the JOSE 'typ' header rule from RFC 7519 §5.1: if present, the
// value MUST identify the object as a JWT. Per RFC 6838 media-type matching is
// case-insensitive, and per RFC 8725 §3.11 'application/jwt' is treated equivalently. An
// absent 'typ' header is allowed (it's RECOMMENDED but not required by RFC 7519).
func (c *Handler) validateTokenType(token *jwt.JSONWebToken) error {
	for _, header := range token.Headers {
		raw, ok := header.ExtraHeaders[jose.HeaderType]
		if !ok {
			continue
		}

		typ, _ := raw.(string)
		if typ == "" {
			continue
		}

		if !strings.EqualFold(typ, consts.JSONWebTokenTypeJWT) && !strings.EqualFold(typ, "application/jwt") {
			return errorsx.WithStack(oauth2.ErrInvalidGrant.WithHintf("The JWT in 'assertion' request parameter has an invalid 'typ' header value '%s'; expected 'JWT'.", typ))
		}
	}

	return nil
}

func (c *Handler) validateTokenPreRequisites(token *jwt.JSONWebToken) error {
	unverifiedClaims := jwt.Claims{}

	if err := token.UnsafeClaimsWithoutVerification(&unverifiedClaims); err != nil {
		return errorsx.WithStack(oauth2.ErrInvalidGrant.WithHint("Looks like there are no claims in JWT in 'assertion' request parameter.").WithWrap(err).WithDebugError(err))
	}

	if unverifiedClaims.Issuer == "" {
		return errorsx.WithStack(oauth2.ErrInvalidGrant.WithHint("The JWT in 'assertion' request parameter MUST contain an 'iss' (issuer) claim."))
	}

	if unverifiedClaims.Subject == "" {
		return errorsx.WithStack(oauth2.ErrInvalidGrant.WithHint("The JWT in 'assertion' request parameter MUST contain a 'sub' (subject) claim."))
	}

	return nil
}

func (c *Handler) findPublicKeyForToken(ctx context.Context, token *jwt.JSONWebToken) (*jose.JSONWebKey, error) {
	unverifiedClaims := jwt.Claims{}
	if err := token.UnsafeClaimsWithoutVerification(&unverifiedClaims); err != nil {
		return nil, errorsx.WithStack(oauth2.ErrInvalidRequest.WithWrap(err).WithDebugError(err))
	}

	var keyID string
	for _, header := range token.Headers {
		if header.KeyID != "" {
			keyID = header.KeyID
			break
		}
	}

	keyNotFoundErr := oauth2.ErrInvalidGrant.WithHintf("No public JWK was registered for issuer '%s' and subject '%s', and public key is required to check signature of JWT in 'assertion' request parameter.", unverifiedClaims.Issuer, unverifiedClaims.Subject)

	if keyID != "" {
		key, err := c.Storage.GetRFC7523PublicKey(ctx, unverifiedClaims.Issuer, unverifiedClaims.Subject, keyID)
		if err != nil {
			return nil, errorsx.WithStack(keyNotFoundErr.WithWrap(err).WithDebugError(err))
		}
		return key, nil
	}

	keys, err := c.Storage.GetRFC7523PublicKeys(ctx, unverifiedClaims.Issuer, unverifiedClaims.Subject)
	if err != nil {
		return nil, errorsx.WithStack(keyNotFoundErr.WithWrap(err).WithDebugError(err))
	}

	claims := jwt.Claims{}

	for _, key := range keys.Keys {
		if err = token.Claims(key, &claims); err == nil {
			return &key, nil
		}
	}

	return nil, errorsx.WithStack(keyNotFoundErr)
}

// TODO: Refactor time permitting.
//
//nolint:gocyclo,unparam
func (c *Handler) validateTokenClaims(ctx context.Context, claims jwt.Claims, key *jose.JSONWebKey) error {
	audiences := c.Config.GetAllowedJWTAssertionAudiences(ctx)

	if len(audiences) == 0 {
		return errorsx.WithStack(oauth2.ErrServerError.WithHint("The JWT in 'assertion' request parameter can't be validated as the authorization server isn't configured to accept JWT assertions."))
	}

	if len(claims.Audience) == 0 {
		return errorsx.WithStack(oauth2.ErrInvalidGrant.WithHint("The JWT in 'assertion' request parameter MUST contain an 'aud' (audience) claim."))
	}

	validAudience := false

verify:
	for _, unverified := range claims.Audience {
		for _, aud := range audiences {
			if subtle.ConstantTimeCompare([]byte(aud), []byte(unverified)) == 1 {
				validAudience = true
				break verify
			}
		}
	}

	if !validAudience {
		return errorsx.WithStack(oauth2.ErrInvalidGrant.WithHintf("The JWT in 'assertion' request parameter MUST contain an 'aud' (audience) claim containing a value '%s' that identifies the authorization server as an intended audience.", strings.Join(audiences, "', '")))
	}

	if claims.Expiry == nil {
		return errorsx.WithStack(oauth2.ErrInvalidGrant.WithHint("The JWT in 'assertion' request parameter MUST contain an 'exp' (expiration time) claim."))
	}

	if claims.Expiry.Time().Before(time.Now()) {
		return errorsx.WithStack(oauth2.ErrInvalidGrant.WithHint("The JWT provided in the 'assertion' request parameter is expired."))
	}

	if claims.NotBefore != nil && !claims.NotBefore.Time().Before(time.Now()) {
		return errorsx.WithStack(oauth2.ErrInvalidGrant.WithHintf("The JWT in 'assertion' request parameter contains an 'nbf' (not before) claim, that identifies the time '%s' before which the token MUST NOT be accepted.", claims.NotBefore.Time().Format(time.RFC3339)))
	}

	if claims.IssuedAt != nil {
		if !claims.IssuedAt.Time().Before(time.Now()) {
			return errorsx.WithStack(oauth2.ErrInvalidGrant.WithHintf("The JWT in 'assertion' request parameter contains an 'iat' (issued at) claim, that identifies the time '%s' which is after the current time", claims.IssuedAt.Time().Format(time.RFC3339)))
		}
	} else if !c.Config.GetGrantTypeJWTBearerIssuedDateOptional(ctx) {
		return errorsx.WithStack(oauth2.ErrInvalidGrant.WithHint("The JWT in 'assertion' request parameter MUST contain an 'iat' (issued at) claim."))
	}

	var issuedDate time.Time
	if claims.IssuedAt != nil {
		issuedDate = claims.IssuedAt.Time()
	} else {
		issuedDate = time.Now()
	}

	if claims.Expiry.Time().Sub(issuedDate) > c.Config.GetJWTMaxDuration(ctx) {
		return errorsx.WithStack(oauth2.ErrInvalidGrant.WithHintf("The JWT in 'assertion' request parameter contains an 'exp' (expiration time) claim with value '%s' that is unreasonably far in the future, considering token issued at '%s'.", claims.Expiry.Time().Format(time.RFC3339), issuedDate.Format(time.RFC3339)))
	}

	if !c.Config.GetGrantTypeJWTBearerIDOptional(ctx) && claims.ID == "" {
		return errorsx.WithStack(oauth2.ErrInvalidGrant.WithHint("The JWT in 'assertion' request parameter MUST contain an 'jti' (JWT ID) claim."))
	}

	if claims.ID != "" {
		used, err := c.Storage.IsRFC7523JWTUsed(ctx, claims.Issuer, claims.ID)
		if err != nil {
			return errorsx.WithStack(oauth2.ErrServerError.WithWrap(err).WithDebugError(err))
		}
		if used {
			return errorsx.WithStack(oauth2.ErrJTIKnown)
		}
	}

	return nil
}

type extendedSession interface {
	Session
	oauth2.Session
}

func (c *Handler) getSessionFromRequest(request oauth2.AccessRequester) (extendedSession, error) {
	session := request.GetSession()
	if jwtSession, ok := session.(extendedSession); !ok {
		return nil, errorsx.WithStack(oauth2.ErrServerError.WithHintf("Session must be of type *rfc7523.Session but got type: %T", session))
	} else {
		return jwtSession, nil
	}
}

var (
	_ oauth2.TokenEndpointHandler = (*Handler)(nil)
)
