// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package expfmt

import (
	"bytes"
	"io"
	"math"
	"strings"
	"testing"

	dto "github.com/prometheus/client_model/go"
	"google.golang.org/protobuf/proto"
	"google.golang.org/protobuf/types/known/timestamppb"
)

func TestCreateOpenMetrics20(t *testing.T) {
	scenarios := []struct {
		name string
		in   *dto.MetricFamily
		out  string
	}{
		{
			name: "Counter",
			in: &dto.MetricFamily{
				Name: proto.String("http_requests_total"),
				Help: proto.String("Total number of HTTP requests."),
				Type: dto.MetricType_COUNTER.Enum(),
				Metric: []*dto.Metric{
					{
						Label: []*dto.LabelPair{
							{Name: proto.String("method"), Value: proto.String("GET")},
							{Name: proto.String("code"), Value: proto.String("200")},
						},
						Counter: &dto.Counter{
							Value:            proto.Float64(1027),
							CreatedTimestamp: &timestamppb.Timestamp{Seconds: 1234567890},
						},
					},
				},
			},
			out: `# HELP http_requests_total Total number of HTTP requests.
# TYPE http_requests_total counter
http_requests_total{method="GET",code="200"} 1027.0 st@1234567890
`,
		},
		{
			name: "CounterWithSubsecondCreatedTimestamp",
			in: &dto.MetricFamily{
				Name: proto.String("http_requests_total"),
				Help: proto.String("Total number of HTTP requests."),
				Type: dto.MetricType_COUNTER.Enum(),
				Metric: []*dto.Metric{
					{
						Label: []*dto.LabelPair{
							{Name: proto.String("method"), Value: proto.String("GET")},
							{Name: proto.String("code"), Value: proto.String("200")},
						},
						Counter: &dto.Counter{
							Value:            proto.Float64(1027),
							CreatedTimestamp: &timestamppb.Timestamp{Seconds: 1234567890, Nanos: 987654321},
						},
					},
				},
			},
			out: `# HELP http_requests_total Total number of HTTP requests.
# TYPE http_requests_total counter
http_requests_total{method="GET",code="200"} 1027.0 st@1234567890.987654321
`,
		},
		{
			name: "Gauge",
			in: &dto.MetricFamily{
				Name: proto.String("node_memory_active_bytes"),
				Help: proto.String("Active memory in bytes."),
				Type: dto.MetricType_GAUGE.Enum(),
				Metric: []*dto.Metric{
					{
						Gauge: &dto.Gauge{
							Value: proto.Float64(1.2345e+09),
						},
					},
				},
			},
			out: `# HELP node_memory_active_bytes Active memory in bytes.
# TYPE node_memory_active_bytes gauge
node_memory_active_bytes 1.2345e+09
`,
		},
		{
			name: "GaugeWithUnit",
			in: &dto.MetricFamily{
				Name: proto.String("node_memory_active_bytes"),
				Help: proto.String("Active memory in bytes."),
				Type: dto.MetricType_GAUGE.Enum(),
				Unit: proto.String("bytes"),
				Metric: []*dto.Metric{
					{
						Gauge: &dto.Gauge{
							Value: proto.Float64(1.2345e+09),
						},
					},
				},
			},
			out: `# HELP node_memory_active_bytes Active memory in bytes.
# TYPE node_memory_active_bytes gauge
# UNIT node_memory_active_bytes bytes
node_memory_active_bytes 1.2345e+09
`,
		},
		{
			name: "GaugeWithTimestamp",
			in: &dto.MetricFamily{
				Name: proto.String("node_memory_active_bytes"),
				Type: dto.MetricType_GAUGE.Enum(),
				Metric: []*dto.Metric{
					{
						Gauge: &dto.Gauge{
							Value: proto.Float64(1.2345e+09),
						},
						TimestampMs: proto.Int64(1234567890000),
					},
				},
			},
			out: `# TYPE node_memory_active_bytes gauge
node_memory_active_bytes 1.2345e+09 1234567890
`,
		},
		{
			name: "CounterWithExemplar",
			in: &dto.MetricFamily{
				Name: proto.String("http_requests_total"),
				Type: dto.MetricType_COUNTER.Enum(),
				Metric: []*dto.Metric{
					{
						Counter: &dto.Counter{
							Value:            proto.Float64(1027),
							CreatedTimestamp: &timestamppb.Timestamp{Seconds: 1234567890},
							Exemplar: &dto.Exemplar{
								Label: []*dto.LabelPair{
									{Name: proto.String("trace_id"), Value: proto.String("1234")},
								},
								Value:     proto.Float64(1),
								Timestamp: &timestamppb.Timestamp{Seconds: 1234567890, Nanos: 500000000},
							},
						},
						TimestampMs: proto.Int64(1234567891000),
					},
				},
			},
			out: `# TYPE http_requests_total counter
http_requests_total 1027.0 1234567891 st@1234567890 # {trace_id="1234"} 1.0 1234567890.5
`,
		},
		{
			name: "CounterWithExemplarWithoutLabels",
			in: &dto.MetricFamily{
				Name: proto.String("http_requests_total"),
				Type: dto.MetricType_COUNTER.Enum(),
				Metric: []*dto.Metric{
					{
						Counter: &dto.Counter{
							Value: proto.Float64(1027),
							Exemplar: &dto.Exemplar{
								Value:     proto.Float64(1),
								Timestamp: &timestamppb.Timestamp{Seconds: 1234567890, Nanos: 500000000},
							},
						},
					},
				},
			},
			out: `# TYPE http_requests_total counter
http_requests_total 1027.0 # {} 1.0 1234567890.5
`,
		},
		{
			name: "CounterWithExemplarWithoutTimestamp",
			in: &dto.MetricFamily{
				Name: proto.String("http_requests_total"),
				Type: dto.MetricType_COUNTER.Enum(),
				Metric: []*dto.Metric{
					{
						Counter: &dto.Counter{
							Value: proto.Float64(1027),
							Exemplar: &dto.Exemplar{
								Label: []*dto.LabelPair{
									{Name: proto.String("trace_id"), Value: proto.String("1234")},
								},
								Value: proto.Float64(1),
							},
						},
					},
				},
			},
			out: `# TYPE http_requests_total counter
http_requests_total 1027.0
`,
		},
		{
			name: "CounterWithInvalidExemplarTimestamp",
			in: &dto.MetricFamily{
				Name: proto.String("http_requests_total"),
				Type: dto.MetricType_COUNTER.Enum(),
				Metric: []*dto.Metric{
					{
						Counter: &dto.Counter{
							Value: proto.Float64(1027),
							Exemplar: &dto.Exemplar{
								Label: []*dto.LabelPair{
									{Name: proto.String("trace_id"), Value: proto.String("1234")},
								},
								Value: proto.Float64(1),
								Timestamp: &timestamppb.Timestamp{
									Nanos: -1,
								},
							},
						},
					},
				},
			},
			out: `# TYPE http_requests_total counter
http_requests_total 1027.0
`,
		},
		{
			name: "CounterWithInvalidExemplarLabel",
			in: &dto.MetricFamily{
				Name: proto.String("http_requests_total"),
				Type: dto.MetricType_COUNTER.Enum(),
				Metric: []*dto.Metric{
					{
						Counter: &dto.Counter{
							Value: proto.Float64(1027),
							Exemplar: &dto.Exemplar{
								Label: []*dto.LabelPair{
									{Name: proto.String(""), Value: proto.String("1234")},
								},
								Value:     proto.Float64(1),
								Timestamp: &timestamppb.Timestamp{Seconds: 1234567890},
							},
						},
					},
				},
			},
			out: `# TYPE http_requests_total counter
http_requests_total 1027.0
`,
		},
		{
			name: "CounterWithNewlineInExemplarLabelName",
			in: &dto.MetricFamily{
				Name: proto.String("http_requests_total"),
				Type: dto.MetricType_COUNTER.Enum(),
				Metric: []*dto.Metric{
					{
						Counter: &dto.Counter{
							Value: proto.Float64(1027),
							Exemplar: &dto.Exemplar{
								Label: []*dto.LabelPair{
									{Name: proto.String("trace\nid"), Value: proto.String("1234")},
								},
								Value:     proto.Float64(1),
								Timestamp: &timestamppb.Timestamp{Seconds: 1234567890},
							},
						},
					},
				},
			},
			out: `# TYPE http_requests_total counter
http_requests_total 1027.0
`,
		},
		{
			name: "CounterWithNilExemplarLabelPair",
			in: &dto.MetricFamily{
				Name: proto.String("http_requests_total"),
				Type: dto.MetricType_COUNTER.Enum(),
				Metric: []*dto.Metric{
					{
						Counter: &dto.Counter{
							Value: proto.Float64(1027),
							Exemplar: &dto.Exemplar{
								Label:     []*dto.LabelPair{nil},
								Value:     proto.Float64(1),
								Timestamp: &timestamppb.Timestamp{Seconds: 1234567890},
							},
						},
					},
				},
			},
			out: `# TYPE http_requests_total counter
http_requests_total 1027.0
`,
		},
		{
			name: "CounterWithNaNExemplar",
			in: &dto.MetricFamily{
				Name: proto.String("http_requests_total"),
				Type: dto.MetricType_COUNTER.Enum(),
				Metric: []*dto.Metric{
					{
						Counter: &dto.Counter{
							Value: proto.Float64(1027),
							Exemplar: &dto.Exemplar{
								Label: []*dto.LabelPair{
									{Name: proto.String("trace_id"), Value: proto.String("1234")},
								},
								Value:     proto.Float64(math.NaN()),
								Timestamp: &timestamppb.Timestamp{Seconds: 1234567890},
							},
						},
					},
				},
			},
			out: `# TYPE http_requests_total counter
http_requests_total 1027.0 # {trace_id="1234"} NaN 1234567890
`,
		},
		{
			name: "Untyped",
			in: &dto.MetricFamily{
				Name: proto.String("test_metric"),
				Type: dto.MetricType_UNTYPED.Enum(),
				Metric: []*dto.Metric{
					{
						Untyped: &dto.Untyped{
							Value: proto.Float64(1.23),
						},
					},
				},
			},
			out: `# TYPE test_metric unknown
test_metric 1.23
`,
		},
		{
			name: "CounterWithoutCreatedTimestamp",
			in: &dto.MetricFamily{
				Name: proto.String("http_requests_total"),
				Type: dto.MetricType_COUNTER.Enum(),
				Metric: []*dto.Metric{
					{
						Counter: &dto.Counter{
							Value: proto.Float64(1027),
						},
					},
				},
			},
			out: `# TYPE http_requests_total counter
http_requests_total 1027.0
`,
		},
		{
			name: "GaugeWithAccidentalCounterCreatedTimestamp",
			in: &dto.MetricFamily{
				Name: proto.String("node_memory_active_bytes"),
				Help: proto.String("Active memory in bytes."),
				Type: dto.MetricType_GAUGE.Enum(),
				Metric: []*dto.Metric{
					{
						Gauge: &dto.Gauge{
							Value: proto.Float64(1.2345e+09),
						},
						Counter: &dto.Counter{
							CreatedTimestamp: &timestamppb.Timestamp{Seconds: 1234567890},
						},
					},
				},
			},
			out: `# HELP node_memory_active_bytes Active memory in bytes.
# TYPE node_memory_active_bytes gauge
node_memory_active_bytes 1.2345e+09
`,
		},
		{
			name: "UntypedWithAccidentalCounterCreatedTimestamp",
			in: &dto.MetricFamily{
				Name: proto.String("test_metric"),
				Type: dto.MetricType_UNTYPED.Enum(),
				Metric: []*dto.Metric{
					{
						Untyped: &dto.Untyped{
							Value: proto.Float64(1.23),
						},
						Counter: &dto.Counter{
							CreatedTimestamp: &timestamppb.Timestamp{Seconds: 1234567890},
						},
					},
				},
			},
			out: `# TYPE test_metric unknown
test_metric 1.23
`,
		},
		{
			name: "UTF8Support",
			in: &dto.MetricFamily{
				Name: proto.String("你好_total"),
				Type: dto.MetricType_COUNTER.Enum(),
				Metric: []*dto.Metric{
					{
						Label: []*dto.LabelPair{
							{Name: proto.String("🌎"), Value: proto.String("🌍")},
						},
						Counter: &dto.Counter{
							Value: proto.Float64(1027),
						},
					},
				},
			},
			out: `# TYPE "你好_total" counter
{"你好_total","🌎"="🌍"} 1027.0
`,
		},
	}

	for _, scenario := range scenarios {
		t.Run(scenario.name, func(t *testing.T) {
			var buf bytes.Buffer
			n, err := MetricFamilyToOpenMetrics20(&buf, scenario.in)
			if err != nil {
				t.Fatal(err)
			}
			if buf.String() != scenario.out {
				t.Errorf("expected out:\n%s\ngot:\n%s", scenario.out, buf.String())
			}
			if n != len(scenario.out) {
				t.Errorf("expected %d bytes written, got %d", len(scenario.out), n)
			}
		})
	}
}

func TestWriteOpenMetrics20Timestamp(t *testing.T) {
	tests := []struct {
		name string
		val  float64
		out  string
	}{
		{"Integer", 1234567890, "1234567890"},
		{"Subsecond", 1234567890.123, "1234567890.123"},
		{"Zero", 0, "0"},
		{"NaN", math.NaN(), "NaN"},
		{"+Inf", math.Inf(+1), "+Inf"},
		{"-Inf", math.Inf(-1), "-Inf"},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			var buf bytes.Buffer
			w := enhancedWriter(&buf)
			n, err := writeOpenMetrics20Timestamp(w, tc.val)
			if err != nil {
				t.Fatal(err)
			}
			if buf.String() != tc.out {
				t.Errorf("expected %q, got %q", tc.out, buf.String())
			}
			if n != len(tc.out) {
				t.Errorf("expected %d bytes written, got %d", len(tc.out), n)
			}
		})
	}
}

func TestCreateOpenMetrics20_Errors(t *testing.T) {
	tests := []struct {
		name        string
		in          *dto.MetricFamily
		expectedErr string
	}{
		{
			name: "NoName",
			in: &dto.MetricFamily{
				Type: dto.MetricType_COUNTER.Enum(),
			},
			expectedErr: "MetricFamily has no name",
		},
		{
			name: "UnknownType",
			in: &dto.MetricFamily{
				Name: proto.String("test_metric"),
				Type: dto.MetricType(100).Enum(),
			},
			expectedErr: "unknown metric type",
		},
		{
			name: "MissingCounter",
			in: &dto.MetricFamily{
				Name: proto.String("test_metric"),
				Type: dto.MetricType_COUNTER.Enum(),
				Metric: []*dto.Metric{
					{},
				},
			},
			expectedErr: "expected counter in metric",
		},
		{
			name: "MissingGauge",
			in: &dto.MetricFamily{
				Name: proto.String("test_metric"),
				Type: dto.MetricType_GAUGE.Enum(),
				Metric: []*dto.Metric{
					{},
				},
			},
			expectedErr: "expected gauge in metric",
		},
		{
			name: "MissingUntyped",
			in: &dto.MetricFamily{
				Name: proto.String("test_metric"),
				Type: dto.MetricType_UNTYPED.Enum(),
				Metric: []*dto.Metric{
					{},
				},
			},
			expectedErr: "expected untyped in metric",
		},
		{
			name: "MissingSummary",
			in: &dto.MetricFamily{
				Name: proto.String("test_metric"),
				Type: dto.MetricType_SUMMARY.Enum(),
				Metric: []*dto.Metric{
					{},
				},
			},
			expectedErr: "expected summary in metric",
		},
		{
			name: "MissingHistogram",
			in: &dto.MetricFamily{
				Name: proto.String("test_metric"),
				Type: dto.MetricType_HISTOGRAM.Enum(),
				Metric: []*dto.Metric{
					{},
				},
			},
			expectedErr: "expected histogram in metric",
		},
		{
			name: "SummaryNotImplemented",
			in: &dto.MetricFamily{
				Name: proto.String("test_metric"),
				Type: dto.MetricType_SUMMARY.Enum(),
				Metric: []*dto.Metric{
					{Summary: &dto.Summary{}},
				},
			},
			expectedErr: "summary not implemented yet",
		},
		{
			name: "HistogramNotImplemented",
			in: &dto.MetricFamily{
				Name: proto.String("test_metric"),
				Type: dto.MetricType_HISTOGRAM.Enum(),
				Metric: []*dto.Metric{
					{Histogram: &dto.Histogram{}},
				},
			},
			expectedErr: "histogram not implemented yet",
		},
		{
			name: "GaugeHistogramNotImplemented",
			in: &dto.MetricFamily{
				Name: proto.String("test_metric"),
				Type: dto.MetricType_GAUGE_HISTOGRAM.Enum(),
				Metric: []*dto.Metric{
					{Histogram: &dto.Histogram{}},
				},
			},
			expectedErr: "histogram not implemented yet",
		},
		{
			name: "CounterValueNaN",
			in: &dto.MetricFamily{
				Name: proto.String("test_counter_total"),
				Type: dto.MetricType_COUNTER.Enum(),
				Metric: []*dto.Metric{
					{Counter: &dto.Counter{Value: proto.Float64(math.NaN())}},
				},
			},
			expectedErr: "counter value cannot be NaN",
		},
		{
			name: "CounterValueNegative",
			in: &dto.MetricFamily{
				Name: proto.String("test_counter_total"),
				Type: dto.MetricType_COUNTER.Enum(),
				Metric: []*dto.Metric{
					{Counter: &dto.Counter{Value: proto.Float64(-5.0)}},
				},
			},
			expectedErr: "counter value cannot be negative",
		},
		{
			name: "EmptyLabelName",
			in: &dto.MetricFamily{
				Name: proto.String("test_counter_total"),
				Type: dto.MetricType_COUNTER.Enum(),
				Metric: []*dto.Metric{
					{
						Label: []*dto.LabelPair{
							{Name: proto.String(""), Value: proto.String("bar")},
						},
						Counter: &dto.Counter{Value: proto.Float64(1.0)},
					},
				},
			},
			expectedErr: "label name cannot be empty",
		},
		{
			name: "NewlineInMetricName",
			in: &dto.MetricFamily{
				Name: proto.String("test_counter\ntotal"),
				Type: dto.MetricType_COUNTER.Enum(),
				Metric: []*dto.Metric{
					{Counter: &dto.Counter{Value: proto.Float64(1.0)}},
				},
			},
			expectedErr: "contains raw newlines",
		},
		{
			name: "NewlineInUnit",
			in: &dto.MetricFamily{
				Name: proto.String("test_counter_total"),
				Type: dto.MetricType_COUNTER.Enum(),
				Unit: proto.String("seconds\n"),
				Metric: []*dto.Metric{
					{Counter: &dto.Counter{Value: proto.Float64(1.0)}},
				},
			},
			expectedErr: "contains raw newlines",
		},
		{
			name: "CarriageReturnInUnit",
			in: &dto.MetricFamily{
				Name: proto.String("test_counter_total"),
				Type: dto.MetricType_COUNTER.Enum(),
				Unit: proto.String("seconds\r"),
				Metric: []*dto.Metric{
					{Counter: &dto.Counter{Value: proto.Float64(1.0)}},
				},
			},
			expectedErr: "contains raw newlines",
		},
		{
			name: "NilMetric",
			in: &dto.MetricFamily{
				Name:   proto.String("test_counter_total"),
				Type:   dto.MetricType_COUNTER.Enum(),
				Metric: []*dto.Metric{nil},
			},
			expectedErr: "expected non-nil metric",
		},
		{
			name: "NilLabelPair",
			in: &dto.MetricFamily{
				Name: proto.String("test_counter_total"),
				Type: dto.MetricType_COUNTER.Enum(),
				Metric: []*dto.Metric{
					{
						Label:   []*dto.LabelPair{nil},
						Counter: &dto.Counter{Value: proto.Float64(1.0)},
					},
				},
			},
			expectedErr: "expected non-nil label pair",
		},
		{
			name: "CounterInvalidCreatedTimestamp",
			in: &dto.MetricFamily{
				Name: proto.String("test_counter_total"),
				Type: dto.MetricType_COUNTER.Enum(),
				Metric: []*dto.Metric{
					{
						Counter: &dto.Counter{
							Value: proto.Float64(1.0),
							CreatedTimestamp: &timestamppb.Timestamp{
								Nanos: -1,
							},
						},
					},
				},
			},
			expectedErr: "invalid created timestamp in metric test_counter_total",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			var buf bytes.Buffer
			_, err := MetricFamilyToOpenMetrics20(&buf, tc.in)
			if err == nil {
				t.Fatal("expected error, got nil")
			}
			if !strings.Contains(err.Error(), tc.expectedErr) {
				t.Fatalf("expected error containing %q, got %q", tc.expectedErr, err.Error())
			}
		})
	}
}

func TestWriteOpenMetrics20Sample_UseIntValue(t *testing.T) {
	var buf bytes.Buffer
	w := enhancedWriter(&buf)
	metric := &dto.Metric{}
	n, err := writeOpenMetrics20Sample(w, "test_metric", metric, 0, 123, true, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	expected := "test_metric 123\n"
	if buf.String() != expected {
		t.Errorf("expected %q, got %q", expected, buf.String())
	}
	if n != len(expected) {
		t.Errorf("expected %d bytes written, got %d", len(expected), n)
	}
}

func TestWriteProtoTimestamp(t *testing.T) {
	tests := []struct {
		name string
		ts   *timestamppb.Timestamp
		out  string
	}{
		{
			name: "WholeSecondsPositive",
			ts:   &timestamppb.Timestamp{Seconds: 1234567890},
			out:  "1234567890",
		},
		{
			name: "SubsecondPositive",
			ts:   &timestamppb.Timestamp{Seconds: 1234567890, Nanos: 500000000},
			out:  "1234567890.5",
		},
		{
			name: "SubsecondPositiveFullPrecision",
			ts:   &timestamppb.Timestamp{Seconds: 1234567890, Nanos: 987654321},
			out:  "1234567890.987654321",
		},
		{
			name: "ZeroSecondsSubsecond",
			ts:   &timestamppb.Timestamp{Seconds: 0, Nanos: 500000000},
			out:  "0.5",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			var buf bytes.Buffer
			w := enhancedWriter(&buf)
			n, err := writeProtoTimestamp(w, tc.ts)
			if err != nil {
				t.Fatal(err)
			}
			if buf.String() != tc.out {
				t.Errorf("expected %q, got %q", tc.out, buf.String())
			}
			if n != len(tc.out) {
				t.Errorf("expected %d bytes written, got %d", len(tc.out), n)
			}
		})
	}
}

func TestCreateOpenMetrics20_SimpleWriter(t *testing.T) {
	in := &dto.MetricFamily{
		Name: proto.String("http_requests_total"),
		Type: dto.MetricType_COUNTER.Enum(),
		Metric: []*dto.Metric{
			{
				Counter: &dto.Counter{
					Value: proto.Float64(1027),
				},
			},
		},
	}

	var buf bytes.Buffer
	// Wrap bytes.Buffer in a struct that only implements io.Writer
	sw := struct {
		io.Writer
	}{&buf}

	n, err := MetricFamilyToOpenMetrics20(sw, in)
	if err != nil {
		t.Fatal(err)
	}

	expected := `# TYPE http_requests_total counter
http_requests_total 1027.0
`
	if buf.String() != expected {
		t.Errorf("expected %q, got %q", expected, buf.String())
	}
	if n != len(expected) {
		t.Errorf("expected %d bytes written, got %d", len(expected), n)
	}
}
