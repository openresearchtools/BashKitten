module github.com/prometheus/common

go 1.25.0

require (
	github.com/alecthomas/kingpin/v2 v2.4.0
	github.com/golang-jwt/jwt/v5 v5.3.1
	github.com/google/go-cmp v0.7.0
	github.com/google/uuid v1.6.0
	github.com/julienschmidt/httprouter v1.3.0
	github.com/munnerz/goautoneg v0.0.0-20191010083416-a7dc8b61c822
	github.com/mwitkow/go-conntrack v0.0.0-20190716064945-2f068394615f
	github.com/prometheus/client_model v0.6.2
	github.com/stretchr/testify v1.12.1
	go.yaml.in/yaml/v2 v2.4.4
	golang.org/x/net v0.58.0
	golang.org/x/oauth2 v0.36.0
	google.golang.org/protobuf v1.36.12
)

require (
	github.com/alecthomas/units v0.0.0-20240927000941-0f3dac36c52b // indirect
	github.com/beorn7/perks v1.0.1 // indirect
	github.com/cespare/xxhash/v2 v2.3.0 // indirect
	github.com/jpillora/backoff v1.0.0 // indirect
	github.com/prometheus/client_golang v1.23.2 // indirect
	github.com/prometheus/procfs v0.21.0 // indirect
	github.com/xhit/go-str2duration/v2 v2.1.0 // indirect
	go.yaml.in/yaml/v3 v3.0.5 // indirect
	golang.org/x/sys v0.47.0 // indirect
	golang.org/x/text v0.41.0 // indirect
)

retract (
	v1.20.99 // This tag is needed to retract accidental tags below, but is retracted directly.
	v1.20.3 // Tags pushed accidentally, see https://github.com/prometheus/common/issues/831
	v1.20.3
	v1.20.2
	v1.20.1
	v1.20.0
	v1.19.1
	v1.19.0
	v1.18.0
	v1.17.0
	v1.16.0
	v1.15.1
	v1.15.0
	v1.14.0
	v1.13.1
	v1.13.0
	v1.12.2
	v1.12.1
	v1.12.0
	v1.11.1
	v1.11.0
	v1.10.0
	v1.9.0
	v1.8.0
	v1.7.1
	v1.7.0
	v1.6.0
	v1.5.1
	v1.5.0
	v1.4.1
	v1.4.0
	v1.3.0
	v1.2.1
	v1.2.0
	v1.1.0
	v1.0.0
	v0.50.0 // Critical bug in counter suffixes, please read issue https://github.com/prometheus/common/issues/605
)
