module github.com/go-webauthn/x

go 1.26.0

toolchain go1.27.1

require (
	github.com/stretchr/testify v1.12.1
	golang.org/x/crypto v0.57.0
)

require go.yaml.in/yaml/v3 v3.0.5 // indirect
