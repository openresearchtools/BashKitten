package protocol

import (
	"bytes"
	"context"
	"crypto/sha256"
	"crypto/x509"
	"encoding/base64"
	"fmt"
	"slices"
	"time"

	"github.com/go-viper/mapstructure/v2"
	"github.com/golang-jwt/jwt/v5"

	"github.com/go-webauthn/webauthn/metadata"
)

// attestationFormatValidationHandlerAndroidSafetyNet is the handler for the Android SafetyNet Attestation Statement
// Format.
//
// When the authenticator is a platform authenticator on certain Android platforms, the attestation statement may be
// based on the SafetyNet API. In this case the authenticator data is completely controlled by the caller of the
// SafetyNet API (typically an application running on the Android platform) and the attestation statement provides some
// statements about the health of the platform and the identity of the calling application (see SafetyNet Documentation
// for more details).
//
// The syntax of an Android Attestation statement is defined as follows:
//
//	$$attStmtType //= (
//			fmt: "android-safetynet",
//			attStmt: safetynetStmtFormat
//	)
//
//	safetynetStmtFormat = {
//			ver: text,
//			response: bytes
//	}
//
// Specification: §8.5. Android SafetyNet Attestation Statement Format
//
// See: https://www.w3.org/TR/webauthn/#sctn-android-safetynet-attestation
func attestationFormatValidationHandlerAndroidSafetyNet(att AttestationObject, clientDataHash []byte, mds metadata.Provider, _ AttestationPolicy, _ SignaturePolicy) (attestationType string, x5cs []any, err error) {
	// The syntax of an Android Attestation statement is defined as follows:
	//     $$attStmtType //= (
	//                           fmt: "android-safetynet",
	//                           attStmt: safetynetStmtFormat
	//                       )

	//     safetynetStmtFormat = {
	//                               ver: text,
	//                               response: bytes
	//                           }

	// §8.5.1 Verify that attStmt is valid CBOR conforming to the syntax defined above and perform CBOR decoding on it to extract
	// the contained fields.

	// We have done this
	// §8.5.2 Verify that response is a valid SafetyNet response of version ver.
	version, present := att.AttStatement[stmtVersion].(string)
	if !present {
		return "", nil, ErrAttestationFormat.WithDetails("Unable to find the version of SafetyNet")
	}

	if version == "" {
		return "", nil, ErrAttestationFormat.WithDetails("Not a proper version for SafetyNet")
	}

	// TODO: provide user the ability to designate their supported versions.

	response, present := att.AttStatement["response"].([]byte)
	if !present {
		return "", nil, ErrAttestationFormat.WithDetails("Unable to find the SafetyNet response")
	}

	var token *jwt.Token

	// §8.5.2 and §8.5.4 Verify that response is a valid SafetyNet response of version ver, and that it actually came
	// from the SafetyNet service, by following the steps indicated by the SafetyNet online documentation. Those steps
	// require the certificate chain in the JWS header be validated and the leaf matched to the SafetyNet hostname
	// before the signature is verified with it, which the verifier below performs as part of supplying the key.
	verifier := &safetyNetJWTVerifier{}

	if token, err = jwt.Parse(string(response), verifier.keyFunc, jwt.WithValidMethods([]string{jwt.SigningMethodRS256.Alg()})); err != nil {
		return "", nil, ErrInvalidAttestation.WithDetails(fmt.Sprintf("Error verifying the SafetyNet response signature: %+v", err)).WithError(err)
	}

	// marshall the JWT payload into the safetynet response json.
	var safetyNetResponse SafetyNetResponse

	if err = mapstructure.Decode(token.Claims, &safetyNetResponse); err != nil {
		return "", nil, ErrAttestationFormat.WithDetails(fmt.Sprintf("Error parsing the SafetyNet response: %+v", err)).WithError(err)
	}

	// §8.5.3 Verify that the nonce in the response is identical to the Base64 encoding of the SHA-256 hash of the concatenation
	// of authenticatorData and clientDataHash.
	nonceBuffer := sha256.Sum256(slices.Concat(att.RawAuthData, clientDataHash))

	nonceBytes, err := base64.StdEncoding.DecodeString(safetyNetResponse.Nonce)
	if !bytes.Equal(nonceBuffer[:], nonceBytes) || err != nil {
		return "", nil, ErrInvalidAttestation.WithDetails("Invalid nonce for in SafetyNet response").WithError(err)
	}

	// §8.5.5 Verify that attestationCert is issued to the hostname "attest.android.com". This is performed by the
	// verifier above as part of the chain validation rather than against a certificate nothing has vouched for.

	// §8.5.6 Verify that the ctsProfileMatch attribute in the payload of response is true.
	if !safetyNetResponse.CtsProfileMatch {
		return "", nil, ErrInvalidAttestation.WithDetails("ctsProfileMatch attribute of the JWT payload is false")
	}

	if t := time.Unix(safetyNetResponse.TimestampMs/1000, 0); t.After(time.Now()) {
		// Zero tolerance for post-dated timestamps.
		return "", nil, ErrInvalidAttestation.WithDetails("SafetyNet response with timestamp after current time")
	} else if t.Before(time.Now().Add(-time.Minute)) {
		// Small tolerance for pre-dated timestamps.
		if mds != nil && mds.GetValidateEntry(context.Background()) {
			return "", nil, ErrInvalidAttestation.WithDetails("SafetyNet response with timestamp before one minute ago")
		}
	}

	// §8.5.7 If successful, return implementation-specific values representing attestation type Basic and attestation
	// trust path attestationCert.
	return string(metadata.BasicFull), nil, nil
}

// safetyNetJWTVerifier verifies the certificate chain carried in the JWS x5c header before releasing the leaf public
// key to the JWT parser, and retains the chain so it can be used as the attestation trust path.
//
// The SafetyNet documentation requires the chain be validated and the leaf matched to the SafetyNet hostname before
// the signature is verified with it. Releasing the leaf public key without doing so allows any self-signed
// certificate bearing that hostname to sign an entirely forged response.
type safetyNetJWTVerifier struct {
	x5c   []any
	certs []*x509.Certificate
}

func (v *safetyNetJWTVerifier) keyFunc(token *jwt.Token) (key any, err error) {
	var (
		ok    bool
		raw   any
		chain []any
	)

	if raw, ok = token.Header[stmtX5C]; !ok {
		return nil, fmt.Errorf("jwt header missing x5c")
	}

	if chain, ok = raw.([]any); !ok || len(chain) == 0 {
		return nil, fmt.Errorf("jwt header x5c is not a non-empty array")
	}

	certs := make([]*x509.Certificate, len(chain))

	for i, element := range chain {
		var (
			value string
			der   []byte
		)

		if value, ok = element.(string); !ok || value == "" {
			return nil, fmt.Errorf("jwt header x5c[%d] is not a base64 string", i)
		}

		if der, err = base64.StdEncoding.DecodeString(value); err != nil {
			return nil, fmt.Errorf("decode x5c[%d]: %w", i, err)
		}

		if certs[i], err = x509.ParseCertificate(der); err != nil {
			return nil, fmt.Errorf("parse x5c[%d]: %w", i, err)
		}
	}

	roots := attStatementAndroidSafetyNetRootsCertPool

	if roots == nil {
		if roots, err = x509.SystemCertPool(); err != nil {
			return nil, fmt.Errorf("load system trust store: %w", err)
		}
	}

	intermediates := x509.NewCertPool()

	for _, cert := range certs[1:] {
		intermediates.AddCert(cert)
	}

	// The leaf is a TLS server certificate so the hostname match of §8.5.5 is performed here as part of the chain
	// verification, and ExtKeyUsageServerAuth is the applicable usage.
	if _, err = certs[0].Verify(x509.VerifyOptions{
		DNSName:       attStatementAndroidSafetyNetHostname,
		Roots:         roots,
		Intermediates: intermediates,
		KeyUsages:     []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
	}); err != nil {
		return nil, fmt.Errorf("verify x5c chain: %w", err)
	}

	v.x5c, v.certs = chain, certs

	return certs[0].PublicKey, nil
}

type SafetyNetResponse struct {
	Nonce                      string `json:"nonce"`
	TimestampMs                int64  `json:"timestampMs"`
	ApkPackageName             string `json:"apkPackageName"`
	ApkDigestSha256            string `json:"apkDigestSha256"`
	CtsProfileMatch            bool   `json:"ctsProfileMatch"`
	ApkCertificateDigestSha256 []any  `json:"apkCertificateDigestSha256"`
	BasicIntegrity             bool   `json:"basicIntegrity"`
}

var (
	// attStatementAndroidSafetyNetRootsCertPool contains the trust anchors used to verify the certificate chain which
	// signs a SafetyNet response. A nil pool causes the host system trust store to be used, which is the correct
	// default as the leaf is an ordinary WebPKI TLS certificate issued to the SafetyNet hostname rather than an
	// attestation specific root.
	attStatementAndroidSafetyNetRootsCertPool *x509.CertPool
)

func init() {
	RegisterAttestationFormat(AttestationFormatAndroidSafetyNet, attestationFormatValidationHandlerAndroidSafetyNet)
}
