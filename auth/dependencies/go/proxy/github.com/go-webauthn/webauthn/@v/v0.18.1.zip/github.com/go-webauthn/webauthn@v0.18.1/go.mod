module github.com/go-webauthn/webauthn

go 1.26.0

toolchain go1.27.1

require (
	github.com/fxamacker/cbor/v2 v2.9.3
	github.com/go-viper/mapstructure/v2 v2.5.0
	github.com/go-webauthn/x v0.3.1
	github.com/golang-jwt/jwt/v5 v5.3.1
	github.com/google/go-tpm v0.9.8
	github.com/google/uuid v1.6.0
	github.com/stretchr/testify v1.12.1
	github.com/tinylib/msgp v1.6.4
	go.uber.org/mock v0.6.0
)

require (
	github.com/philhofer/fwd v1.2.0 // indirect
	github.com/x448/float16 v0.8.4 // indirect
	go.yaml.in/yaml/v3 v3.0.5 // indirect
	golang.org/x/crypto v0.57.0 // indirect
	golang.org/x/sys v0.48.0 // indirect
)
