package protocol

import (
	"encoding/base64"
	"encoding/json"
	"fmt"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestURLEncodedBase64_MarshalJSON(t *testing.T) {
	testCases := []struct {
		name     string
		have     URLEncodedBase64
		expected string
	}{
		{
			name:     "ShouldMarshalData",
			have:     URLEncodedBase64("test data"),
			expected: `"dGVzdCBkYXRh"`,
		},
		{
			name:     "ShouldMarshalNil",
			have:     nil,
			expected: `null`,
		},
		{
			name:     "ShouldMarshalEmpty",
			have:     URLEncodedBase64{},
			expected: `""`,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			data, err := tc.have.MarshalJSON()
			require.NoError(t, err)
			assert.Equal(t, tc.expected, string(data))
		})
	}
}

func TestURLEncodedBase64_UnmarshalJSON_Error(t *testing.T) {
	testCases := []struct {
		name string
		data string
		err  string
	}{
		{
			name: "ShouldFailInvalidBase64",
			data: `"not valid base64!!!"`,
			err:  "illegal base64 data at input byte 3",
		},
		{
			name: "ShouldFailJSONNumber",
			data: `123456`,
			err:  errBase64NotJSONString.Error(),
		},
		{
			name: "ShouldFailJSONBoolean",
			data: `true`,
			err:  errBase64NotJSONString.Error(),
		},
		{
			name: "ShouldFailJSONObject",
			data: `{"a":"b"}`,
			err:  errBase64NotJSONString.Error(),
		},
		{
			name: "ShouldFailJSONArray",
			data: `["YWJj"]`,
			err:  errBase64NotJSONString.Error(),
		},
		{
			name: "ShouldFailUnterminatedJSONString",
			data: `"YWJj`,
			err:  errBase64NotJSONString.Error(),
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			var e URLEncodedBase64

			assert.EqualError(t, e.UnmarshalJSON([]byte(tc.data)), tc.err)
		})
	}
}

func TestBase64UnmarshalJSON(t *testing.T) {
	type testData struct {
		StringData  string           `json:"string_data"`
		EncodedData URLEncodedBase64 `json:"encoded_data"`
	}

	testCases := []struct {
		name     string
		message  string
		expected testData
		err      string
	}{
		{
			name:    "ShouldHandleBase64Data",
			message: "\"" + base64.RawURLEncoding.EncodeToString([]byte("test base64 data")) + "\"",
			expected: testData{
				StringData:  "test string",
				EncodedData: URLEncodedBase64("test base64 data"),
			},
			err: "",
		},
		{
			name:    "ShouldHandleNull",
			message: "null",
			expected: testData{
				StringData:  "test string",
				EncodedData: nil,
			},
			err: "",
		},
		{
			name:    "ShouldHandlePaddedBase64Data",
			message: `"YWJjZA=="`,
			expected: testData{
				StringData:  "test string",
				EncodedData: URLEncodedBase64("abcd"),
			},
			err: "",
		},
		{
			name:    "ShouldHandleEscapedBase64Data",
			message: `"\u0059\u0057\u004a\u006a"`,
			expected: testData{
				StringData:  "test string",
				EncodedData: URLEncodedBase64("abc"),
			},
			err: "",
		},
		{
			name:    "ShouldHandlePartiallyEscapedBase64Data",
			message: `"YW\u004aj"`,
			expected: testData{
				StringData:  "test string",
				EncodedData: URLEncodedBase64("abc"),
			},
			err: "",
		},
		{
			name:    "ShouldHandleEmptyString",
			message: `""`,
			expected: testData{
				StringData:  "test string",
				EncodedData: URLEncodedBase64{},
			},
			err: "",
		},
	}

	for _, tc := range testCases {
		raw := fmt.Sprintf(`{"string_data": "test string", "encoded_data": %s}`, tc.message)
		actual := &testData{}

		if tc.err != "" {
			assert.EqualError(t, json.NewDecoder(strings.NewReader(raw)).Decode(actual), tc.err)
		} else {
			assert.NoError(t, json.NewDecoder(strings.NewReader(raw)).Decode(actual))
		}

		assert.Equal(t, tc.expected.EncodedData, actual.EncodedData)
		assert.Equal(t, tc.expected.StringData, actual.StringData)
	}
}
