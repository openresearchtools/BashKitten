// Copyright 2023, Google Inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// Package callctx provides helpers for storing and retrieving values out of
// [context.Context]. These values are used by our client libraries in various
// ways across the stack.
package callctx

import (
	"context"
	"fmt"
	"log/slog"
)

const (
	// XGoogFieldMaskHeader is the canonical header key for the [System Parameter]
	// that specifies the response read mask. The value(s) for this header
	// must adhere to format described in [fieldmaskpb].
	//
	// [System Parameter]: https://cloud.google.com/apis/docs/system-parameters
	// [fieldmaskpb]: https://google.golang.org/protobuf/types/known/fieldmaskpb
	XGoogFieldMaskHeader = "x-goog-fieldmask"

	headerKey = contextKey("header")
)

// contextKey is a private type used to store/retrieve context values.
type contextKey string

// HeadersFromContext retrieves headers set from [SetHeaders]. These headers
// can then be cast to http.Header or metadata.MD to send along on requests.
func HeadersFromContext(ctx context.Context) map[string][]string {
	m, ok := ctx.Value(headerKey).(map[string][]string)
	if !ok {
		return nil
	}
	return m
}

// SetHeaders stores key value pairs in the returned context that can later
// be retrieved by [HeadersFromContext]. Values stored in this manner will
// automatically be retrieved by client libraries and sent as outgoing headers
// on all requests. keyvals should have a corresponding value for every key
// provided. If there is an odd number of keyvals this method will panic.
func SetHeaders(ctx context.Context, keyvals ...string) context.Context {
	if len(keyvals)%2 != 0 {
		panic(fmt.Sprintf("callctx: an even number of key value pairs must be provided, got %d", len(keyvals)))
	}
	h, ok := ctx.Value(headerKey).(map[string][]string)
	if !ok {
		h = make(map[string][]string)
	} else {
		h = cloneHeaders(h)
	}

	for i := 0; i < len(keyvals); i = i + 2 {
		h[keyvals[i]] = append(h[keyvals[i]], keyvals[i+1])
	}
	return context.WithValue(ctx, headerKey, h)
}

// cloneHeaders makes a new key-value map while reusing the value slices.
// As such, new values should be appended to the value slice, and modifying
// indexed values is not thread safe.
//
// TODO: Replace this with maps.Clone when Go 1.21 is the minimum version.
func cloneHeaders(h map[string][]string) map[string][]string {
	c := make(map[string][]string, len(h))
	for k, v := range h {
		vc := make([]string, len(v))
		copy(vc, v)
		c[k] = vc
	}
	return c
}

// telemetryKey is a private type used to store/retrieve telemetry context values.
type telemetryKey string

// WithTelemetryContext injects telemetry attribute values (like resource name
// or client version) into the context. In accordance with standard Go context
// guidelines, this should only be used for data that transits processes and APIs,
// and not for passing optional parameters to functions. keyvals should have a
// corresponding value for every key provided. If there is an odd number of keyvals
// this method will panic.
func WithTelemetryContext(ctx context.Context, keyvals ...string) context.Context {
	if len(keyvals)%2 != 0 {
		panic(fmt.Sprintf("callctx: an even number of key value pairs must be provided, got %d", len(keyvals)))
	}

	for i := 0; i < len(keyvals); i = i + 2 {
		ctx = context.WithValue(ctx, telemetryKey(keyvals[i]), keyvals[i+1])
	}
	return ctx
}

// TelemetryFromContext extracts a telemetry attribute value from the context.
// The returned bool indicates a successful typecast of the value to a string.
func TelemetryFromContext(ctx context.Context, key string) (string, bool) {
	val, ok := ctx.Value(telemetryKey(key)).(string)
	return val, ok
}

// loggerKey is a private type used to store/retrieve the logger context value.
type loggerContextKey string

const loggerCKey = loggerContextKey("logger")

// WithLoggerContext injects a slog.Logger into the context. This logger will
// be extracted by the client library or transport wrappers to emit logs.
func WithLoggerContext(ctx context.Context, logger *slog.Logger) context.Context {
	return context.WithValue(ctx, loggerCKey, logger)
}

// LoggerFromContext extracts a slog.Logger from the context.
// The returned bool indicates whether a logger was found.
func LoggerFromContext(ctx context.Context) (*slog.Logger, bool) {
	logger, ok := ctx.Value(loggerCKey).(*slog.Logger)
	return logger, ok
}
