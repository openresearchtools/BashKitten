package fasthttp

import (
	"bytes"
	"errors"
	"fmt"
	"io"
	"sync"

	"github.com/valyala/bytebufferpool"
	"github.com/valyala/fasthttp/stackless"

	brotli "github.com/molecule-man/go-brrr"
)

// Supported compression levels.
const (
	CompressBrotliNoCompression   = 0
	CompressBrotliBestSpeed       = brotli.BestSpeed
	CompressBrotliBestCompression = brotli.BestCompression

	// CompressBrotliDefaultCompression chooses a default brotli compression level comparable to
	// CompressDefaultCompression (gzip 6).
	// See: https://github.com/valyala/fasthttp/issues/798#issuecomment-626293806
	CompressBrotliDefaultCompression = 4
)

func acquireBrotliReader(r io.Reader) *brotli.Reader {
	v := brotliReaderPool.Get()
	if v == nil {
		return brotli.NewReader(r)
	}
	zr := v.(*brotli.Reader) //nolint:forcetypeassert
	zr.Reset(r)
	return zr
}

func releaseBrotliReader(zr *brotli.Reader) {
	brotliReaderPool.Put(zr)
}

var brotliReaderPool sync.Pool

func acquireStacklessBrotliWriter(w io.Writer, level int) stackless.Writer {
	nLevel := normalizeBrotliCompressLevel(level)
	p := stacklessBrotliWriterPoolMap[nLevel]
	v := p.Get()
	if v == nil {
		return stackless.NewWriter(w, func(w io.Writer) stackless.Writer {
			return acquireRealBrotliWriter(w, level)
		})
	}
	sw := v.(stackless.Writer) //nolint:forcetypeassert
	sw.Reset(w)
	return sw
}

func releaseStacklessBrotliWriter(sw stackless.Writer, level int) {
	sw.Close()
	nLevel := normalizeBrotliCompressLevel(level)
	p := stacklessBrotliWriterPoolMap[nLevel]
	p.Put(sw)
}

func acquireRealBrotliWriter(w io.Writer, level int) *brotli.Writer {
	nLevel := normalizeBrotliCompressLevel(level)
	p := realBrotliWriterPoolMap[nLevel]
	v := p.Get()
	if v == nil {
		// nLevel is always in the [0..11] range accepted by brotli.NewWriter,
		// so the error can never be non-nil here.
		zw, _ := brotli.NewWriter(w, nLevel)
		return zw
	}
	zw := v.(*brotli.Writer) //nolint:forcetypeassert
	zw.Reset(w)
	return zw
}

func releaseRealBrotliWriter(zw *brotli.Writer, level int) {
	zw.Close()
	nLevel := normalizeBrotliCompressLevel(level)
	p := realBrotliWriterPoolMap[nLevel]
	p.Put(zw)
}

var (
	stacklessBrotliWriterPoolMap = newCompressWriterPoolMap()
	realBrotliWriterPoolMap      = newCompressWriterPoolMap()
)

// AppendBrotliBytesLevel appends brotlied src to dst using the given
// compression level and returns the resulting dst.
//
// Supported compression levels are:
//
//   - CompressBrotliNoCompression
//   - CompressBrotliBestSpeed
//   - CompressBrotliBestCompression
//   - CompressBrotliDefaultCompression
func AppendBrotliBytesLevel(dst, src []byte, level int) []byte {
	w := &byteSliceWriter{b: dst}
	WriteBrotliLevel(w, src, level) //nolint:errcheck
	return w.b
}

// WriteBrotliLevel writes brotlied p to w using the given compression level
// and returns the number of compressed bytes written to w.
//
// Supported compression levels are:
//
//   - CompressBrotliNoCompression
//   - CompressBrotliBestSpeed
//   - CompressBrotliBestCompression
//   - CompressBrotliDefaultCompression
func WriteBrotliLevel(w io.Writer, p []byte, level int) (int, error) {
	switch w.(type) {
	case *byteSliceWriter,
		*bytes.Buffer,
		*bytebufferpool.ByteBuffer:
		// These writers don't block, so we can just use stacklessWriteBrotli
		ctx := &compressCtx{
			w:     w,
			p:     p,
			level: level,
		}
		stacklessWriteBrotli(ctx)
		return len(p), nil
	default:
		zw := acquireStacklessBrotliWriter(w, level)
		n, err := zw.Write(p)
		releaseStacklessBrotliWriter(zw, level)
		return n, err
	}
}

var (
	stacklessWriteBrotliOnce sync.Once
	stacklessWriteBrotliFunc func(ctx any) bool
)

func stacklessWriteBrotli(ctx any) {
	stacklessWriteBrotliOnce.Do(func() {
		stacklessWriteBrotliFunc = stackless.NewFunc(nonblockingWriteBrotli)
	})
	stacklessWriteBrotliFunc(ctx)
}

func nonblockingWriteBrotli(ctxv any) {
	ctx := ctxv.(*compressCtx) //nolint:forcetypeassert
	zw := acquireRealBrotliWriter(ctx.w, ctx.level)

	zw.Write(ctx.p) //nolint:errcheck // no way to handle this error anyway

	releaseRealBrotliWriter(zw, ctx.level)
}

// WriteBrotli writes brotlied p to w and returns the number of compressed
// bytes written to w.
func WriteBrotli(w io.Writer, p []byte) (int, error) {
	return WriteBrotliLevel(w, p, CompressBrotliDefaultCompression)
}

// AppendBrotliBytes appends brotlied src to dst and returns the resulting dst.
func AppendBrotliBytes(dst, src []byte) []byte {
	return AppendBrotliBytesLevel(dst, src, CompressBrotliDefaultCompression)
}

// WriteUnbrotli writes unbrotlied p to w and returns the number of uncompressed
// bytes written to w.
func WriteUnbrotli(w io.Writer, p []byte) (int, error) {
	return writeUnbrotli(w, p, 0)
}

func writeUnbrotli(w io.Writer, p []byte, maxBodySize int) (int, error) {
	r := newBrotliSliceReader(p)
	zr := acquireBrotliReader(r)
	n, err := copyZeroAllocWithLimit(w, zr, maxBodySize)
	releaseBrotliReader(zr)
	nn := int(n)
	if int64(nn) != n {
		return 0, fmt.Errorf("too much data unbrotlied: %d", n)
	}
	if err == nil && r.excessiveInput() {
		return nn, errBrotliExcessiveInput
	}
	return nn, err
}

// AppendUnbrotliBytes appends unbrotlied src to dst and returns the resulting dst.
func AppendUnbrotliBytes(dst, src []byte) ([]byte, error) {
	w := &byteSliceWriter{b: dst}
	_, err := WriteUnbrotli(w, src)
	return w.b, err
}

// errBrotliExcessiveInput is returned when a complete brotli stream is followed
// by bytes that aren't part of it. github.com/andybalholm/brotli, the decoder
// fasthttp used before, reported this with the same message; go-brrr ignores
// the trailing bytes, so brotliSliceReader detects them instead.
var errBrotliExcessiveInput = errors.New("brotli: excessive input")

// brotliSliceReader hands the decoder everything but the final byte of b,
// releasing that byte only once the decoder asks for more input. A brotli
// stream is self-terminating and its final byte always carries stream bits, so
// a decoder that succeeds without asking for the held back byte ended before
// the end of b: the leftover is excessive input.
type brotliSliceReader struct {
	b []byte
}

func newBrotliSliceReader(b []byte) *brotliSliceReader {
	return &brotliSliceReader{b: b}
}

func (r *brotliSliceReader) Read(p []byte) (int, error) {
	if len(r.b) > 1 {
		// Always withhold the final byte.
		n := copy(p, r.b[:len(r.b)-1])
		r.b = r.b[n:]
		return n, nil
	}
	if len(r.b) == 1 {
		if len(p) == 0 {
			return 0, nil
		}
		p[0] = r.b[0]
		r.b = r.b[1:]
		return 1, nil
	}
	return 0, io.EOF
}

// excessiveInput is only meaningful once the decoder has reported success:
// a decoder that stopped early hasn't asked for the held back byte either.
func (r *brotliSliceReader) excessiveInput() bool {
	return len(r.b) > 0
}

// normalizes compression level into [0..11], so it could be used as an index
// in *PoolMap.
func normalizeBrotliCompressLevel(level int) int {
	// -2 is the lowest compression level - CompressHuffmanOnly
	// 9 is the highest compression level - CompressBestCompression
	if level < 0 || level > 11 {
		level = CompressBrotliDefaultCompression
	}
	return level
}
