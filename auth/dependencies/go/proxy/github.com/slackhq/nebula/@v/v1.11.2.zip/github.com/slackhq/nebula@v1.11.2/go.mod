module github.com/slackhq/nebula

go 1.26.0

require (
	dario.cat/mergo v1.0.2
	filippo.io/bigmod v0.1.0
	github.com/DefinedNet/netlink v1.3.2-dn.1
	github.com/anmitsu/go-shlex v0.0.0-20200514113438-38f4b401e2be
	github.com/armon/go-radix v1.0.0
	github.com/flynn/noise v1.1.0
	github.com/gaissmai/bart v0.28.0
	github.com/gogo/protobuf v1.3.2
	github.com/google/gopacket v1.1.19
	github.com/kardianos/service v1.3.0
	github.com/miekg/dns v1.1.72
	github.com/miekg/pkcs11 v1.1.2
	github.com/nbrownus/go-metrics-prometheus v0.0.0-20210712211119-974a6260965f
	github.com/prometheus/client_golang v1.23.2
	github.com/rcrowley/go-metrics v0.0.0-20201227073835-cf1acfcdf475
	github.com/skip2/go-qrcode v0.0.0-20200617195104-da1b6568686e
	github.com/stefanberger/go-pkcs11uri v0.0.0-20230803200340-78284954bff6
	github.com/stretchr/testify v1.11.1
	go.uber.org/goleak v1.3.0
	go.yaml.in/yaml/v3 v3.0.4
	golang.org/x/crypto v0.54.0
	golang.org/x/exp v0.0.0-20230725093048-515e97ebf090
	golang.org/x/net v0.57.0
	golang.org/x/sync v0.22.0
	golang.org/x/sys v0.47.0
	golang.org/x/term v0.45.0
	golang.zx2c4.com/wintun v0.0.0-20230126152724-0fa3db229ce2
	golang.zx2c4.com/wireguard v0.0.0-20230325221338-052af4a8072b
	golang.zx2c4.com/wireguard/windows v1.0.1
	google.golang.org/protobuf v1.36.11
	gopkg.in/yaml.v3 v3.0.1
	gvisor.dev/gvisor v0.0.0-20240423190808-9d7a357edefe
)

require (
	github.com/beorn7/perks v1.0.1 // indirect
	github.com/cespare/xxhash/v2 v2.3.0 // indirect
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/google/btree v1.1.2 // indirect
	github.com/munnerz/goautoneg v0.0.0-20191010083416-a7dc8b61c822 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	github.com/prometheus/client_model v0.6.2 // indirect
	github.com/prometheus/common v0.66.1 // indirect
	github.com/prometheus/procfs v0.16.1 // indirect
	github.com/vishvananda/netns v0.0.5 // indirect
	go.yaml.in/yaml/v2 v2.4.2 // indirect
	golang.org/x/mod v0.36.0 // indirect
	golang.org/x/time v0.5.0 // indirect
	golang.org/x/tools v0.45.0 // indirect
)
