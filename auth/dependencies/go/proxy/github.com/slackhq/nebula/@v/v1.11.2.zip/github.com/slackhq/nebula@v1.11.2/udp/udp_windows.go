//go:build !e2e_testing
// +build !e2e_testing

package udp

import (
	"fmt"
	"log/slog"
	"net"
	"net/netip"
	"syscall"
)

func NewListener(l *slog.Logger, ip netip.Addr, port int, multi bool, batch int) (Conn, error) {
	if multi {
		//NOTE: Technically we can support it with RIO but it wouldn't be at the socket level
		// The udp stack would need to be reworked to hide away the implementation differences between
		// Windows and Linux
		return nil, fmt.Errorf("multiple udp listeners not supported on windows")
	}

	var conn Conn
	rc, err := NewRIOListener(l, ip, port)
	if err == nil {
		conn = rc
	} else {
		l.Error("Falling back to standard udp sockets", "error", err)
		conn, err = NewGenericListener(l, ip, port, multi, batch)
		if err != nil {
			return nil, err
		}
	}
	return wrapWithWDFBypass(l, conn), nil
}

func NewListenConfig(multi bool) net.ListenConfig {
	return net.ListenConfig{
		Control: func(network, address string, c syscall.RawConn) error {
			if multi {
				// There is no way to support multiple listeners safely on Windows:
				// https://docs.microsoft.com/en-us/windows/desktop/winsock/using-so-reuseaddr-and-so-exclusiveaddruse
				return fmt.Errorf("multiple udp listeners not supported on windows")
			}
			return nil
		},
	}
}

func (u *GenericConn) Rebind() error {
	return nil
}
