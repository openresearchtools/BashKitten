package quic

import (
	"testing"
	"time"

	"github.com/quic-go/quic-go/internal/monotime"
	"github.com/quic-go/quic-go/internal/protocol"
	"github.com/quic-go/quic-go/internal/qerr"
	"github.com/quic-go/quic-go/internal/utils"

	"github.com/stretchr/testify/require"
)

func TestConnectionFlowControlWindowUpdate(t *testing.T) {
	fc := newConnectionFlowController(
		100, // initial receive window
		100, // max receive window
		nil,
		utils.NewRTTStats(),
		utils.DefaultLogger,
	)
	require.False(t, fc.AddBytesRead(1))
	require.Zero(t, fc.GetWindowUpdate(monotime.Now()))
	require.True(t, fc.AddBytesRead(99))
	require.Equal(t, protocol.ByteCount(200), fc.GetWindowUpdate(monotime.Now()))
}

func TestConnectionWindowAutoTuningNotAllowed(t *testing.T) {
	// the RTT is 1 second
	rttStats := utils.NewRTTStats()
	rttStats.UpdateRTT(time.Second, 0)
	require.Equal(t, time.Second, rttStats.SmoothedRTT())

	callbackCalledWith := protocol.InvalidByteCount
	fc := newConnectionFlowController(
		100, // initial receive window
		150, // max receive window
		func(size protocol.ByteCount) bool {
			callbackCalledWith = size
			return false
		},
		rttStats,
		utils.DefaultLogger,
	)
	now := monotime.Now()
	require.NoError(t, fc.IncrementHighestReceived(100, now))
	fc.AddBytesRead(90)
	require.Equal(t, protocol.InvalidByteCount, callbackCalledWith)
	require.Equal(t, protocol.ByteCount(90+100), fc.GetWindowUpdate(now.Add(time.Millisecond)))
	require.Equal(t, protocol.ByteCount(150-100), callbackCalledWith)
}

func TestConnectionFlowControlViolation(t *testing.T) {
	fc := newConnectionFlowController(100, 100, nil, utils.NewRTTStats(), utils.DefaultLogger)
	require.NoError(t, fc.IncrementHighestReceived(40, monotime.Now()))
	require.NoError(t, fc.IncrementHighestReceived(60, monotime.Now()))
	err := fc.IncrementHighestReceived(1, monotime.Now())
	var terr *qerr.TransportError
	require.ErrorAs(t, err, &terr)
	require.Equal(t, qerr.FlowControlError, terr.ErrorCode)
}

func TestConnectionFlowControllerReset(t *testing.T) {
	fc := newConnectionFlowController(0, 0, nil, utils.NewRTTStats(), utils.DefaultLogger)
	fc.UpdateSendWindow(100)
	require.True(t, fc.TryAddBytesSent(10))
	require.Equal(t, protocol.ByteCount(90), fc.SendWindowSize())
	fc.Reset()
	require.Zero(t, fc.SendWindowSize())
}
