// Copyright 2022 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package com.google.firebase.concurrent;

import android.annotation.SuppressLint;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.Executor;

/** @hide */
public enum UiExecutor implements Executor {
  INSTANCE;

  // This is the only UI handler that is allowed in Firebase SDK.
  @SuppressLint("ThreadPoolCreation")
  private static final Handler HANDLER = new Handler(Looper.getMainLooper());

  @Override
  public void execute(Runnable command) {
    HANDLER.post(command);
  }
}
