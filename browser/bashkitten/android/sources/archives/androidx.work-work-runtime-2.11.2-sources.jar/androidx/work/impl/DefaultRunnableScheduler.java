/*
 * Copyright 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.work.impl;

import android.os.Handler;
import android.os.Looper;

import androidx.annotation.RestrictTo;
import androidx.core.os.HandlerCompat;
import androidx.work.RunnableScheduler;

import org.jspecify.annotations.NonNull;

/**
 * The default implementation of the {@link androidx.work.RunnableScheduler} used by
 * {@link  androidx.work.impl.background.greedy.GreedyScheduler}.
 *
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class DefaultRunnableScheduler implements RunnableScheduler {

    private final Handler mHandler;

    public DefaultRunnableScheduler() {
        mHandler = HandlerCompat.createAsync(Looper.getMainLooper());
    }

    public @NonNull Handler getHandler() {
        return mHandler;
    }

    @Override
    public void scheduleWithDelay(long delayInMillis, @NonNull Runnable runnable) {
        mHandler.postDelayed(runnable, delayInMillis);
    }

    @Override
    public void cancel(@NonNull Runnable runnable) {
        mHandler.removeCallbacks(runnable);
    }
}
