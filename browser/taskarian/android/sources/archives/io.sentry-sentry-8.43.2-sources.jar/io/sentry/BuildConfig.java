package io.sentry;

import java.lang.String;

public final class BuildConfig {
  public static final String SENTRY_JAVA_SDK_NAME = "sentry.java";

  public static final String VERSION_NAME = "8.43.2";

  private BuildConfig() {
  }
}
