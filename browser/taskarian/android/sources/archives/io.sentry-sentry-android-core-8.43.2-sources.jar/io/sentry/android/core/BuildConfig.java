/**
 * Automatically generated file. DO NOT MODIFY
 */
package io.sentry.android.core;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "io.sentry.android.core";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String SENTRY_ANDROID_SDK_NAME = "sentry.java.android";
  // Field from default config.
  public static final String VERSION_NAME = "8.43.2";
}
