/**
 * Automatically generated file. DO NOT MODIFY
 */
package mozilla.telemetry.glean;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "mozilla.telemetry.glean";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String GLEAN_MINICONDA_DIR = "/builds/worker/.gradle/glean/bootstrap-24.3.0-0/Miniconda3";
  // Field from default config.
  public static final String GLEAN_PING_SCHEMA_PATH = "/builds/worker/checkouts/vcs/glean.1.schema.json";
}
