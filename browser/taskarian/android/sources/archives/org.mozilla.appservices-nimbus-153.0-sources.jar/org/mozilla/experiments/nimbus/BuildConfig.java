/**
 * Automatically generated file. DO NOT MODIFY
 */
package org.mozilla.experiments.nimbus;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "org.mozilla.experiments.nimbus";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String LIBRARY_VERSION = "153.0";
}
